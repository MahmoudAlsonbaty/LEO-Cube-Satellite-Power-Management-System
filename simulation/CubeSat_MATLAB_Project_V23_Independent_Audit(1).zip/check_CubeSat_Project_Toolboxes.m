function check_CubeSat_Project_Toolboxes()
% check_CubeSat_Project_Toolboxes
%
% V12: added a check for the Aerospace Toolbox eclipse()/eclipseStatus()
% path (the "primary path" used by src/computeIlluminationProfile.m). This
% path additionally requires ephemeris data downloaded once via the
% Add-On Explorer (run >> aeroDataPackage), which is easy to miss -- this
% check tells the user up front whether they will be running on the
% high-fidelity dual-cone model or the analytic fallback, instead of
% leaving them to discover it from a printed message buried in the main
% script's console output.

    clc;
    fprintf('\nCubeSat Project Toolbox and UI Check\n');
    fprintf('====================================\n');

    names = {'satelliteScenario','simulink','new_system','simscape.logging.Node'};
    notes = {'Satellite scenario support','Simulink','Simulink model generation','Simscape logging support'};

    for i = 1:numel(names)
        available = exist(names{i},'file') == 2 || exist(names{i},'class') == 8 || exist(names{i},'builtin') == 5;
        fprintf('%-28s : %-3s | %s\n',names{i},yesNo(available),notes{i});
    end

    fprintf('\nEphemeris, scenario API, and 3-D viewer availability:\n');
    fprintf('(V14 separates these checks. planetEphemeris can be READY while\n');
    fprintf(' satelliteScenario/satelliteScenarioViewer are still unavailable because\n');
    fprintf(' the scenario toolbox path or license is not visible in this MATLAB session.)\n');
    ensureAerospaceEphemerisReady(true);

    fprintf('\nJava/UI status:\n');
    fprintf('usejava(''jvm'')     = %d\n',safeUseJava('jvm'));
    fprintf('usejava(''awt'')     = %d\n',safeUseJava('awt'));
    fprintf('usejava(''swing'')   = %d\n',safeUseJava('swing'));
    fprintf('usejava(''desktop'') = %d\n',safeUseJava('desktop'));

    fprintf('\nInstalled products:\n');
    v = ver;
    for i = 1:numel(v)
        fprintf(' - %s %s\n',v(i).Name,v(i).Version);
    end

    fprintf('\nNOTE on "CubeSat Toolbox": this project does not require or use the\n');
    fprintf('commercial "CubeSat Toolbox" sold separately by Princeton Satellite\n');
    fprintf('Systems -- that is a different, paid, third-party product (attitude\n');
    fprintf('control / magnetic-torquer focused) and is NOT a MathWorks toolbox.\n');
    fprintf('This project only uses Aerospace Toolbox / Satellite Communications\n');
    fprintf('Toolbox functionality (satelliteScenario, eclipse, access). See\n');
    fprintf('docs/Toolbox_Integration_Notes.md for details.\n');
end

function s = yesNo(v)
    if v
        s = 'YES';
    else
        s = 'NO';
    end
end

function tf = safeUseJava(feature)
    try
        tf = usejava(feature);
    catch
        tf = false;
    end
end
