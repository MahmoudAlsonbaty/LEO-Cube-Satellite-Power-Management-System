function START_TOOLBOX_VIEWER_WITH_METRICS()
% START_TOOLBOX_VIEWER_WITH_METRICS
% -------------------------------------------------------------------------
% Official satelliteScenarioViewer + smooth live metrics dashboard.
%
% V12 design (see docs/Firmware_Issues_and_Fixes.md and
% docs/Toolbox_Integration_Notes.md for the full write-up of what changed
% and why -- this header is the short version):
%
%   - One full orbit is shown, where "full orbit" is now computed from the
%     satellite's actual semi-major axis (trueOrbitalPeriodMinutes.m)
%     instead of a hardcoded "100 minutes" that did not match the orbit
%     actually being propagated by satelliteScenario.
%   - The metrics model's sample period is now DERIVED from the scenario's
%     sampleTimeSeconds (one source of truth) instead of being a separately
%     hardcoded 0.25 min -- removing a grid mismatch between the viewer and
%     the dashboard.
%   - Eclipse/sunlight is computed by computeIlluminationProfile.m, which
%     uses the real Aerospace Toolbox dual-cone eclipse analysis when
%     available, and an analytic beta-angle model (tied to the satellite's
%     actual inclination/RAAN/altitude and the real Sun position on the
%     chosen date) otherwise -- replacing a hardcoded 70/30 duty-cycle
%     guess that had no link to the satellite's real geometry.
%   - The firmware/telemetry model (src/simulateCubeSatSubsystem.m) now
%     has soft-start/soft-stop transients, realistic small sensor noise,
%     and a numerically-stable (exact exponential) lag discretization --
%     see that file's header for details.
%   - The previously-unused access(sat,gs) analysis is now captured and
%     surfaced as a "Next ground contact" KPI on the dashboard.
%   - V17: Dashboard sync used satelliteScenarioViewer.CurrentTime as the
%     primary live animation clock.
%   - V18: Dashboard sync now uses a single presentation wall clock locked to
%     the same PlaybackSpeedMultiplier as the viewer, with light viewer-time
%     correction when viewer.CurrentTime is readable. This removes the small
%     lag/jitter caused by reading the viewer clock directly at a lower UI
%     timer rate. Metric plots now cover 1.75 orbit cycles, while the 3-D
%     viewer still completes one true orbit in the target presentation time.
%
% Run:
%   START_TOOLBOX_VIEWER_WITH_METRICS

    clc;
    close all;

    % Defensively stop/delete any sync timer left running from a previous
    % run that did not get cleaned up via the dashboard's close callback
    % (e.g. the figure was deleted directly instead of closed). This is
    % cheap insurance against orphaned timer objects accumulating in the
    % base workspace across repeated runs in the same MATLAB session.
    if evalin('base','exist(''metricsTimer'',''var'')')
        try
            oldTimer = evalin('base','metricsTimer');
            if isvalid(oldTimer)
                stop(oldTimer);
                delete(oldTimer);
            end
        catch
        end
    end

    root = fileparts(mfilename('fullpath'));
    addpath(root);
    addpath(fullfile(root,'src'));

    % --- V13 FIX: validate and refresh ephemeris support before viewer. ------
    % The uploaded aerospaceephemerisdata.mlpkginstall file is only an
    % installer descriptor; MATLAB must install/register the Add-On and its
    % toolbox cache must be refreshed before planetEphemeris(), eclipse(),
    % and satelliteScenarioViewer can see the actual data. This helper checks
    % the direct ephemeris path first, calls rehash toolboxcache once if
    % needed, then validates the eclipseStatus path used by the illumination
    % model. It returns diagnostics instead of letting the viewer fail late.
    ephemerisInfo = ensureAerospaceEphemerisReady(true);
    ephemerisAvailable = ephemerisInfo.ephemerisAvailable;

    %% =====================================================
    % USER SETTINGS
    % ======================================================

    failureMode = "none";          % "none", "stuck_on", "stuck_off"

    % V16 FIX: keep the live dashboard on the fast analytic eclipse model by
    % default. Your Ctrl+C stack showed eclipseStatus -> planetEphemeris
    % spending too long inside ephemeris indexing while computeIlluminationProfile
    % sampled every dashboard/scenario point. That is not a missing-data error;
    % it is a performance/initialization cost of the high-fidelity eclipse API.
    % The official 3-D viewer can still use satelliteScenario, but the power
    % metrics use the analytic beta-angle model so one full orbit starts quickly
    % and finishes within the target presentation time. Set this to true only
    % for offline validation runs where you are willing to wait for MATLAB's
    % high-fidelity eclipse analysis.
    useToolboxEclipse = false;

    targetViewSeconds = 55;        % full viewer orbit finishes well under one minute

    % V18 FIX: the 3-D viewer still shows exactly one true orbit, but the
    % metric plots cover more than one orbit. This prevents the traces from
    % visually ending right at the cursor/finish point and lets you see the
    % next illumination/load transition beginning after the first orbit.
    plotOrbitCycles = 1.75;       % dashboard plot span only; viewer remains 1.00 orbit

    sampleTimeSeconds = 10;        % single source of truth for BOTH the
                                    % scenario sample time AND the firmware
                                    % model's dt -- see dtMin below
    dashboardHz = 8;               % dashboard refresh rate

    cairoLatDeg = 30.0444;
    cairoLonDeg = 31.2357;

    earthRadius_m = 6371e3;
    altitude_m = 500e3;
    semiMajorAxis_m = earthRadius_m + altitude_m;

    eccentricity = 0.001;
    inclination_deg = 51.6;
    raan_deg = 0;
    argPeriapsis_deg = 0;
    trueAnomaly_deg = 0;

    % --- V12 FIX: orbit period from physics, not a hardcoded number -----
    orbitMinutes = trueOrbitalPeriodMinutes(semiMajorAxis_m);
    playbackSpeed = orbitMinutes*60/targetViewSeconds;

    % --- V12 FIX: one shared dt for scenario AND firmware model ----------
    dtMin = sampleTimeSeconds/60;

    % --- V12 FIX: scale the fault-injection time with the real period so
    % a "stuck_on"/"stuck_off" demo still falls inside the displayed
    % orbit (V11's hardcoded failureTimeMin=95 silently stopped doing
    % anything once the displayed orbit shrank to ~94.5 minutes). -------
    failureTimeMin = 0.95*orbitMinutes;


    fprintf('\nSmooth official viewer + synced dashboard (V18 clock + plot-window sync)\n');
    fprintf('============================================================\n');
    fprintf('Ground station:        Cairo, Egypt\n');
    fprintf('True orbital period:   %.3f min (from a=%.0f km via vis-viva)\n',orbitMinutes,semiMajorAxis_m/1000);
    fprintf('Target viewer duration: %.0f sec for first orbit\n',targetViewSeconds);
    fprintf('Metrics plot span:    %.2f orbits (%.1f min)\n',plotOrbitCycles,plotOrbitCycles*orbitMinutes);
    fprintf('Playback speed:        %.1fx\n',playbackSpeed);
    fprintf('Shared sample dt:      %.0f s (scenario AND firmware model)\n',sampleTimeSeconds);
    fprintf('Dashboard refresh:     %.1f Hz\n',dashboardHz);

    %% =====================================================
    % SATELLITE SCENARIO / FALLBACK SCENARIO
    % ======================================================

    startTime = datetime(2026,6,27,12,0,0,'TimeZone','UTC');
    stopTime  = startTime + minutes(orbitMinutes); %#ok<NASGU>

    sc = [];
    sat = [];
    gs = [];
    gsAccess = [];
    viewer = [];
    useScenarioClock = false;
    clockMode = "wall-clock";
    viewerMode = "dashboard-only (toolbox viewer unavailable)";

    % --- V15 FIX: satelliteScenarioViewer is a METHOD of satelliteScenario. --
    % Your latest diagnostic proved the previous V14 gate was too strict:
    %       satelliteScenarioViewer:     NO
    %       satelliteScenarioViewer path: ...\@satelliteScenario\satelliteScenarioViewer.p
    % In MATLAB, class methods inside @class folders can be callable through
    % method dispatch even when exist('satelliteScenarioViewer','file') is not
    % reported as a normal top-level function. Therefore the correct gate is:
    %   1) satelliteScenario must be callable so we can make sc, and
    %   2) satelliteScenarioViewer must either be a normal function OR be found
    %      as a satelliteScenario class method by which('satelliteScenarioViewer').
    % We still wrap the actual call in try/catch; this gate only prevents a
    % false dashboard-only fallback when the viewer method is physically present.
    hasScenarioSupport = scenarioApiAvailable();
    hasViewerSupport   = viewerApiAvailable();

    if hasScenarioSupport
        try
            sc = satelliteScenario(startTime,stopTime,sampleTimeSeconds);
            sat = satellite(sc, ...
                semiMajorAxis_m, eccentricity, inclination_deg, ...
                raan_deg, argPeriapsis_deg, trueAnomaly_deg, ...
                'Name','CubeSat Sensor Payload Module');
            useScenarioClock = true;
            viewerMode = "official viewer pending";
        catch ME
            % Do not let a broken/partially licensed satelliteScenario path
            % stop the power-module simulation. The dashboard does not need a
            % scenario object because the physics model already has the same
            % orbital elements and mission time base.
            sc = [];
            sat = [];
            useScenarioClock = false;
            viewerMode = "dashboard-only (satelliteScenario failed)";
            fprintf(2,['satelliteScenario exists but could not be created.\n' ...
                       'Continuing with analytic orbit/dashboard playback.\n' ...
                       'Original scenario error: %s\n'],ME.message);
        end
    else
        fprintf(2,['satelliteScenario was not found on the MATLAB path.\n' ...
                   'This is not an ephemeris-data problem: planetEphemeris can see\n' ...
                   'the data, but the scenario/viewer API itself is unavailable.\n' ...
                   'Continuing with analytic orbit/dashboard playback.\n']);
    end

    if ~isempty(sc) && ~isempty(sat)
        try
            gs = groundStation(sc,cairoLatDeg,cairoLonDeg,'Name','Cairo Ground Station');
            gsAccess = access(sat,gs);   % V12 FIX: capture Access object for dashboard KPI
        catch ME
            gs = [];
            fprintf('Cairo ground station/access skipped: %s\n',ME.message);
        end
    end

    % NOTE: eclipse(sat) (inside computeIlluminationProfile) and the
    % access() call above are both added BEFORE the viewer is created /
    % before play() is called, while the scenario SimulationStatus is
    % still "NotStarted". If satelliteScenario support is missing, sat is
    % intentionally empty and computeIlluminationProfile falls back to the
    % analytic beta-angle model.
    orbitElements = struct('inclination_deg',inclination_deg, ...
                            'raan_deg',raan_deg, ...
                            'altitude_m',altitude_m);

    % Build the metrics time base now (same dt as the scenario -- V12 fix).
    % V18: use a longer plotting horizon than the viewer horizon so the graphs
    % show more of the repeated power/eclipse cycle. Append the exact final
    % plotting time because colon vectors can stop one sample early when dt does
    % not divide the span exactly.
    viewerOrbitMinutes = orbitMinutes;
    plotMinutes = plotOrbitCycles*orbitMinutes;
    timeMin = 0:dtMin:plotMinutes;
    if timeMin(end) < plotMinutes
        timeMin = [timeMin plotMinutes]; %#ok<AGROW>
    end

    if useToolboxEclipse && ~isempty(sat)
        % Optional high-fidelity path. The fifth argument explicitly enables
        % eclipseStatus because the default is now the fast analytic path.
        [illumFrac,eclipseInfo] = computeIlluminationProfile(sat,startTime,timeMin,orbitElements,true);
    else
        % Default production/presentation path. It avoids the slow
        % eclipseStatus -> planetEphemeris indexing path shown in your Ctrl+C
        % stack while keeping the dashboard physically tied to inclination, RAAN,
        % altitude, date, and true orbital period.
        [illumFrac,eclipseInfo] = computeIlluminationProfile([],startTime,timeMin,orbitElements,false);
    end

    fprintf('Eclipse model source:  %s\n',eclipseInfo.source);
    if ~isnan(eclipseInfo.betaDeg)
        fprintf('Beta angle (fallback): %.1f deg | eclipse fraction: %.1f%%\n', ...
            eclipseInfo.betaDeg, 100*eclipseInfo.eclipseFracOrbit);
    end

    % Open the official 3-D viewer when the method is discoverable OR when the
    % scenario object exists and the guarded call can prove it works. V15 avoids
    % treating @satelliteScenario/satelliteScenarioViewer.p as missing.
    if ~isempty(sc) && hasViewerSupport
        try
            viewer = satelliteScenarioViewer(sc,'ShowDetails',true);
            viewerMode = "official viewer";
            clockMode = "viewer-current-time";  % V17: sync dashboard to animated viewer clock.
        catch ME
            if isEphemerisError(ME)
                fprintf(2,'satelliteScenarioViewer needs ephemeris data for ShowDetails mode; retrying without ShowDetails...\n');
                try
                    viewer = satelliteScenarioViewer(sc);
                    viewerMode = "official viewer (reduced)";
                    clockMode = "viewer-current-time";  % V17: reduced viewer still exposes CurrentTime.
                    fprintf(2,['Viewer opened in reduced mode. The dashboard is still synced\n' ...
                               'to the presentation wall clock; detailed rendering is reduced.\n']);
                catch ME2
                    useScenarioClock = false;
                    viewerMode = "dashboard-only (viewer failed)";
                    fprintf(2,['satelliteScenarioViewer could not open even in reduced mode.\n' ...
                               'Continuing with dashboard-only playback.\n' ...
                               'Original viewer error: %s\n'],ME2.message);
                end
            else
                useScenarioClock = false;
                viewerMode = "dashboard-only (viewer failed)";
                fprintf(2,['satelliteScenarioViewer failed for a non-ephemeris reason.\n' ...
                           'Continuing with dashboard-only playback.\n' ...
                           'Original viewer error: %s\n'],ME.message);
            end
        end
    elseif ~isempty(sc)
        % Scenario propagation is available, but the viewer function is not.
        % play(sc) is not useful without a visible viewer, so use wall-clock
        % mission time to keep the dashboard smooth and bounded to one orbit.
        useScenarioClock = false;
        viewerMode = "dashboard-only (satelliteScenarioViewer missing)";
        fprintf(2,['satelliteScenario was created, but satelliteScenarioViewer was not found.\n' ...
                   'Continuing with dashboard-only playback.\n']);
    end

    assignin('base','sc',sc);
    assignin('base','sat',sat);
    assignin('base','gs',gs);
    assignin('base','viewer',viewer);
    assignin('base','ephemerisInfo',ephemerisInfo);

    %% =====================================================
    % SUBSYSTEM METRICS MODEL
    % ======================================================

    sim = simulateCubeSatSubsystem(failureMode,failureTimeMin,illumFrac,timeMin,dtMin,42);

    contacts = computeNextGroundContact(gsAccess,startTime);

    fprintf('Failure mode:       %s (fault time: %.1f min)\n',failureMode,failureTimeMin);
    fprintf('Energy saving:      %.1f %%\n',sim.energySavingPct);
    fprintf('Payload ON duty:    %.1f %%\n',100*mean(sim.modeName=="PAYLOAD ON"));
    fprintf('Rail ON duty:       %.1f %%\n',100*mean(sim.railV>0));
    fprintf('Max temperature:    %.1f C\n',max(sim.tempC));
    fprintf('Average current:    %.2f mA\n',mean(sim.currentmA));
    fprintf('Ground contacts in window: %d\n',numel(contacts));
    fprintf('Viewer mode:        %s\n',viewerMode);
    if clockMode == "viewer-current-time"
        fprintf('Dashboard clock:    wall-clock locked + viewer resync\n');
    else
        fprintf('Dashboard clock:    %s\n',clockMode);
    end
    fprintf('============================================================\n');

    dash = createModernDashboard(sim,playbackSpeed,targetViewSeconds,eclipseInfo,contacts,viewerMode,viewerOrbitMinutes,plotOrbitCycles);
    updateDashboardFromMissionTime(dash,sim,0);

    %% =====================================================
    % SMOOTH SYNC: WALL-CLOCK LOCKED TO VIEWER PLAYBACK
    % ======================================================

    % V18 FIX: The dashboard now uses a single presentation wall clock that is
    % locked to the same playbackSpeed used by play(sc,...). Reading
    % viewer.CurrentTime directly every UI tick removed the static-dashboard bug
    % in V17, but it can still be slightly out of sync because the viewer clock
    % is sampled discretely and may lag the UI timer. V18 uses the wall clock
    % as the smooth primary timeline, then lightly corrects its offset whenever
    % viewer.CurrentTime is readable. This gives a smoother dashboard without
    % drifting away from the official viewer.

    refreshPeriod = max(0.05,1/dashboardHz);

    t = timer( ...
        'ExecutionMode','fixedRate', ...
        'Period',refreshPeriod, ...
        'TasksToExecute',ceil(targetViewSeconds*dashboardHz)+60, ...
        'BusyMode','drop', ...
        'TimerFcn',@(timerObj,evt) updateFromPlaybackTime(timerObj,evt,dash,sim,sc,viewer,startTime,viewerOrbitMinutes,clockMode,playbackSpeed), ...
        'StopFcn',@(~,~) fprintf('Dashboard sync timer stopped.\n'));

    dash.timer = t;
    setappdata(dash.fig,'syncTimer',t);
    set(dash.fig,'CloseRequestFcn',@closeDashboard);

    assignin('base','metricsTimer',t);

    clockData = struct('clockTic',tic, ...
                       'clockMode',clockMode, ...
                       'clockOffsetMin',0, ...
                       'viewerLockEstablished',false, ...
                       'lastMissionMinute',0);
    set(t,'UserData',clockData);

    try
        start(t);
        if useScenarioClock
            play(sc,'PlaybackSpeedMultiplier',playbackSpeed);
        end
    catch ME
        try
            stop(t);
            delete(t);
        catch
        end
        error('Could not start smooth synced playback. Original error: %s',ME.message);
    end

    fprintf('\nPlayback started.\n');
    if clockMode == "viewer-current-time"
        fprintf('The official viewer runs smoothly; the dashboard uses a playback-rate wall clock.\n');
        fprintf('viewer.CurrentTime is used only for small drift corrections, not as the noisy primary clock.\n');
    else
        fprintf('Dashboard fallback clock is active; mission time is driven by the same internal wall clock.\n');
        fprintf('This keeps the metrics live even when the viewer API cannot provide a live time.\n');
    end
end

%% ========================================================================
% TIMER / WINDOW
% =========================================================================

function updateFromPlaybackTime(timerObj,~,dash,sim,sc,viewer,startTime,viewerOrbitMinutes,clockMode,playbackSpeed)
    if ~ishandle(dash.fig)
        try
            stop(timerObj);
        catch
        end
        return;
    end

    % V18 primary timeline: one smooth presentation clock. The official
    % viewer and dashboard are both configured to the same playbackSpeed, so
    % this avoids the small lag/jitter that appears when the dashboard samples
    % viewer.CurrentTime directly only 8 times per second.
    clockData = get(timerObj,'UserData');
    if ~isstruct(clockData) || ~isfield(clockData,'clockTic')
        clockData = struct('clockTic',tic, ...
                           'clockMode',clockMode, ...
                           'clockOffsetMin',0, ...
                           'viewerLockEstablished',false, ...
                           'lastMissionMinute',0);
    end

    elapsedSec = toc(clockData.clockTic);
    wallMissionMinute = elapsedSec * playbackSpeed/60 + clockData.clockOffsetMin;

    % Optional correction from the official viewer clock. This is deliberately
    % an OFFSET correction rather than directly driving the UI from
    % viewer.CurrentTime. The direct approach fixed the frozen dashboard, but
    % it made the metric cursor visually trail/lead the 3-D animation by a
    % small amount on some MATLAB/R2025b machines.
    viewerMinute = NaN;
    if clockMode == "viewer-current-time" && ~isempty(viewer)
        try
            viewerMinute = minutes(viewer.CurrentTime - startTime);
        catch
            viewerMinute = NaN;
        end
    end

    if ~isnan(viewerMinute) && viewerMinute >= 0
        rawWallMinute = elapsedSec * playbackSpeed/60;
        desiredOffset = viewerMinute - rawWallMinute;
        driftMin = viewerMinute - wallMissionMinute;

        if ~clockData.viewerLockEstablished && viewerMinute > 0
            % First positive viewer timestamp: snap the internal offset to the
            % viewer so both displays share the same starting phase.
            clockData.clockOffsetMin = desiredOffset;
            clockData.viewerLockEstablished = true;
            wallMissionMinute = viewerMinute;
        elseif abs(driftMin) > 0.25
            % Large visible mismatch: correct aggressively but still smoothly.
            clockData.clockOffsetMin = clockData.clockOffsetMin + 0.75*driftMin;
            wallMissionMinute = elapsedSec * playbackSpeed/60 + clockData.clockOffsetMin;
        elseif abs(driftMin) > 0.04
            % Small mismatch: gentle correction. 0.04 min is ~2.4 seconds of
            % mission time, below the visual significance of the 10 s scenario
            % sample grid but enough to prevent gradual drift.
            clockData.clockOffsetMin = clockData.clockOffsetMin + 0.20*driftMin;
            wallMissionMinute = elapsedSec * playbackSpeed/60 + clockData.clockOffsetMin;
        end
    elseif ~isempty(sc)
        % Secondary fallback for odd viewer states. This is only used when
        % viewer.CurrentTime cannot be read at all.
        try
            scenarioMinute = minutes(sc.SimulationTime - startTime);
            if scenarioMinute > 0
                wallMissionMinute = scenarioMinute;
            end
        catch
        end
    end

    missionMinute = wallMissionMinute;
    if isnan(missionMinute) || missionMinute < 0
        missionMinute = 0;
    end
    missionMinute = min(missionMinute,viewerOrbitMinutes);

    % Keep time monotonic on the dashboard so a one-frame viewer read jitter
    % cannot make the cursor jump backward.
    if isfield(clockData,'lastMissionMinute')
        missionMinute = max(missionMinute,clockData.lastMissionMinute);
    end
    clockData.lastMissionMinute = missionMinute;
    set(timerObj,'UserData',clockData);

    updateDashboardFromMissionTime(dash,sim,missionMinute);

    if missionMinute >= viewerOrbitMinutes
        try
            stop(timerObj);
        catch
        end
    end
end

function closeDashboard(src,~)
    t = getappdata(src,'syncTimer');
    if ~isempty(t)
        try
            stop(t);
        catch
        end
        try
            delete(t);
        catch
        end
    end
    delete(src);
end

% V23 (independent audit): scenarioApiAvailable, viewerApiAvailable, and
% functionAvailable used to be defined as local functions here AND
% (identically) in src/ensureAerospaceEphemerisReady.m. They are now each
% their own file in src/ (already on this script's path via
% addpath(fullfile(root,'src')) above), so both callers share one
% implementation instead of two copies that could silently drift apart.

function tf = isEphemerisError(ME)
% isEphemerisError
% Checks the primary error and its causes for the external ephemeris-data
% failure signature. MATLAB wraps viewer errors differently across releases,
% so testing only ME.message is not robust enough.
    tf = messageLooksLikeEphemerisError(ME.message);
    try
        for i = 1:numel(ME.cause)
            tf = tf || messageLooksLikeEphemerisError(ME.cause{i}.message);
        end
    catch
    end
end

function tf = messageLooksLikeEphemerisError(msg)
    tf = contains(msg,'Ephemeris data','IgnoreCase',true) || ...
         contains(msg,'aeroDataPackage','IgnoreCase',true) || ...
         contains(msg,'planetEphemeris','IgnoreCase',true);
end

%% ========================================================================
% DASHBOARD CREATION
% =========================================================================

function dash = createModernDashboard(sim,playbackSpeed,targetViewSeconds,eclipseInfo,contacts,viewerMode,viewerOrbitMinutes,plotOrbitCycles)
    th = getTheme();

    fig = figure( ...
        'Name','CubeSat Power Module Dashboard - Clock Sync + Extended Cycle View', ...
        'NumberTitle','off', ...
        'Color',th.bg, ...
        'MenuBar','figure', ...
        'ToolBar','figure', ...
        'WindowStyle','normal', ...
        'Resize','on', ...
        'Position',[865 35 1000 940]);

    axUI = axes('Parent',fig,'Position',[0 0 1 1]);
    axis(axUI,[0 100 0 100]);
    axis(axUI,'off');
    hold(axUI,'on');
    set(axUI,'Color',th.bg);

    % Chart axes
    axCurrent = axes('Parent',fig,'Position',[0.075 0.315 0.395 0.135]);
    axTemp    = axes('Parent',fig,'Position',[0.555 0.315 0.370 0.135]);
    axRail    = axes('Parent',fig,'Position',[0.075 0.135 0.395 0.135]);
    axEnergy  = axes('Parent',fig,'Position',[0.555 0.135 0.370 0.135]);
    axEnv     = axes('Parent',fig,'Position',[0.075 0.045 0.850 0.055]);

    setupChart(axCurrent,th);
    setupChart(axTemp,th);
    setupChart(axRail,th);
    setupChart(axEnergy,th);
    setupChart(axEnv,th);

    plot(axCurrent,sim.timeMin,sim.baselineCurrentmA,'--','Color',th.muted,'LineWidth',1.0);
    hold(axCurrent,'on');
    % V23 FIX (independent audit, dashboard objective #4): the foreground
    % telemetry line used to be plotted in full at creation time, with only
    % an xline cursor sweeping across an already-complete curve during
    % "live" playback -- not actually real-time line drawing. Now a faint
    % full-range PREVIEW (muted color, drawn once, cheap) sits underneath a
    % bold LIVE line that updateDashboard() grows frame-by-frame via
    % XData/YData, so only telemetry "received so far" is rendered in the
    % live color; the muted preview still shows the V18-intended look-ahead
    % context (this chart's data spans 1.75 orbits; playback only reaches
    % 1.0 orbit) without pretending it is already-sampled telemetry.
    plot(axCurrent,sim.timeMin,sim.currentmA,'Color',mutedColor(th.blue,th.chartBg),'LineWidth',1.0);
    liveCurrent = plot(axCurrent,sim.timeMin(1),sim.currentmA(1),'Color',th.blue,'LineWidth',1.8);
    title(axCurrent,'Current draw (context-dependent)','Color',th.fg,'FontSize',10,'FontWeight','bold');
    ylabel(axCurrent,'mA','Color',th.fg);
    xlim(axCurrent,[0 sim.timeMin(end)]);
    ylim(axCurrent,[0 max(sim.baselineCurrentmA)*1.15]);
    xline(axCurrent,viewerOrbitMinutes,':','1 orbit','Color',th.muted,'LineWidth',0.9,'LabelVerticalAlignment','bottom','LabelHorizontalAlignment','right');
    cCurrent = xline(axCurrent,0,'Color',th.white,'LineWidth',1.2);

    plot(axTemp,sim.timeMin,sim.tempC,'Color',mutedColor(th.orange,th.chartBg),'LineWidth',1.0);
    hold(axTemp,'on');
    liveTemp = plot(axTemp,sim.timeMin(1),sim.tempC(1),'Color',th.orange,'LineWidth',1.8);
    yline(axTemp,120,'--','Color',th.red,'LineWidth',0.9);
    yline(axTemp,100,'--','Color',th.yellow,'LineWidth',0.9);
    title(axTemp,'Temperature (context-dependent)','Color',th.fg,'FontSize',10,'FontWeight','bold');
    ylabel(axTemp,'C','Color',th.fg);
    xlim(axTemp,[0 sim.timeMin(end)]);
    ylim(axTemp,[min(sim.tempC)-8 max(sim.tempC)+10]);
    xline(axTemp,viewerOrbitMinutes,':','1 orbit','Color',th.muted,'LineWidth',0.9,'LabelVerticalAlignment','bottom','LabelHorizontalAlignment','right');
    cTemp = xline(axTemp,0,'Color',th.white,'LineWidth',1.2);

    stairs(axRail,sim.timeMin,sim.railV,'Color',mutedColor(th.green,th.chartBg),'LineWidth',1.0);
    hold(axRail,'on');
    liveRail = stairs(axRail,sim.timeMin(1),sim.railV(1),'Color',th.green,'LineWidth',1.8);
    title(axRail,'Sensor rail voltage (context-dependent)','Color',th.fg,'FontSize',10,'FontWeight','bold');
    ylabel(axRail,'V','Color',th.fg);
    xlim(axRail,[0 sim.timeMin(end)]);
    ylim(axRail,[-0.2 3.8]);
    xline(axRail,viewerOrbitMinutes,':','1 orbit','Color',th.muted,'LineWidth',0.9,'LabelVerticalAlignment','bottom','LabelHorizontalAlignment','right');
    cRail = xline(axRail,0,'Color',th.white,'LineWidth',1.2);

    plot(axEnergy,sim.timeMin,sim.cumBaselineWh,'--','Color',th.muted,'LineWidth',1.0);
    hold(axEnergy,'on');
    plot(axEnergy,sim.timeMin,sim.cumImprovedWh,'Color',mutedColor(th.green,th.chartBg),'LineWidth',1.0);
    liveEnergy = plot(axEnergy,sim.timeMin(1),sim.cumImprovedWh(1),'Color',th.green,'LineWidth',1.8);
    title(axEnergy,'Cumulative energy (lower is better)','Color',th.fg,'FontSize',10,'FontWeight','bold');
    ylabel(axEnergy,'Wh','Color',th.fg);
    xlim(axEnergy,[0 sim.timeMin(end)]);
    ylim(axEnergy,[0 max(sim.cumBaselineWh)*1.08]);
    xline(axEnergy,viewerOrbitMinutes,':','1 orbit','Color',th.muted,'LineWidth',0.9,'LabelVerticalAlignment','bottom','LabelHorizontalAlignment','right');
    cEnergy = xline(axEnergy,0,'Color',th.white,'LineWidth',1.2);

    % V12 FIX: continuous illumination fraction instead of a binary
    % eclipse/sun stairstep -- this is the plot that makes the smoothed
    % terminator crossing actually visible on the dashboard.
    plot(axEnv,sim.timeMin,sim.illumFrac,'Color',mutedColor(th.yellow,th.chartBg),'LineWidth',1.4);
    hold(axEnv,'on');
    liveEnv = plot(axEnv,sim.timeMin(1),sim.illumFrac(1),'Color',th.yellow,'LineWidth',2.2);
    yline(axEnv,0.5,':','Color',th.muted,'LineWidth',0.8);
    title(axEnv,sprintf('Environment timeline (%s, informational)',eclipseInfo.source), ...
        'Color',th.fg,'FontSize',9,'FontWeight','bold','Interpreter','none');
    xlim(axEnv,[0 sim.timeMin(end)]);
    ylim(axEnv,[-0.05 1.05]);
    yticks(axEnv,[0 1]);
    yticklabels(axEnv,{'Eclipse','Sun'});
    xlabel(axEnv,'Mission time (min)','Color',th.fg);
    xline(axEnv,viewerOrbitMinutes,':','1 orbit','Color',th.muted,'LineWidth',0.9,'LabelVerticalAlignment','bottom','LabelHorizontalAlignment','right');
    cEnv = xline(axEnv,0,'Color',th.white,'LineWidth',1.2);

    % UI cards drawn once
    dash = struct();
    dash.fig = fig;
    dash.axUI = axUI;
    dash.cursors = [cCurrent cTemp cRail cEnergy cEnv];
    % V23 FIX (independent audit, dashboard objective #4): handles to the
    % foreground "live" line objects, grown frame-by-frame in
    % updateDashboard() so the chart actually draws in real time instead of
    % only moving a cursor over an already-complete static curve.
    dash.liveLines = [liveCurrent liveTemp liveRail liveEnergy liveEnv];
    dash.theme = th;
    dash.playbackSpeed = playbackSpeed;
    dash.targetViewSeconds = targetViewSeconds;
    dash.viewerOrbitMinutes = viewerOrbitMinutes;
    dash.plotOrbitCycles = plotOrbitCycles;
    dash.eclipseInfo = eclipseInfo;
    dash.contacts = contacts;
    dash.viewerMode = viewerMode;

    dash.ui = createUICards(axUI,th,eclipseInfo);
end

function ui = createUICards(ax,th,eclipseInfo)
    % Header
    ui.headerBox = roundedRect(ax,3,92,94,6,th.card2,th.grid,1.0);
    ui.title = text(ax,5,95,'CubeSat Sensor Payload Power Module', ...
        'Color',th.fg,'FontWeight','bold','FontSize',15);
    ui.clock = text(ax,95,95,'', ...
        'Color',th.muted,'HorizontalAlignment','right','FontName','Consolas','FontSize',10);

    % Hero cards
    [ui.envBox,ui.envBig,ui.envSmall] = heroCard(ax,3,80,45,9,th);
    [ui.modeBox,ui.modeBig,ui.modeSmall] = heroCard(ax,52,80,45,9,th);
    ui.envSourceNote = eclipseInfo.source;

    % KPI cards -- V12: widened from 4 to 5 narrower cards to fit the new
    % "Next ground contact" KPI (surfaces the access() analysis that V11
    % computed but never displayed) without disturbing the rest of the
    % layout.
    kpiW = 17; kpiGap = 2.25;
    xKPI = 3 + (0:4)*(kpiW+kpiGap);
    [ui.railBox,ui.railValue,ui.railLabel]       = kpiCard(ax,xKPI(1),66,kpiW,10,'Sensor rail',th);
    [ui.currentBox,ui.currentValue,ui.currentLabel] = kpiCard(ax,xKPI(2),66,kpiW,10,'Current',th);
    [ui.tempBox,ui.tempValue,ui.tempLabel]       = kpiCard(ax,xKPI(3),66,kpiW,10,'Temperature',th);
    [ui.energyBox,ui.energyValue,ui.energyLabel] = kpiCard(ax,xKPI(4),66,kpiW,10,'Energy saved',th);
    [ui.contactBox,ui.contactValue,ui.contactLabel] = kpiCard(ax,xKPI(5),66,kpiW,10,'Next contact',th);

    % Progress cards
    [ui.orbitBox,ui.orbitBar,ui.orbitPct] = progressCard(ax,3,54,30,8,'Orbit progress',th);
    [ui.currentProgressBox,ui.currentBar,ui.currentPct] = progressCard(ax,36,54,30,8,'Current vs baseline',th);
    [ui.thermalBox,ui.thermalBar,ui.thermalPct] = progressCard(ax,69,54,28,8,'Thermal limit',th);

    % Mission strip
    ui.stripBox = roundedRect(ax,3,47,94,4.5,th.card,th.grid,0.7);
    ui.strip = text(ax,5,49.2,'', ...
        'Color',th.muted,'FontName','Consolas','FontSize',9.3);
end

function updateDashboardFromMissionTime(dash,sim,missionMinute)
    [~,idx] = min(abs(sim.timeMin - missionMinute));
    updateDashboard(dash,sim,idx,missionMinute);
end

function updateDashboard(dash,sim,k,missionMinute)
    th = dash.theme;
    ui = dash.ui;

    for i = 1:numel(dash.cursors)
        if isvalid(dash.cursors(i))
            dash.cursors(i).Value = missionMinute;
        end
    end

    % V23 FIX (independent audit, dashboard objective #4): grow each live
    % line to include every sample up to and including the current index k.
    % Re-slicing the full prefix each call (rather than addpoints-style
    % appending) is deliberate: it stays correct even if missionMinute is
    % ever non-monotonic between calls (the upstream timer already clamps
    % this -- see updateFromPlaybackTime's lastMissionMinute guard -- but
    % this makes the chart-update code correct on its own terms too), and at
    % this sample count (a few hundred to ~1000 points for the live dashboard
    % window) the cost is negligible next to drawnow limitrate's own budget.
    if isfield(dash,'liveLines')
        idxRange = 1:k;
        set(dash.liveLines(1),'XData',sim.timeMin(idxRange),'YData',sim.currentmA(idxRange));
        set(dash.liveLines(2),'XData',sim.timeMin(idxRange),'YData',sim.tempC(idxRange));
        set(dash.liveLines(3),'XData',sim.timeMin(idxRange),'YData',sim.railV(idxRange));
        set(dash.liveLines(4),'XData',sim.timeMin(idxRange),'YData',sim.cumImprovedWh(idxRange));
        set(dash.liveLines(5),'XData',sim.timeMin(idxRange),'YData',sim.illumFrac(idxRange));
    end

    if sim.isEclipse(k)
        envText = 'ECLIPSE';
        envSub = sprintf('Earth shadow (%.0f%% illum)',100*sim.illumFrac(k));
        envColor = th.blue;
    else
        envText = 'SUNLIGHT';
        envSub = sprintf('solar input %.0f%% (%s)',100*sim.illumFrac(k),ui.envSourceNote);
        envColor = th.yellow;
    end

    mode = sim.modeName(k);
    modeColor = modeColorFor(mode,th);

    set(ui.clock,'String',sprintf('%.0fx  |  %.0f sec view  |  t = %.1f min', ...
        dash.playbackSpeed,dash.targetViewSeconds,missionMinute));

    set(ui.envBox,'EdgeColor',envColor);
    set(ui.envBig,'String',envText,'Color',envColor);
    set(ui.envSmall,'String',envSub);

    set(ui.modeBox,'EdgeColor',modeColor);
    set(ui.modeBig,'String',char(mode),'Color',modeColor);
    set(ui.modeSmall,'String','firmware state');

    set(ui.railValue,'String',sprintf('%.1f V',sim.railV(k)),'Color',railColor(sim.railV(k),th));
    set(ui.currentValue,'String',sprintf('%.2f mA',sim.currentmA(k)),'Color',th.blue);
    set(ui.tempValue,'String',sprintf('%.1f C',sim.tempC(k)),'Color',tempColor(sim.tempC(k),th));
    set(ui.energyValue,'String',sprintf('%.1f%%',sim.energySavingPct),'Color',th.green);

    contactText = nextContactText(dash.contacts,missionMinute);
    set(ui.contactValue,'String',contactText,'Color',th.purple);

    updateProgress(ui.orbitBar,ui.orbitPct,missionMinute/dash.viewerOrbitMinutes,th.purple);
    updateProgress(ui.currentBar,ui.currentPct,min(sim.currentmA(k)/40.1,1),th.blue);
    updateProgress(ui.thermalBar,ui.thermalPct,min(max(sim.tempC(k),0)/120,1),tempColor(sim.tempC(k),th));

    set(ui.strip,'String',sprintf('Viewer: %s   |   Plot span: %.2f orbits   |   Cairo GS   |   Payload ON: %.1f%%   |   Rail ON: %.1f%%   |   Eclipse: %.1f%%', ...
        dash.viewerMode,dash.plotOrbitCycles,100*mean(sim.modeName=="PAYLOAD ON"),100*mean(sim.railV>0),100*mean(sim.isEclipse)));

    drawnow limitrate;
end

function txt = nextContactText(contacts,missionMinute)
    % V12: surfaces the previously-unused access() analysis as a simple
    % "currently in contact" / "time until next contact" KPI string.
    if isempty(contacts)
        txt = 'n/a';
        return;
    end

    for i = 1:numel(contacts)
        if missionMinute >= contacts(i).startMin && missionMinute <= contacts(i).endMin
            txt = sprintf('IN VIEW (%.0fs left)',60*(contacts(i).endMin-missionMinute));
            return;
        end
    end

    futureStarts = arrayfun(@(c) c.startMin, contacts);
    futureStarts(futureStarts < missionMinute) = Inf;
    waitMin = min(futureStarts - missionMinute);

    if isinf(waitMin)
        txt = 'none left';
    else
        txt = sprintf('in %.1f min',waitMin);
    end
end

function updateProgress(barObj,pctObj,fraction,color)
    fraction = max(0,min(1,fraction));
    pos = get(barObj,'UserData');
    pos(3) = pos(5)*fraction; % pos = [x y w h maxWidth]
    set(barObj,'Position',pos(1:4),'FaceColor',color,'EdgeColor',color);
    set(pctObj,'String',sprintf('%.0f%%',fraction*100),'Color',color);
end

function obj = roundedRect(ax,x,y,w,h,face,edge,lw)
    obj = rectangle(ax,'Position',[x y w h],'Curvature',0.08, ...
        'FaceColor',face,'EdgeColor',edge,'LineWidth',lw);
end

function [box,bigTxt,smallTxt] = heroCard(ax,x,y,w,h,th)
    box = roundedRect(ax,x,y,w,h,th.card,th.grid,1.7);
    bigTxt = text(ax,x+3,y+h*0.62,'', ...
        'Color',th.fg,'FontName','Consolas','FontWeight','bold','FontSize',18);
    smallTxt = text(ax,x+3,y+h*0.25,'', ...
        'Color',th.muted,'FontSize',9.5);
end

function [box,valueTxt,labelTxt] = kpiCard(ax,x,y,w,h,label,th)
    box = roundedRect(ax,x,y,w,h,th.card,th.grid,1.0);
    valueTxt = text(ax,x+w/2,y+h*0.58,'', ...
        'Color',th.fg,'FontName','Consolas','FontWeight','bold','FontSize',13.5, ...
        'HorizontalAlignment','center');
    labelTxt = text(ax,x+w/2,y+h*0.24,label, ...
        'Color',th.muted,'FontSize',8.3,'HorizontalAlignment','center');
end

function [box,bar,pct] = progressCard(ax,x,y,w,h,label,th)
    box = roundedRect(ax,x,y,w,h,th.card,th.grid,1.0);
    text(ax,x+2,y+h*0.62,label,'Color',th.fg,'FontSize',9.2,'FontWeight','bold');
    roundedRect(ax,x+2,y+1.2,w-4,1.4,th.track,th.track,0.1);
    bar = roundedRect(ax,x+2,y+1.2,0,1.4,th.blue,th.blue,0.1);
    set(bar,'UserData',[x+2,y+1.2,0,1.4,w-4]);
    pct = text(ax,x+w-2,y+h*0.62,'0%', ...
        'Color',th.blue,'HorizontalAlignment','right','FontName','Consolas', ...
        'FontWeight','bold','FontSize',9.2);
end

%% ========================================================================
% STYLE
% =========================================================================

function setupChart(ax,th)
    set(ax,'Color',th.chartBg, ...
        'XColor',th.fg, ...
        'YColor',th.fg, ...
        'GridColor',th.grid, ...
        'MinorGridColor',th.grid, ...
        'FontName','Consolas', ...
        'FontSize',7, ...
        'LineWidth',0.8, ...
        'Box','on');
    grid(ax,'on');
end

function th = getTheme()
    th.bg = [0.010 0.014 0.026];
    th.card = [0.035 0.047 0.075];
    th.card2 = [0.050 0.065 0.105];
    th.chartBg = [0.018 0.026 0.045];
    th.track = [0.075 0.090 0.125];

    th.fg = [0.92 0.95 1.00];
    th.white = [1.00 1.00 1.00];
    th.muted = [0.58 0.64 0.74];
    th.grid = [0.20 0.26 0.38];

    th.blue = [0.30 0.68 1.00];
    th.green = [0.24 0.90 0.54];
    th.yellow = [1.00 0.78 0.18];
    th.orange = [1.00 0.45 0.18];
    th.red = [1.00 0.28 0.28];
    th.purple = [0.78 0.45 1.00];
end

function out = mutedColor(liveColor, bg)
% mutedColor
% -------------------------------------------------------------------------
% V23 (independent audit, dashboard objective #4): blends a chart's live
% telemetry color toward the chart background to produce a faint
% "preview" color for the full-range look-ahead curve, visually distinct
% from the bold "live" line drawn on top of it as the simulation advances.
    blend = 0.32;
    out = blend*liveColor + (1-blend)*bg;
end

function c = modeColorFor(modeName,th)
    switch string(modeName)
        case "PAYLOAD ON"
            c = th.green;
        case "ECLIPSE SLEEP"
            c = th.blue;
        case "THERMAL PROTECT"
            c = th.orange;
        case "BACKUP SAFE"
            c = th.purple;
        case "BOOT"
            c = th.muted;
        otherwise
            c = th.muted;
    end
end

function c = railColor(v,th)
    if v > 0
        c = th.green;
    else
        c = th.blue;
    end
end

function c = tempColor(t,th)
    if t >= 120
        c = th.red;
    elseif t >= 100
        c = th.orange;
    else
        c = th.green;
    end
end
