# validation_extra/

Added during the V22/V23 independent audit. Same spirit as `validation/`
(see that folder's README): a Python cross-check used because no licensed
MATLAB installation was available to run the real `.m` files directly.

- `missionpower_crosscheck.py` -- a hand-transcribed Python port of
  `src/simulateCubeSatMissionPower.m`, `src/estimateCubeSatEPSPowerBudget.m`,
  and the `scenarioConfig()` function in `RUN_FULL_MISSION_POWER_METRICS.m`.

  This closes a gap that existed through V22: `simulateCubeSatSubsystem.m`
  has `validation/crosscheck_firmware.py`, and the orbit/eclipse math has
  `validation/crosscheck.py`, but `simulateCubeSatMissionPower.m` -- the
  file with the most interacting nonlinear effects in the whole project
  (DOD stress, C-rate stress, calendar stress, temperature acceleration,
  EFC weighting, SOC clamping, all compounding over a multi-year run) --
  had no equivalent. Running it across all three scenarios and six mission
  durations (30/90/180/365/730/1095 days) is what caught the SOC
  floor-clamp edge case described in `docs/Power_Metrics_Model_Assumptions_V22.md`
  and fixed in `src/simulateCubeSatMissionPower.m`.

Run as:

```bash
python3 validation_extra/missionpower_crosscheck.py
```

Like everything in `validation/`, this is not a substitute for running
the real project in MATLAB -- it is a record of how the battery/EPS model
was numerically stress-tested without one, kept for the same auditability
reasons as the rest of `validation/`.
