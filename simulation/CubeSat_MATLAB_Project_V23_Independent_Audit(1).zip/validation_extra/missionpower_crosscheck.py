"""
Independent Python port of src/simulateCubeSatMissionPower.m,
src/estimateCubeSatEPSPowerBudget.m, and the scenarioConfig() function in
RUN_FULL_MISSION_POWER_METRICS.m.

Purpose: this is the file in the project with the most interacting
nonlinear effects (DOD stress, C-rate stress, calendar stress, temperature
acceleration, EFC weighting, SOC clamping) and it is the ONE file in the
project with no existing Python cross-check (simulateCubeSatSubsystem.m
has crosscheck_firmware.py; the orbit/eclipse math has crosscheck.py).
This script fills that gap: it is not a MATLAB parser and cannot replace
running the real .m file in MATLAB, but it lets logical/numerical issues
(NaNs, runaway values, out-of-band SOC, sign errors) be caught without a
MATLAB license, the same way the rest of /validation/ already does.

Transcribed by hand from the .m source as of the V22 delivery under review.
"""
import math
import numpy as np
from datetime import datetime, timezone
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "validation"))
import crosscheck as xc  # reuse the already-validated orbit/eclipse math

Re = 6371e3
mu = 3.986004418e14


def true_orbital_period_minutes(a_m):
    return 2 * math.pi * math.sqrt(a_m ** 3 / mu) / 60


def apply_switch_fault(commanded, t_min, failure_mode, failure_time_min):
    if t_min < failure_time_min:
        return commanded
    if failure_mode == "stuck_on":
        return True
    if failure_mode == "stuck_off":
        return False
    return commanded


def lag_step(prev, target, dt, tau):
    return target + (prev - target) * math.exp(-dt / max(tau, 1e-12))


def simulate_subsystem(failure_mode, failure_time_min, illum, time_min, dt_min, seed=42):
    """Direct port of src/simulateCubeSatSubsystem.m"""
    N = len(time_min)
    rng = np.random.default_rng(seed)
    solarADC_true = 120 + (900 - 120) * illum
    solarADC = solarADC_true + 8 * rng.standard_normal(N)
    isEclipse = illum < 0.5

    railV = np.zeros(N)
    currentmA = np.zeros(N)
    tempC = np.zeros(N)
    modeName = [""] * N

    tauThermalMin = 30.0
    tauRailMin = 0.10
    tauCurrentMin = 0.10

    tempC[0] = 50 + 0.3 * rng.standard_normal()
    commandedRail = False
    actualRail = False
    eclipseLatched = False
    thermalLatched = False
    modeName[0] = "BOOT"
    nextControlMin = dt_min

    for k in range(N):
        if k > 0:
            sunTargetTemp = 130.0 if actualRail else 75.0
            targetTemp = illum[k - 1] * sunTargetTemp + (1 - illum[k - 1]) * (-40.0)
            tempC[k] = lag_step(tempC[k - 1], targetTemp, dt_min, tauThermalMin)
            tempC[k] += 0.3 * rng.standard_normal()

        actualRail = apply_switch_fault(commandedRail, time_min[k], failure_mode, failure_time_min)

        if k == 0:
            pass
        elif time_min[k] >= nextControlMin:
            eclipseDecision = (solarADC[k] < 650) if eclipseLatched else (solarADC[k] <= 500)
            if eclipseDecision:
                eclipseLatched = True
                commandedRail = False
                actualRail = apply_switch_fault(False, time_min[k], failure_mode, failure_time_min)
                modeName[k] = "BACKUP SAFE" if actualRail else "ECLIPSE SLEEP"
                nextControlMin = time_min[k] + 1
            else:
                eclipseLatched = False
                thermalDecision = (tempC[k] > 100) if thermalLatched else (tempC[k] >= 120)
                if thermalDecision:
                    thermalLatched = True
                    commandedRail = False
                    actualRail = apply_switch_fault(False, time_min[k], failure_mode, failure_time_min)
                    modeName[k] = "BACKUP SAFE" if actualRail else "THERMAL PROTECT"
                    nextControlMin = time_min[k] + 1
                else:
                    thermalLatched = False
                    commandedRail = True
                    actualRail = apply_switch_fault(True, time_min[k], failure_mode, failure_time_min)
                    if not actualRail:
                        modeName[k] = "BACKUP SAFE"
                        nextControlMin = time_min[k] + 1
                    else:
                        modeName[k] = "PAYLOAD ON"
                        nextControlMin = time_min[k] + dt_min
        else:
            modeName[k] = modeName[k - 1]

        targetRailV = 3.3 if actualRail else 0.0
        if modeName[k] == "PAYLOAD ON":
            targetCurrent = 40.1
        elif modeName[k] == "BACKUP SAFE" and actualRail:
            targetCurrent = 5.11
        else:
            targetCurrent = 0.011

        if k == 0:
            railV[k] = targetRailV
            currentmA[k] = targetCurrent
        else:
            railV[k] = lag_step(railV[k - 1], targetRailV, dt_min, tauRailMin)
            currentmA[k] = lag_step(currentmA[k - 1], targetCurrent, dt_min, tauCurrentMin)

    return dict(timeMin=np.array(time_min), illumFrac=illum, tempC=tempC,
                currentmA=currentmA, modeName=np.array(modeName), railV=railV)


# ---------------------------------------------------------------------------
# Default config (applyDefaults in simulateCubeSatMissionPower.m, merged with
# scenarioConfig()'s shared block in RUN_FULL_MISSION_POWER_METRICS.m)
# ---------------------------------------------------------------------------
def base_cfg():
    return dict(
        powerManagementEnabled=True,
        missionDurationDays=365,
        missionStepSeconds=300,
        initialSOC=0.85,
        socMin=0.20, socMax=0.90,
        batteryNominalCapacityWh=24.0,
        batteryInitialTempC=22.0, batteryBaseTempC=18.0, batterySunHeatC=5.0,
        batteryLoadHeatCoeffCperW=0.40, batteryOrbitTempCoupling=0.035,
        batteryThermalTauMin=55.0, batteryReferenceTempC=25.0, batteryQ10=2.0,
        batteryReferenceCycleLifeEFC=5500, batteryCycleFadeAtReference=0.20,
        batteryCalendarFadePerYear=0.010, batteryMaxPermanentFade=0.45,
        batteryMinHealthFloor=0.55, referenceDOD=0.30, minimumDODForAging=0.03,
        dodStressExponent=1.55, minDODStressFactor=0.15, referenceCRate=0.20,
        cRateStressGain=0.60, highSOCStressThreshold=0.85, highSOCCalendarStressGain=1.10,
        lowSOCStressThreshold=0.15, lowSOCCalendarStressGain=1.10,
        batteryColdCapacityLossPerC=0.0045, batteryHotCapacityLossPerC=0.0020,
        batteryMinTempCapacityFactor=0.70, batteryMaxTempCapacityFactor=1.02,
        batteryNominalChargeEfficiency=0.94, batteryNominalDischargeEfficiency=0.96,
        batteryMinEfficiency=0.82, targetOrbitDOD=0.30,
        solarNominalPowerW=10.5, sunPointingFactor=0.82, mpptEfficiency=0.92,
        solarRadiationDegradationPerYear=0.018, solarThermalCycleFadePerHalfCycle=3.5e-8,
        solarMaxPermanentFade=0.30, solarMinHealthFloor=0.70,
        panelReferenceTempC=25.0, panelSizingTempC=45.0, panelPowerTempCoeffPerC=-0.0032,
        panelMinTempDerate=0.70, panelMaxTempDerate=1.05, panelInitialTempC=0.0,
        panelEclipseTempC=-30.0, panelSunTempC=50.0, panelThermalTauMin=10.0,
        panelLoadHeatCoeffCperW=0.05, panelCycleReferenceDeltaC=75.0,
        eclipseThreshold=0.5,
        powerBootW=2.0, powerPayloadOnW=4.2, powerEclipseSleepW=0.75,
        powerThermalProtectW=1.05, powerBackupSafeW=0.60, powerNoManagementW=5.0,
        noManagementPayloadCurrentmA=40.1, noManagementEclipsePenaltyW=0.30,
        payloadRailScale=1.0, epsDistributionEfficiency=0.90,
        eolBatteryHealthLimit=0.80, eolSolarHealthLimit=0.80,
        thermalWarningC=45.0, thermalLimitC=60.0, unmetEnergyToleranceWh=1.0e-3,
    )


def scenario_config(name, duration_days):
    cfg = base_cfg()
    cfg["scenarioName"] = name
    cfg["missionDurationDays"] = duration_days

    if name == "Managed EPS solution":
        cfg["powerManagementEnabled"] = True
        cfg["scenarioRole"] = "managed"
        cfg["socMin"], cfg["socMax"] = 0.20, 0.90
    elif name == "Conventional CubeSat EPS":
        cfg["powerManagementEnabled"] = True
        cfg["scenarioRole"] = "conventional"
        cfg["socMin"], cfg["socMax"] = 0.15, 0.95
        cfg["epsDistributionEfficiency"] = 0.88
        cfg["powerPayloadOnW"] = 4.85
        cfg["powerEclipseSleepW"] = 2.15
        cfg["powerThermalProtectW"] = 1.55
        cfg["powerBackupSafeW"] = 1.20
        cfg["batteryLoadHeatCoeffCperW"] = 0.50
        cfg["batteryCalendarFadePerYear"] = 0.012
        cfg["highSOCCalendarStressGain"] = 1.35
        cfg["lowSOCCalendarStressGain"] = 1.30
    else:
        cfg["powerManagementEnabled"] = False
        cfg["scenarioRole"] = "stress-test"
        cfg["socMin"], cfg["socMax"] = 0.05, 1.00
        cfg["epsDistributionEfficiency"] = 0.88
        cfg["batteryLoadHeatCoeffCperW"] = 0.55
        cfg["batteryCalendarFadePerYear"] = 0.013
        cfg["highSOCCalendarStressGain"] = 1.60
        cfg["lowSOCCalendarStressGain"] = 1.50
    return cfg


def spacecraft_load_power_w(mode_name, payload_current_mA, illum_frac, cfg):
    payloadRailPowerW = cfg["payloadRailScale"] * 3.3 * payload_current_mA / 1000
    if not cfg["powerManagementEnabled"]:
        payloadRailPowerW = cfg["payloadRailScale"] * 3.3 * max(payload_current_mA, cfg["noManagementPayloadCurrentmA"]) / 1000
        eclipsePenaltyW = cfg["noManagementEclipsePenaltyW"] * (1.0 if illum_frac < cfg["eclipseThreshold"] else 0.0)
        return cfg["powerNoManagementW"] + payloadRailPowerW + eclipsePenaltyW
    if mode_name == "BOOT":
        return cfg["powerBootW"]
    elif mode_name == "PAYLOAD ON":
        return cfg["powerPayloadOnW"] + payloadRailPowerW
    elif mode_name == "ECLIPSE SLEEP":
        return cfg["powerEclipseSleepW"]
    elif mode_name == "THERMAL PROTECT":
        return cfg["powerThermalProtectW"]
    elif mode_name == "BACKUP SAFE":
        return cfg["powerBackupSafeW"] + 0.25 * payloadRailPowerW
    else:
        return cfg["powerBackupSafeW"]


def estimate_eps_power_budget(orbit, cfg, design_life_days):
    time_min = orbit["timeMin"]
    illum = orbit["illumFrac"]
    mode = orbit["modeName"]
    payload_mA = orbit["currentmA"]
    N = len(time_min)

    dtHr = np.append(np.diff(time_min), 0) / 60.0
    sunlit = illum >= cfg["eclipseThreshold"]
    eclipseMask = ~sunlit

    loadW = np.array([spacecraft_load_power_w(mode[k], payload_mA[k], illum[k], cfg) for k in range(N)])

    daylightHours = np.sum(dtHr[sunlit])
    eclipseHours = np.sum(dtHr[eclipseMask])
    orbitHours = daylightHours + eclipseHours

    dayLoadW = np.sum(loadW[sunlit] * dtHr[sunlit]) / max(daylightHours, 1e-12)
    eclipseLoadW = np.sum(loadW[eclipseMask] * dtHr[eclipseMask]) / max(eclipseHours, 1e-12)

    etaDirect = max(0.01, min(1.0, cfg["epsDistributionEfficiency"]))
    etaStorage = max(0.01, min(1.0, cfg["epsDistributionEfficiency"] *
                                cfg["batteryNominalChargeEfficiency"] * cfg["batteryNominalDischargeEfficiency"]))

    requiredEOLSunPowerW = ((eclipseLoadW * eclipseHours / etaStorage) +
                            (dayLoadW * daylightHours / etaDirect)) / max(daylightHours, 1e-12)

    designYears = design_life_days / 365.25
    orbitsPerDay = 24 / max(orbitHours, 1e-12)
    thermalHalfCycles = 2 * orbitsPerDay * design_life_days
    radiationFade = cfg["solarRadiationDegradationPerYear"] * designYears
    thermalCycleFade = cfg["solarThermalCycleFadePerHalfCycle"] * thermalHalfCycles
    solarHealthEOL = max(cfg["solarMinHealthFloor"], 1 - min(cfg["solarMaxPermanentFade"], radiationFade + thermalCycleFade))

    panelTempDerate = 1 + cfg["panelPowerTempCoeffPerC"] * (cfg["panelSizingTempC"] - cfg["panelReferenceTempC"])
    panelTempDerate = max(cfg["panelMinTempDerate"], min(cfg["panelMaxTempDerate"], panelTempDerate))

    generationFactorEOL = cfg["sunPointingFactor"] * cfg["mpptEfficiency"] * panelTempDerate * solarHealthEOL
    requiredSolarBOLW = requiredEOLSunPowerW / max(generationFactorEOL, 1e-12)

    eclipseEnergyWh = eclipseLoadW * eclipseHours / max(cfg["batteryNominalDischargeEfficiency"], 1e-12)
    requiredBatteryWhAtTargetDOD = eclipseEnergyWh / max(cfg["targetOrbitDOD"], 1e-12)
    installedBatteryMarginPct = 100 * (cfg["batteryNominalCapacityWh"] / requiredBatteryWhAtTargetDOD - 1)

    installedSolarBOLW = cfg["solarNominalPowerW"]
    installedSolarMarginPct = 100 * (installedSolarBOLW / requiredSolarBOLW - 1)

    return dict(daylightHours=daylightHours, eclipseHours=eclipseHours, orbitHours=orbitHours,
                dayLoadW=dayLoadW, eclipseLoadW=eclipseLoadW,
                requiredSolarBOLW=requiredSolarBOLW, installedSolarBOLW=installedSolarBOLW,
                installedSolarMarginPct=installedSolarMarginPct,
                requiredBatteryWhAtTargetDOD=requiredBatteryWhAtTargetDOD,
                installedBatteryMarginPct=installedBatteryMarginPct)


def battery_temp_capacity_factor(tempC, cfg):
    coldLoss = cfg["batteryColdCapacityLossPerC"] * max(0, cfg["batteryReferenceTempC"] - tempC)
    hotLoss = cfg["batteryHotCapacityLossPerC"] * max(0, tempC - cfg["batteryReferenceTempC"])
    f = 1 - coldLoss - hotLoss
    return max(cfg["batteryMinTempCapacityFactor"], min(cfg["batteryMaxTempCapacityFactor"], f))


def battery_charge_eff(tempC, cfg):
    tempPenalty = 0.0025 * abs(tempC - cfg["batteryReferenceTempC"])
    return max(cfg["batteryMinEfficiency"], cfg["batteryNominalChargeEfficiency"] - tempPenalty)


def battery_discharge_eff(tempC, cfg):
    tempPenalty = 0.0018 * abs(tempC - cfg["batteryReferenceTempC"])
    return max(cfg["batteryMinEfficiency"], cfg["batteryNominalDischargeEfficiency"] - tempPenalty)


def simulate_mission_power(orbit, cfg):
    dtMin = cfg["missionStepSeconds"] / 60.0
    endMin = cfg["missionDurationDays"] * 24 * 60
    timeMin = np.arange(0, endMin + 1e-9, dtMin)
    if timeMin[-1] < endMin:
        timeMin = np.append(timeMin, endMin)
    N = len(timeMin)
    dtHr = np.append([0], np.diff(timeMin)) / 60.0
    dtYears = dtHr / (24 * 365.25)

    orbitPeriodMin = orbit["timeMin"][-1]
    phaseMin = np.mod(timeMin, orbitPeriodMin)

    illumFrac = np.interp(phaseMin, orbit["timeMin"], orbit["illumFrac"])
    payloadCurrentmA = np.interp(phaseMin, orbit["timeMin"], orbit["currentmA"])
    # nearest-mode lookup
    phaseIdx = np.clip(np.round(np.interp(phaseMin, orbit["timeMin"], np.arange(len(orbit["timeMin"])))).astype(int),
                        0, len(orbit["modeName"]) - 1)
    modeName = orbit["modeName"][phaseIdx]

    soc = np.zeros(N)
    storedWh = np.zeros(N)
    capacityHealth = np.zeros(N)
    tempCapacityFactor = np.zeros(N)
    availableCapacityWh = np.zeros(N)
    batteryTempC = np.zeros(N)
    panelTempC = np.zeros(N)
    solarHealth = np.zeros(N)
    generatedW = np.zeros(N)
    loadW = np.zeros(N)
    consumedW = np.zeros(N)
    netBatteryW = np.zeros(N)
    chargeWh = np.zeros(N)
    dischargeWh = np.zeros(N)
    unmetWh = np.zeros(N)
    excessWh = np.zeros(N)
    cumulativeGeneratedWh = np.zeros(N)
    cumulativeConsumedWh = np.zeros(N)
    cumulativeUnmetWh = np.zeros(N)
    cumulativeExcessWh = np.zeros(N)
    equivalentFullCycles = np.zeros(N)
    weightedCycleDamageEFC = np.zeros(N)
    orbitDepthOfDischarge = np.zeros(N)
    instantaneousDOD = np.zeros(N)
    batteryCycleFade = np.zeros(N)
    batteryCalendarFade = np.zeros(N)
    batteryC_Rate = np.zeros(N)
    solarRadiationFade = np.zeros(N)
    solarThermalCycleFade = np.zeros(N)
    solarThermalCycleCount = np.zeros(N)
    powerMarginW = np.zeros(N)

    capacityHealth[0] = 1.0
    solarHealth[0] = 1.0
    batteryTempC[0] = cfg["batteryInitialTempC"]
    panelTempC[0] = cfg["panelInitialTempC"]
    tempCapacityFactor[0] = battery_temp_capacity_factor(batteryTempC[0], cfg)
    availableCapacityWh[0] = cfg["batteryNominalCapacityWh"] * capacityHealth[0] * tempCapacityFactor[0]
    soc[0] = max(cfg["socMin"], min(cfg["socMax"], cfg["initialSOC"]))
    storedWh[0] = soc[0] * availableCapacityWh[0]
    instantaneousDOD[0] = max(0, cfg["socMax"] - soc[0])

    previousSunlit = illumFrac[0] >= cfg["eclipseThreshold"]
    currentOrbit = math.floor(timeMin[0] / orbitPeriodMin) + 1
    orbitSocMin = soc[0]
    orbitSocMax = soc[0]

    for k in range(N):
        if k > 0:
            elapsedOrbit = math.floor(timeMin[k] / orbitPeriodMin) + 1
            if elapsedOrbit != currentOrbit:
                orbitDepth = max(0, orbitSocMax - orbitSocMin)
                idxPrevOrbit = (np.floor(timeMin / orbitPeriodMin) + 1) == currentOrbit
                orbitDepthOfDischarge[idxPrevOrbit] = orbitDepth
                currentOrbit = elapsedOrbit
                orbitSocMin = soc[k - 1]
                orbitSocMax = soc[k - 1]

        loadW[k] = spacecraft_load_power_w(modeName[k], payloadCurrentmA[k], illumFrac[k], cfg)
        consumedW[k] = loadW[k] / cfg["epsDistributionEfficiency"]

        if k == 0:
            generatedW[k] = cfg["solarNominalPowerW"] * cfg["sunPointingFactor"] * illumFrac[k] * solarHealth[k] * cfg["mpptEfficiency"]
            netBatteryW[k] = generatedW[k] - consumedW[k]
            powerMarginW[k] = netBatteryW[k]
            continue

        panelTargetC = (cfg["panelEclipseTempC"] + (cfg["panelSunTempC"] - cfg["panelEclipseTempC"]) * illumFrac[k] +
                         cfg["panelLoadHeatCoeffCperW"] * loadW[k])
        panelTempC[k] = lag_step(panelTempC[k - 1], panelTargetC, dtHr[k] * 60, cfg["panelThermalTauMin"])

        orbitTempC_k = np.interp(phaseMin[k], orbit["timeMin"], orbit["tempC"])
        batteryTargetC = (cfg["batteryBaseTempC"] + cfg["batterySunHeatC"] * illumFrac[k] +
                           cfg["batteryLoadHeatCoeffCperW"] * loadW[k] +
                           cfg["batteryOrbitTempCoupling"] * (orbitTempC_k - cfg["batteryBaseTempC"]))
        batteryTempC[k] = lag_step(batteryTempC[k - 1], batteryTargetC, dtHr[k] * 60, cfg["batteryThermalTauMin"])

        tempCapacityFactor[k] = battery_temp_capacity_factor(batteryTempC[k], cfg)
        availableCapacityWh[k] = cfg["batteryNominalCapacityWh"] * capacityHealth[k - 1] * tempCapacityFactor[k]

        storedWh[k] = min(storedWh[k - 1], cfg["socMax"] * availableCapacityWh[k])
        storedWh[k] = max(cfg["socMin"] * availableCapacityWh[k], storedWh[k])
        soc[k] = storedWh[k] / max(availableCapacityWh[k], 1e-12)

        panelTempDerate = 1 + cfg["panelPowerTempCoeffPerC"] * (panelTempC[k] - cfg["panelReferenceTempC"])
        panelTempDerate = max(cfg["panelMinTempDerate"], min(cfg["panelMaxTempDerate"], panelTempDerate))
        generatedW[k] = (cfg["solarNominalPowerW"] * cfg["sunPointingFactor"] * illumFrac[k] *
                         solarHealth[k - 1] * panelTempDerate * cfg["mpptEfficiency"])

        netBatteryW[k] = generatedW[k] - consumedW[k]
        powerMarginW[k] = netBatteryW[k]

        chargeEff = battery_charge_eff(batteryTempC[k], cfg)
        dischargeEff = battery_discharge_eff(batteryTempC[k], cfg)

        if netBatteryW[k] >= 0:
            requestedChargeWh = netBatteryW[k] * dtHr[k] * chargeEff
            headroomWh = max(0, (cfg["socMax"] - soc[k]) * availableCapacityWh[k])
            chargeWh[k] = min(requestedChargeWh, headroomWh)
            excessWh[k] = max(0, requestedChargeWh - chargeWh[k])
            storedWh[k] = storedWh[k] + chargeWh[k]
        else:
            requestedDischargeWh = -netBatteryW[k] * dtHr[k] / dischargeEff
            usableWh = max(0, (soc[k] - cfg["socMin"]) * availableCapacityWh[k])
            dischargeWh[k] = min(requestedDischargeWh, usableWh)
            unmetWh[k] = max(0, requestedDischargeWh - dischargeWh[k])
            storedWh[k] = storedWh[k] - dischargeWh[k]

        soc[k] = max(0, min(cfg["socMax"], storedWh[k] / max(availableCapacityWh[k], 1e-12)))
        storedWh[k] = soc[k] * availableCapacityWh[k]
        soc[k] = max(cfg["socMin"], soc[k])
        storedWh[k] = soc[k] * availableCapacityWh[k]
        instantaneousDOD[k] = max(0, cfg["socMax"] - soc[k])
        orbitSocMin = min(orbitSocMin, soc[k])
        orbitSocMax = max(orbitSocMax, soc[k])

        movedWh = chargeWh[k] + dischargeWh[k]
        equivalentFullCycles[k] = equivalentFullCycles[k - 1] + movedWh / (2 * cfg["batteryNominalCapacityWh"])

        dodForStress = max(cfg["minimumDODForAging"], instantaneousDOD[k])
        dodStress = max(cfg["minDODStressFactor"], (dodForStress / cfg["referenceDOD"]) ** cfg["dodStressExponent"])

        batteryC_Rate[k] = abs(netBatteryW[k]) / max(cfg["batteryNominalCapacityWh"], 1e-12)
        cRateStress = 1 + cfg["cRateStressGain"] * max(0, batteryC_Rate[k] - cfg["referenceCRate"])
        tempAccel = cfg["batteryQ10"] ** ((batteryTempC[k] - cfg["batteryReferenceTempC"]) / 10)

        dWeightedEFC = dischargeWh[k] / cfg["batteryNominalCapacityWh"] * dodStress * cRateStress
        weightedCycleDamageEFC[k] = weightedCycleDamageEFC[k - 1] + dWeightedEFC
        dCycleFade = cfg["batteryCycleFadeAtReference"] * dWeightedEFC / cfg["batteryReferenceCycleLifeEFC"] * tempAccel

        highSOCStress = 1 + cfg["highSOCCalendarStressGain"] * max(0, soc[k] - cfg["highSOCStressThreshold"])
        lowSOCStress = 1 + cfg["lowSOCCalendarStressGain"] * max(0, cfg["lowSOCStressThreshold"] - soc[k])
        dCalendarFade = cfg["batteryCalendarFadePerYear"] * dtYears[k] * tempAccel * highSOCStress * lowSOCStress

        batteryCycleFade[k] = min(cfg["batteryMaxPermanentFade"], batteryCycleFade[k - 1] + dCycleFade)
        batteryCalendarFade[k] = min(cfg["batteryMaxPermanentFade"], batteryCalendarFade[k - 1] + dCalendarFade)
        totalBatteryFade = min(cfg["batteryMaxPermanentFade"], batteryCycleFade[k] + batteryCalendarFade[k])
        capacityHealth[k] = max(1 - totalBatteryFade, cfg["batteryMinHealthFloor"])

        solarRadiationFade[k] = min(cfg["solarMaxPermanentFade"],
                                     solarRadiationFade[k - 1] + cfg["solarRadiationDegradationPerYear"] * dtYears[k])

        isSunlit = illumFrac[k] >= cfg["eclipseThreshold"]
        if isSunlit != previousSunlit:
            solarThermalCycleCount[k] = solarThermalCycleCount[k - 1] + 0.5
            dPanelCycleFade = cfg["solarThermalCycleFadePerHalfCycle"] * (
                1 + abs(panelTempC[k] - panelTempC[k - 1]) / cfg["panelCycleReferenceDeltaC"])
            solarThermalCycleFade[k] = min(cfg["solarMaxPermanentFade"], solarThermalCycleFade[k - 1] + dPanelCycleFade)
            previousSunlit = isSunlit
        else:
            solarThermalCycleCount[k] = solarThermalCycleCount[k - 1]
            solarThermalCycleFade[k] = solarThermalCycleFade[k - 1]

        totalSolarFade = min(cfg["solarMaxPermanentFade"], solarRadiationFade[k] + solarThermalCycleFade[k])
        solarHealth[k] = max(1 - totalSolarFade, cfg["solarMinHealthFloor"])

        cumulativeGeneratedWh[k] = cumulativeGeneratedWh[k - 1] + generatedW[k] * dtHr[k]
        cumulativeConsumedWh[k] = cumulativeConsumedWh[k - 1] + consumedW[k] * dtHr[k]
        cumulativeUnmetWh[k] = cumulativeUnmetWh[k - 1] + unmetWh[k]
        cumulativeExcessWh[k] = cumulativeExcessWh[k - 1] + excessWh[k]

    orbitDepth = max(0, orbitSocMax - orbitSocMin)
    idxLastOrbit = (np.floor(timeMin / orbitPeriodMin) + 1) == currentOrbit
    orbitDepthOfDischarge[idxLastOrbit] = orbitDepth

    return dict(timeMin=timeMin, soc=soc, capacityHealth=capacityHealth, solarHealth=solarHealth,
                batteryTempC=batteryTempC, panelTempC=panelTempC, generatedW=generatedW, consumedW=consumedW,
                unmetWh=unmetWh, excessWh=excessWh, cumulativeUnmetWh=cumulativeUnmetWh,
                cumulativeGeneratedWh=cumulativeGeneratedWh, cumulativeConsumedWh=cumulativeConsumedWh,
                equivalentFullCycles=equivalentFullCycles, weightedCycleDamageEFC=weightedCycleDamageEFC,
                orbitDepthOfDischarge=orbitDepthOfDischarge, instantaneousDOD=instantaneousDOD,
                batteryC_Rate=batteryC_Rate, powerMarginW=powerMarginW, modeName=modeName, illumFrac=illumFrac)


# ---------------------------------------------------------------------------
if __name__ == "__main__":
    altitude_m = 500e3
    a = Re + altitude_m
    orbitMinutes = true_orbital_period_minutes(a)
    sampleTimeSeconds = 60
    dtMin = sampleTimeSeconds / 60
    timeMin = np.arange(0, orbitMinutes + 1e-9, dtMin)

    startTime = datetime(2026, 6, 1, 10, 0, 0, tzinfo=timezone.utc)
    illum, betaDeg, eclipseFrac, _ = xc.analytic_illum_profile(startTime, timeMin, 51.6, 31.0, altitude_m, ramp_min=0.35)
    orbitSim = simulate_subsystem("none", 0.95 * orbitMinutes, illum, timeMin, dtMin, seed=42)

    print(f"Orbit period: {orbitMinutes:.3f} min, beta={betaDeg:.2f} deg, eclipse frac={eclipseFrac*100:.1f}%")

    designLifeDays = 1095
    designMargin = 0.18
    names = ["Managed EPS solution", "Conventional CubeSat EPS", "Same-array no-control stress test"]

    sizingCfgs = {n: scenario_config(n, designLifeDays) for n in names}
    sizingBudgets = {n: estimate_eps_power_budget(orbitSim, sizingCfgs[n], designLifeDays) for n in names}

    installedManagedW = sizingBudgets["Managed EPS solution"]["requiredSolarBOLW"] * (1 + designMargin)
    installedConventionalW = sizingBudgets["Conventional CubeSat EPS"]["requiredSolarBOLW"] * (1 + designMargin)
    installedByScenario = {
        "Managed EPS solution": installedManagedW,
        "Conventional CubeSat EPS": installedConventionalW,
        "Same-array no-control stress test": installedManagedW,
    }

    print("\nSizing:")
    for n in names:
        print(f"  {n:38s} required BOL = {sizingBudgets[n]['requiredSolarBOLW']:6.2f} W  installed = {installedByScenario[n]:6.2f} W"
              f"  margin = {100*(installedByScenario[n]/sizingBudgets[n]['requiredSolarBOLW']-1):+6.1f}%"
              f"  battery margin = {sizingBudgets[n]['installedBatteryMarginPct']:+6.1f}%")

    lifeSpans = [30, 90, 180, 365, 730, 1095]
    print("\nFull sweep (checking for NaN / out-of-band SOC / runaway temps / negative health):")
    print(f"{'Scenario':38s} {'Days':>5s} {'minSOC%':>8s} {'maxSOC%':>8s} {'battHealth%':>11s} {'solarHealth%':>12s}"
          f" {'maxBattT':>9s} {'minBattT':>9s} {'unmetWh':>10s} {'NaN?':>5s}")

    anomalies = []
    for n in names:
        for d in lifeSpans:
            cfg = scenario_config(n, d)
            cfg["solarNominalPowerW"] = installedByScenario[n]
            mission = simulate_mission_power(orbitSim, cfg)

            hasNaN = (np.any(np.isnan(mission["soc"])) or np.any(np.isnan(mission["batteryTempC"])) or
                      np.any(np.isnan(mission["capacityHealth"])))
            minSOC = 100 * np.min(mission["soc"])
            maxSOC = 100 * np.max(mission["soc"])
            battHealth = 100 * mission["capacityHealth"][-1]
            solarHealth = 100 * mission["solarHealth"][-1]
            maxT = np.max(mission["batteryTempC"])
            minT = np.min(mission["batteryTempC"])
            unmet = mission["cumulativeUnmetWh"][-1]

            print(f"{n:38s} {d:5d} {minSOC:8.2f} {maxSOC:8.2f} {battHealth:11.2f} {solarHealth:12.2f}"
                  f" {maxT:9.2f} {minT:9.2f} {unmet:10.3f} {str(hasNaN):>5s}")

            socFloorPct = 100 * cfg["socMin"]
            socCeilPct = 100 * cfg["socMax"]
            if hasNaN:
                anomalies.append(f"{n} d={d}: NaN detected")
            if minSOC < socFloorPct - 0.01 or maxSOC > socCeilPct + 0.01:
                anomalies.append(f"{n} d={d}: SOC {minSOC:.2f}-{maxSOC:.2f}% outside configured band [{socFloorPct:.1f},{socCeilPct:.1f}]%")
            if battHealth < 100 * cfg["batteryMinHealthFloor"] - 0.01:
                anomalies.append(f"{n} d={d}: battery health {battHealth:.2f}% below floor")
            if maxT > 80 or minT < -50:
                anomalies.append(f"{n} d={d}: battery temp out of plausible range ({minT:.1f} to {maxT:.1f} C)")

    print("\nAnomalies found:" if anomalies else "\nNo numerical anomalies found (no NaNs, all bounds respected).")
    for a_ in anomalies:
        print("  -", a_)
