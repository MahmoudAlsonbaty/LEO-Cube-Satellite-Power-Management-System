function tf = viewerApiAvailable()
% viewerApiAvailable
% -------------------------------------------------------------------------
% satelliteScenarioViewer is a satelliteScenario class method in current
% MATLAB installations. A valid @satelliteScenario/satelliteScenarioViewer.p
% path from which() is enough to attempt satelliteScenarioViewer(sc,...),
% even when exist('satelliteScenarioViewer','file') reports false because
% the method lives in an @-folder rather than as a top-level function.
%
% V23 (independent audit): de-duplicated from two identical local copies --
% see scenarioApiAvailable.m for why.

    p = which('satelliteScenarioViewer');
    tf = functionAvailable('satelliteScenarioViewer') || ~isempty(p) || ...
         functionAvailable('matlabshared.satellitescenario.ScenarioViewer');
end
