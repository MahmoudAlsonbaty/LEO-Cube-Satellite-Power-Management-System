function info = ensureAerospaceEphemerisReady(verbose)
% ensureAerospaceEphemerisReady
% -------------------------------------------------------------------------
% Runtime diagnostic/repair helper for the Aerospace Toolbox ephemeris data
% dependency used by planetEphemeris(), eclipse()/eclipseStatus(), and the
% detailed satelliteScenarioViewer rendering path.
%
% IMPORTANT DISTINCTION:
%   aerospaceephemerisdata.mlpkginstall is only an INSTALLER descriptor. It
%   is not the ephemeris database itself and adding that .mlpkginstall file
%   to the MATLAB path will not make planetEphemeris() work. MATLAB must
%   install/register the Add-On first, then refresh its toolbox cache/path.
%
% This helper does three things before the project opens the viewer:
%   1. Checks that the expected toolbox functions exist.
%   2. Refreshes MATLAB's toolbox cache once (safe and quick) because a
%      correctly installed data Add-On can remain invisible after startup
%      until rehash toolboxcache is called.
%   3. Validates the data path with planetEphemeris() first, then validates
%      the scenario eclipse path with eclipse()/eclipseStatus().
%
% Output fields most useful to the caller:
%   info.ephemerisAvailable       true when planetEphemeris can see data
%   info.eclipseAvailable         true when eclipseStatus works too
%   info.viewerShouldUseFallback  true when the 3-D viewer may fail and the
%                                 dashboard should degrade gracefully

    if nargin < 1
        verbose = true;
    end

    info = struct();
    info.matlabVersion = version;
    % V15: use method-aware checks. satelliteScenarioViewer is commonly a
    % method stored under @satelliteScenario, so exist(name,'file') alone can
    % return false even when which(name) prints a valid method path.
    info.hasSatelliteScenario = scenarioApiAvailable();
    info.hasSatelliteScenarioViewer = viewerApiAvailable();
    info.hasPlanetEphemeris = functionAvailable('planetEphemeris');
    info.hasAeroDataPackage = exist('aeroDataPackage','file') == 2;
    info.hasEclipse = exist('eclipse','file') == 2;
    info.hasEclipseStatus = exist('eclipseStatus','file') == 2;
    info.aeroDataPackagePath = which('aeroDataPackage');
    info.planetEphemerisPath = which('planetEphemeris');
    info.satelliteScenarioPath = which('satelliteScenario');
    info.satelliteScenarioViewerPath = which('satelliteScenarioViewer');
    info.aerospaceLicenseAvailable = testLicense('Aerospace_Toolbox');
    info.satcomLicenseAvailable = testLicense('Satellite_Communications_Toolbox');
    info.installedEphemerisAddOn = false;
    info.installedEphemerisAddOnName = '';
    info.cacheRefreshed = false;
    info.ephemerisAvailable = false;
    info.eclipseAvailable = false;
    info.viewerShouldUseFallback = true;
    info.lastEphemerisError = '';
    info.lastEclipseError = '';

    try
        addons = matlab.addons.installedAddons;
        if istable(addons) && any(strcmpi(addons.Properties.VariableNames,'Name'))
            names = string(addons.Name);
            idx = find(contains(lower(names),'ephemeris data for aerospace toolbox') | ...
                       contains(lower(names),'aerospace ephemeris data'), 1, 'first');
            if ~isempty(idx)
                info.installedEphemerisAddOn = true;
                info.installedEphemerisAddOnName = char(names(idx));
            end
        end
    catch
        % Older releases or restricted installations may not expose the
        % add-on table. This is diagnostic only; planetEphemeris() below is
        % the authoritative check.
    end

    if verbose
        fprintf('\nAerospace ephemeris pre-flight check\n');
        fprintf('------------------------------------\n');
        fprintf('MATLAB version:              %s\n', info.matlabVersion);
        fprintf('satelliteScenario:           %s\n', yesNo(info.hasSatelliteScenario));
        fprintf('satelliteScenarioViewer:     %s\n', yesNo(info.hasSatelliteScenarioViewer));
        fprintf('planetEphemeris:             %s\n', yesNo(info.hasPlanetEphemeris));
        fprintf('aeroDataPackage:             %s\n', yesNo(info.hasAeroDataPackage));
        fprintf('Aerospace license test:      %s\n', yesNo(info.aerospaceLicenseAvailable));
        fprintf('SatCom license test:         %s\n', yesNo(info.satcomLicenseAvailable));
        if info.installedEphemerisAddOn
            fprintf('Ephemeris Add-On registered: YES (%s)\n', info.installedEphemerisAddOnName);
        else
            fprintf('Ephemeris Add-On registered: not confirmed by installedAddons\n');
        end
    end

    % First direct data-path test. A numeric Julian date avoids depending on
    % juliandate() while still testing the actual JPL coefficient database.
    info = tryPlanetEphemeris(info);

    % If the Add-On is installed but MATLAB's cached path is stale, the first
    % test can fail even though the data exists. Refresh once, then retry.
    if ~info.ephemerisAvailable
        try
            rehash toolboxcache;
            info.cacheRefreshed = true;
        catch ME
            info.lastEphemerisError = sprintf('%s | rehash toolboxcache failed: %s', ...
                info.lastEphemerisError, ME.message);
        end
        info = tryPlanetEphemeris(info);
    end

    % Validate the exact analysis path used by computeIlluminationProfile.m.
    if info.ephemerisAvailable && info.hasSatelliteScenario && info.hasEclipse && info.hasEclipseStatus
        try
            t0 = datetime(2026,6,27,12,0,0,'TimeZone','UTC');
            scTmp = satelliteScenario(t0, t0+minutes(1), 10);
            satTmp = satellite(scTmp, 6871e3, 0.001, 51.6, 0, 0, 0);
            eclObj = eclipse(satTmp);
            statusTest = eclipseStatus(eclObj, t0); %#ok<NASGU>
            info.eclipseAvailable = true;
        catch ME
            info.eclipseAvailable = false;
            info.lastEclipseError = ME.message;
        end
    end

    % Viewer fallback is required when the ephemeris data is missing OR when
    % the scenario/viewer API itself is truly unavailable. V15 treats a valid
    % @satelliteScenario/satelliteScenarioViewer.p path as available because it
    % is a class method, not a normal top-level function.
    info.viewerShouldUseFallback = ~(info.ephemerisAvailable && info.hasSatelliteScenario && info.hasSatelliteScenarioViewer);

    if verbose
        fprintf('Toolbox cache refreshed:     %s\n', yesNo(info.cacheRefreshed));
        fprintf('Ephemeris data path:         %s\n', yesNo(info.ephemerisAvailable));
        fprintf('eclipse/eclipsestatus path:  %s\n', yesNo(info.eclipseAvailable));
        if ~info.ephemerisAvailable
            fprintf(2, ['\n[EPHEMERIS NOT READY]\n' ...
                'MATLAB can see the Aerospace functions, but it cannot see the installed\n' ...
                'ephemeris database. The project will continue with the analytic\n' ...
                'illumination fallback and, if needed, dashboard-only playback.\n']);
            if ~isempty(info.lastEphemerisError)
                fprintf(2,'Last planetEphemeris error: %s\n', info.lastEphemerisError);
            end
        elseif ~info.hasSatelliteScenario || ~info.hasSatelliteScenarioViewer
            fprintf(2, ['\n[SCENARIO VIEWER NOT AVAILABLE]\n' ...
                'Ephemeris data is READY because planetEphemeris validated. The remaining\n' ...
                'issue is that satelliteScenario and/or satelliteScenarioViewer are not\n' ...
                'visible to this MATLAB session. The project will use analytic orbit +\n' ...
                'dashboard-only playback until the scenario/viewer toolbox path/license\n' ...
                'is restored.\n']);
            fprintf(2,'satelliteScenario path:       %s\n', pathOrMissing(info.satelliteScenarioPath));
            fprintf(2,'satelliteScenarioViewer path: %s\n', pathOrMissing(info.satelliteScenarioViewerPath));
        elseif ~info.eclipseAvailable
            fprintf(2, ['\n[EPHEMERIS READY / ECLIPSE API UNAVAILABLE]\n' ...
                'planetEphemeris can see the data, but eclipseStatus did not validate.\n' ...
                'Illumination will fall back analytically if eclipse() fails.\n']);
            if ~isempty(info.lastEclipseError)
                fprintf(2,'Last eclipseStatus error: %s\n', info.lastEclipseError);
            end
        else
            fprintf('Ephemeris status:            READY\n');
        end
        fprintf('\n');
    end
end

function info = tryPlanetEphemeris(info)
    if ~info.hasPlanetEphemeris
        info.ephemerisAvailable = false;
        info.lastEphemerisError = 'planetEphemeris was not found on the MATLAB path.';
        return;
    end

    try
        % JD 2451545.0 = 2000-01-01 12:00 UTC, safely inside DE405/DE421.
        posTest = planetEphemeris(2451545.0, 'Earth', 'Moon'); %#ok<NASGU>
        info.ephemerisAvailable = true;
        info.lastEphemerisError = '';
    catch ME
        info.ephemerisAvailable = false;
        info.lastEphemerisError = ME.message;
    end
end

% V23 (independent audit): scenarioApiAvailable, viewerApiAvailable, and
% functionAvailable used to be defined as local functions here AND
% (identically) in START_TOOLBOX_VIEWER_WITH_METRICS.m. They are now each
% their own file in src/ (scenarioApiAvailable.m, viewerApiAvailable.m,
% functionAvailable.m), so both callers share one implementation.

function tf = testLicense(featureName)
    try
        tf = license('test',featureName);
    catch
        tf = false;
    end
end

function txt = pathOrMissing(p)
    if isempty(p)
        txt = '<missing>';
    else
        txt = p;
    end
end

function s = yesNo(v)
    if v
        s = 'YES';
    else
        s = 'NO';
    end
end
