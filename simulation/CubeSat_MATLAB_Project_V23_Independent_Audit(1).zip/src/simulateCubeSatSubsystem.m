function sim = simulateCubeSatSubsystem(failureMode, failureTimeMin, illumFrac, timeMin, dtMin, noiseSeed)
% simulateCubeSatSubsystem
% -------------------------------------------------------------------------
% Discrete-time simulation of the CubeSat sensor-payload power-gating
% firmware: eclipse/thermal/payload mode logic, rail switching, and the
% resulting current/temperature telemetry.
%
% WHAT CHANGED IN V12 AND WHY (see docs/Firmware_Issues_and_Fixes.md for
% the full write-up; short version here so the fix travels with the code):
%
% 1. SOLAR INPUT IS NOW CONTINUOUS, NOT A STEP.
%    V11 set solarADC to exactly 120 or exactly 900 with nothing between --
%    an instantaneous jump every eclipse boundary. solarADC is now derived
%    from the continuous illumFrac (0..1) computed by
%    computeIlluminationProfile.m, which is itself either the real
%    Aerospace Toolbox dual-cone eclipse fraction or a smoothed analytic
%    fallback. This also means the existing eclipseLatched hysteresis
%    band (500 ADC to enter, 650 ADC to leave) is no longer DEAD CODE --
%    in V11 solarADC only ever took the values 120 or 900, so a band
%    sitting strictly between them could never actually be exercised.
%    With a continuous signal passing through the band during the
%    transition, the hysteresis now does real work, exactly as a
%    real eclipse-detector comparator with hysteresis would.
%
% 2. RAIL VOLTAGE / CURRENT NO LONGER JUMP INSTANTLY.
%    V11 set railV/currentmA directly to their new value the instant the
%    mode changed -- an instantaneous step with no transient, which is not
%    how a real FET/load-switch + downstream capacitance behaves. V12
%    ramps both toward their commanded target with a short first-order
%    "soft-start / soft-stop" time constant (tauRailMin, tauCurrentMin).
%
% 3. THE LAG DISCRETIZATION IS NOW THE EXACT, UNCONDITIONALLY-STABLE FORM.
%    V11's thermal model used an explicit first-difference update,
%        T(k) = T(k-1) + (target-T(k-1))*dt/tau
%    which is only numerically stable while dt/tau < 2. That was fine for
%    the thermal loop (dt/tau ~ 0.006), but the SAME pattern was the
%    obvious way to write the new soft-start ramps above, and for a
%    realistic few-second soft-start time constant against a ~10 s sample
%    time, dt/tau comfortably exceeds 2 -- which was caught during
%    pre-port validation (see /validation/crosscheck_firmware.py in this
%    delivery): it produced unbounded, sign-flipping, exponentially
%    growing "current" and "voltage" values almost immediately. V12 uses
%    the EXACT discretization of dx/dt = (target-x)/tau,
%        x(k) = target + (x(k-1)-target)*exp(-dt/tau)
%    everywhere a first-order lag is needed (thermal AND the new soft
%    start/stop ramps). This form is unconditionally stable for any
%    tau > 0 and dt > 0, and is also a more accurate discretization of
%    the underlying ODE than the explicit-difference form it replaces.
%
% 4. TELEMETRY NOW CARRIES REALISTIC SENSOR NOISE.
%    V11's current/temperature/solar curves were perfectly noise-free --
%    "too good to be true" smooth, as flagged in the project brief. V12
%    adds small, fixed-seed (reproducible) Gaussian noise to the telemetry
%    channels the firmware actually reads (solarADC, tempC), sized well
%    below the existing hysteresis bands so it improves realism without
%    introducing spurious mode chatter (see docs for the specific sigma
%    values and why they were chosen).
%
% 5. THE "BOOT" MODE IS NOW REACHABLE.
%    In V11, nextControlMin was initialized to 0 and the first sample's
%    time was also 0, so the very first control decision pre-empted the
%    "BOOT" label before it could ever be displayed -- dead code. V12
%    initializes nextControlMin = dtMin so sample 1 is genuinely BOOT and
%    the first real eclipse/thermal/payload decision happens at sample 2,
%    matching a real firmware power-on sequence (rail held off during
%    initialization).
%
% Inputs:
%   failureMode     - "none" | "stuck_on" | "stuck_off"
%   failureTimeMin  - mission time (minutes) after which the fault applies
%   illumFrac       - 1xN illumination fraction from computeIlluminationProfile
%   timeMin         - 1xN mission time vector, minutes
%   dtMin           - sample period, minutes (must match diff(timeMin))
%   noiseSeed       - scalar seed for reproducible telemetry noise
%
% Output: sim struct with fields used by the dashboard (timeMin, isEclipse,
%   illumFrac, solarADC, railV, currentmA, baselineCurrentmA, tempC,
%   modeName, loadW, baselineLoadW, cumBaselineWh, cumImprovedWh, energySavingPct).

    N = numel(timeMin);

    % Reproducible "realistic telemetry noise" -- save/restore the
    % caller's RNG stream so this function has no side effects on any
    % other randomness in the session (good practice for maintainability).
    callerRngState = rng();
    rng(noiseSeed);

    solarADC_true = 120 + (900-120).*illumFrac;
    solarADC = solarADC_true + 8*randn(1,N);          % +/- few-count ADC noise

    isEclipse = illumFrac < 0.5;                      % binary label, UI only

    railV = zeros(1,N);
    currentmA = zeros(1,N);
    tempC = zeros(1,N);
    modeName = strings(1,N);

    tauThermalMin = 30;     % thermal first-order time constant (minutes)
    tauRailMin    = 0.10;   % rail-voltage soft-start/soft-stop (~6 s)
    tauCurrentMin = 0.10;   % current soft-start/soft-stop (~6 s)

    tempC(1) = 50 + 0.3*randn();
    commandedRail = false;
    actualRail = false;
    eclipseLatched = false;
    thermalLatched = false;

    modeName(1) = "BOOT";
    nextControlMin = dtMin;   % first real control decision is sample 2 (see item 5 above)

    for k = 1:N
        if k > 1
            sunTargetTemp = 75;
            if actualRail
                sunTargetTemp = 130;
            end
            % Continuous blend by illumination fraction -- removes the old
            % instantaneous target-temperature jump at the eclipse edge.
            targetTemp = illumFrac(k-1)*sunTargetTemp + (1-illumFrac(k-1))*(-40);
            tempC(k) = targetTemp + (tempC(k-1)-targetTemp)*exp(-dtMin/tauThermalMin);
            tempC(k) = tempC(k) + 0.3*randn();        % measurement noise
        end

        actualRail = applySwitchFault(commandedRail, timeMin(k), failureMode, failureTimeMin);

        if k == 1
            % BOOT frame: rail held off, decision logic not yet engaged.
        elseif timeMin(k) >= nextControlMin
            if eclipseLatched
                eclipseDecision = solarADC(k) < 650;
            else
                eclipseDecision = solarADC(k) <= 500;
            end

            if eclipseDecision
                eclipseLatched = true;
                commandedRail = false;
                actualRail = applySwitchFault(false,timeMin(k),failureMode,failureTimeMin);
                if actualRail
                    modeName(k) = "BACKUP SAFE";
                else
                    modeName(k) = "ECLIPSE SLEEP";
                end
                nextControlMin = timeMin(k) + 1;
            else
                eclipseLatched = false;
                if thermalLatched
                    thermalDecision = tempC(k) > 100;
                else
                    thermalDecision = tempC(k) >= 120;
                end

                if thermalDecision
                    thermalLatched = true;
                    commandedRail = false;
                    actualRail = applySwitchFault(false,timeMin(k),failureMode,failureTimeMin);
                    if actualRail
                        modeName(k) = "BACKUP SAFE";
                    else
                        modeName(k) = "THERMAL PROTECT";
                    end
                    nextControlMin = timeMin(k) + 1;
                else
                    thermalLatched = false;
                    commandedRail = true;
                    actualRail = applySwitchFault(true,timeMin(k),failureMode,failureTimeMin);
                    if ~actualRail
                        modeName(k) = "BACKUP SAFE";
                        nextControlMin = timeMin(k) + 1;
                    else
                        modeName(k) = "PAYLOAD ON";
                        nextControlMin = timeMin(k) + dtMin;
                    end
                end
            end
        else
            modeName(k) = modeName(k-1);
        end

        % V23 (independent audit, scope note -- no behavior change):
        % "voltage regulation logic and brownout protection scenarios" was
        % one of the audit's review items. This model commands rail
        % voltage directly from firmware mode (3.3 V on, 0 V off) through
        % the soft-start/soft-stop lag below -- there is no separate
        % brownout/undervoltage-lockout circuit, because there is no
        % battery terminal-voltage model in this project at all (energy is
        % tracked as a Wh "bucket", not as cell voltage vs. SOC), so there
        % is nothing for a brownout detector to act on. That is a
        % reasonable scope boundary for a power-BUDGET trade study rather
        % than a flight EPS circuit simulator, but worth stating explicitly
        % rather than leaving implicit. Separately: the lag below is
        % mathematically incapable of overshooting past its commanded
        % target. railV(k) = target + (railV(k-1)-target)*exp(-dt/tau) is
        % algebraically w*railV(k-1) + (1-w)*target with w=exp(-dt/tau) in
        % the open interval (0,1) for any dt,tau > 0 -- i.e. always a
        % convex combination of the previous value and the target -- so it
        % can never produce a value outside [0, 3.3] V even transiently.
        if actualRail
            targetRailV = 3.3;
        else
            targetRailV = 0;
        end

        if modeName(k) == "PAYLOAD ON"
            targetCurrent = 40.1;
        elseif modeName(k) == "BACKUP SAFE" && actualRail
            targetCurrent = 5.11;
        else
            targetCurrent = 0.011;
        end

        if k == 1
            railV(k) = targetRailV;
            currentmA(k) = targetCurrent;
        else
            % Exact exponential soft-start / soft-stop (see item 3 above):
            % unconditionally stable, unlike an explicit first-difference
            % update at this dt/tau ratio.
            railV(k) = targetRailV + (railV(k-1)-targetRailV)*exp(-dtMin/tauRailMin);
            currentmA(k) = targetCurrent + (currentmA(k-1)-targetCurrent)*exp(-dtMin/tauCurrentMin);
        end
    end

    rng(callerRngState);   % restore caller's RNG stream

    baselineCurrentmA = 40.1*ones(1,N);

    % V19 POWER-METRICS REWORK:
    % The previous energy metric integrated only the 3.3 V payload rail
    % current, which made the dashboard energy numbers look much too small
    % for a CubeSat EPS. Keep currentmA as the measured payload-rail current
    % for the live current plot, but calculate energy from system-level load
    % power using the same mode assumptions as the full-mission EPS model.
    baselineLoadW = zeros(1,N);
    loadW = zeros(1,N);
    for j = 1:N
        baselineLoadW(j) = noManagementLoadPowerW(baselineCurrentmA(j), illumFrac(j));
        loadW(j) = managedModeLoadPowerW(modeName(j), currentmA(j));
    end

    baselineWh = trapz(timeMin/60,baselineLoadW);
    improvedWh = trapz(timeMin/60,loadW);

    sim = struct();
    sim.timeMin = timeMin;
    sim.illumFrac = illumFrac;
    sim.isEclipse = isEclipse;
    sim.solarADC = solarADC;
    sim.railV = railV;
    sim.currentmA = currentmA;
    sim.baselineCurrentmA = baselineCurrentmA;
    sim.loadW = loadW;
    sim.baselineLoadW = baselineLoadW;
    sim.tempC = tempC;
    sim.modeName = modeName;
    sim.cumBaselineWh = cumtrapz(timeMin/60,baselineLoadW);
    sim.cumImprovedWh = cumtrapz(timeMin/60,loadW);
    sim.energySavingPct = 100*(baselineWh - improvedWh)/baselineWh;
end

function p = managedModeLoadPowerW(modeName, payloadCurrentmA)
    payloadRailPowerW = 3.3*payloadCurrentmA/1000;
    switch string(modeName)
        case "BOOT"
            p = 2.2;
        case "PAYLOAD ON"
            p = 4.6 + payloadRailPowerW;
        case "ECLIPSE SLEEP"
            p = 0.85;
        case "THERMAL PROTECT"
            p = 1.10;
        case "BACKUP SAFE"
            p = 0.65 + 0.25*payloadRailPowerW;
        otherwise
            p = 0.65;
    end
end

function p = noManagementLoadPowerW(payloadCurrentmA, illumFrac)
    payloadRailPowerW = 3.3*payloadCurrentmA/1000;
    eclipsePenaltyW = 0.25 * double(illumFrac < 0.5);
    p = 4.9 + payloadRailPowerW + eclipsePenaltyW;
end

function actual = applySwitchFault(commanded,timeMin,failureMode,failureTimeMin)
    if timeMin < failureTimeMin
        actual = commanded;
        return;
    end

    switch string(failureMode)
        case "none"
            actual = commanded;
        case "stuck_on"
            actual = true;
        case "stuck_off"
            actual = false;
        otherwise
            actual = commanded;
    end
end
