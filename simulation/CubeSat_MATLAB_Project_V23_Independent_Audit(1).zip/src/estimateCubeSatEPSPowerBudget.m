function budget = estimateCubeSatEPSPowerBudget(orbitSim, cfg, designLifeDays)
% estimateCubeSatEPSPowerBudget
% -------------------------------------------------------------------------
% Source-backed CubeSat EPS sizing calculation used by V20.
%
% The model follows the standard orbit-energy-balance sizing idea used in
% spacecraft power budgets:
%
%   Psa = ((Pe*Te/Xe) + (Pd*Td/Xd)) / Td
%
% where Pe/Pd are eclipse/daylight load powers, Te/Td are eclipse/daylight
% durations, Xe is the solar-array -> battery -> load path efficiency during
% eclipse support, and Xd is the solar-array -> load path efficiency during
% daylight support. V20 then converts that required end-of-life daylight
% power into beginning-of-life installed solar power by applying pointing,
% MPPT, panel-temperature, and end-of-life solar-health factors.
%
% This function is intentionally independent of the graphical dashboard. It
% estimates whether the hardware is sized sensibly before a long-duration
% SOC/aging integration is attempted.

    if nargin < 3 || isempty(designLifeDays)
        designLifeDays = cfg.missionDurationDays;
    end

    illumFrac = orbitSim.illumFrac(:)';
    timeMin = orbitSim.timeMin(:)';
    modeName = orbitSim.modeName(:)';
    payloadCurrentmA = orbitSim.currentmA(:)';

    if numel(timeMin) < 2
        error('estimateCubeSatEPSPowerBudget:BadOrbit','orbitSim.timeMin must contain at least two samples.');
    end

    % Segment durations associated with each sample. The final endpoint has
    % zero forward duration so one exact orbit is not over-counted.
    dtHr = [diff(timeMin) 0]/60;
    sunlit = illumFrac >= cfg.eclipseThreshold;
    eclipse = ~sunlit;

    if ~any(sunlit) || ~any(eclipse)
        error('estimateCubeSatEPSPowerBudget:BadIllumination', ...
            'The orbit profile must contain both sunlight and eclipse samples.');
    end

    loadW = zeros(size(timeMin));
    for k = 1:numel(timeMin)
        loadW(k) = localSpacecraftLoadPowerW(modeName(k), payloadCurrentmA(k), illumFrac(k), cfg);
    end

    daylightHours = sum(dtHr(sunlit));
    eclipseHours = sum(dtHr(eclipse));
    orbitHours = daylightHours + eclipseHours;

    dayLoadW = sum(loadW(sunlit).*dtHr(sunlit))/max(daylightHours, eps);
    eclipseLoadW = sum(loadW(eclipse).*dtHr(eclipse))/max(eclipseHours, eps);
    orbitAverageLoadW = sum(loadW.*dtHr)/max(orbitHours, eps);

    % Daylight/direct path and eclipse/storage path efficiencies.  These are
    % not arbitrary graph scalers: they describe where the watts go.  Daylight
    % loads see distribution losses; eclipse loads must additionally pass
    % through charge/discharge storage losses.
    etaDirect = max(0.01, min(1.0, cfg.epsDistributionEfficiency));
    etaStorage = max(0.01, min(1.0, cfg.epsDistributionEfficiency * ...
        cfg.batteryNominalChargeEfficiency * cfg.batteryNominalDischargeEfficiency));

    requiredEOLSunPowerW = ((eclipseLoadW*eclipseHours/etaStorage) + ...
                            (dayLoadW*daylightHours/etaDirect)) / max(daylightHours, eps);

    designYears = designLifeDays/365.25;
    orbitsPerDay = 24/max(orbitHours, eps);
    thermalHalfCycles = 2*orbitsPerDay*designLifeDays;
    radiationFade = cfg.solarRadiationDegradationPerYear*designYears;
    thermalCycleFade = cfg.solarThermalCycleFadePerHalfCycle*thermalHalfCycles;
    solarHealthEOL = max(cfg.solarMinHealthFloor, 1 - min(cfg.solarMaxPermanentFade, radiationFade + thermalCycleFade));

    panelTempDerate = 1 + cfg.panelPowerTempCoeffPerC*(cfg.panelSizingTempC - cfg.panelReferenceTempC);
    panelTempDerate = max(cfg.panelMinTempDerate, min(cfg.panelMaxTempDerate, panelTempDerate));

    generationFactorEOL = cfg.sunPointingFactor * cfg.mpptEfficiency * panelTempDerate * solarHealthEOL;
    requiredSolarBOLW = requiredEOLSunPowerW / max(generationFactorEOL, eps);

    eclipseEnergyWh = eclipseLoadW * eclipseHours / max(cfg.batteryNominalDischargeEfficiency, eps);
    requiredBatteryWhAtTargetDOD = eclipseEnergyWh / max(cfg.targetOrbitDOD, eps);
    installedBatteryMarginPct = 100*(cfg.batteryNominalCapacityWh/requiredBatteryWhAtTargetDOD - 1);

    if isfield(cfg,'solarNominalPowerW') && ~isempty(cfg.solarNominalPowerW)
        installedSolarBOLW = cfg.solarNominalPowerW;
    else
        installedSolarBOLW = requiredSolarBOLW;
    end
    installedSolarMarginPct = 100*(installedSolarBOLW/requiredSolarBOLW - 1);

    budget = struct();
    budget.daylightHours = daylightHours;
    budget.eclipseHours = eclipseHours;
    budget.orbitHours = orbitHours;
    budget.orbitsPerDay = orbitsPerDay;
    budget.dayLoadW = dayLoadW;
    budget.eclipseLoadW = eclipseLoadW;
    budget.orbitAverageLoadW = orbitAverageLoadW;
    budget.etaDirect = etaDirect;
    budget.etaStorage = etaStorage;
    budget.requiredEOLSunPowerW = requiredEOLSunPowerW;
    budget.requiredSolarBOLW = requiredSolarBOLW;
    budget.installedSolarBOLW = installedSolarBOLW;
    budget.installedSolarMarginPct = installedSolarMarginPct;
    budget.solarHealthEOL = solarHealthEOL;
    budget.panelTempDerate = panelTempDerate;
    budget.generationFactorEOL = generationFactorEOL;
    budget.eclipseEnergyWh = eclipseEnergyWh;
    budget.requiredBatteryWhAtTargetDOD = requiredBatteryWhAtTargetDOD;
    budget.installedBatteryMarginPct = installedBatteryMarginPct;
    budget.targetOrbitDODPct = 100*cfg.targetOrbitDOD;
end

function p = localSpacecraftLoadPowerW(modeName, payloadCurrentmA, illumFrac, cfg)
    payloadRailPowerW = cfg.payloadRailScale * 3.3 * payloadCurrentmA/1000;

    if ~cfg.powerManagementEnabled
        payloadRailPowerW = cfg.payloadRailScale * 3.3 * max(payloadCurrentmA, cfg.noManagementPayloadCurrentmA)/1000;
        eclipsePenaltyW = cfg.noManagementEclipsePenaltyW * double(illumFrac < cfg.eclipseThreshold);
        p = cfg.powerNoManagementW + payloadRailPowerW + eclipsePenaltyW;
        return;
    end

    switch string(modeName)
        case "BOOT"
            p = cfg.powerBootW;
        case "PAYLOAD ON"
            p = cfg.powerPayloadOnW + payloadRailPowerW;
        case "ECLIPSE SLEEP"
            p = cfg.powerEclipseSleepW;
        case "THERMAL PROTECT"
            p = cfg.powerThermalProtectW;
        case "BACKUP SAFE"
            p = cfg.powerBackupSafeW + 0.25*payloadRailPowerW;
        otherwise
            p = cfg.powerBackupSafeW;
    end
end
