function build_CubeSat_PowerGating_Simulink_Model()
% build_CubeSat_PowerGating_Simulink_Model
% -------------------------------------------------------------------------
% Programmatically builds a Simulink model for the CubeSat sensor
% power-gating subsystem.
%
% This replaces the broken hand-drawn "circuit diagram" with an actual
% executable block-diagram model:
%
%   Environment + Firmware Controller + Switch Fault Plant
%       -> mode, commanded rail, actual rail, rail voltage, temperature,
%          current, solar ADC, illumination fraction
%
% V12 CHANGES (kept consistent with the main script's V12 fixes -- see
% docs/Firmware_Issues_and_Fixes.md):
%
%   - The eclipse model is no longer a hardcoded 70/30 duty cycle. The
%     orbit period and eclipse/sunlit durations are computed ONCE here,
%     at build time, using the same beta-angle / cylindrical-shadow
%     analytic model as src/computeIlluminationProfile.m's fallback path,
%     and passed into the MATLAB Function block as Constant blocks
%     (Orbit_Period_min, Eclipse_Duration_min, Sunlit_Duration_min).
%
%     IMPORTANT: this calculation uses datetime() and is NOT done inside
%     the MATLAB Function block itself. MATLAB Function blocks compile
%     through MATLAB Coder (the file's own original comment notes they
%     are implemented as Stateflow EMCharts in many releases), and
%     datetime/toolbox eclipse() calls are not safe to rely on inside
%     that codegen path. Computing the few scalars we need in plain
%     "outer" MATLAB code and feeding them in as block constants keeps
%     the MATLAB Function block itself simple, portable, and codegen-safe,
%     while still using real orbital-geometry-derived numbers instead of
%     a made-up duty cycle.
%
%   - solarADC is now a smooth function of mission time (via a tanh-edged
%     eclipse window, same idea as the main script), not an instantaneous
%     0/1 step -- see controllerScript() below.
%
%   - The thermal lag AND the new rail-voltage/current soft-start ramps
%     use the EXACT exponential discretization of a first-order lag
%     (x(k) = target + (x(k-1)-target)*exp(-dt/tau)) instead of an
%     explicit first-difference update. This matters here because the
%     soft-start/soft-stop time constants are short relative to the
%     model's 1-second fixed step; the explicit-difference form used by
%     the original thermal-only model is only conditionally stable, and a
%     short ramp tau pushed against that step size caused a numerically
%     unstable (unbounded, sign-flipping) result in pre-deployment
%     validation -- see /validation/crosscheck_firmware.py in this
%     delivery. The exact form is unconditionally stable for any
%     tau,dt > 0 and is used everywhere a lag is needed here.
%
%   - A small amount of fixed-seed-free (rng default) measurement noise is
%     added to solarADC and temperatureC so the Scope traces are not
%     perfectly noise-free -- consistent with the "too smooth" fix in the
%     main script.
%
% Requirements:
%   - Simulink
%   - Stateflow is recommended because MATLAB Function blocks are implemented
%     as Stateflow EMCharts in many MATLAB releases.
%
% Run:
%   build_CubeSat_PowerGating_Simulink_Model
%
% Then press Run in Simulink.

    clc;

    if exist('simulink','file') ~= 2 && exist('new_system','file') ~= 2
        error('Simulink was not found. Install Simulink to build this model.');
    end

    model = 'CubeSat_PowerGating_Subsystem_Model';

    if bdIsLoaded(model)
        close_system(model,0);
    end

    % --- V12: compute real orbital period + eclipse/sunlit durations
    % once, here, in plain (non-codegen) MATLAB. Mirrors
    % src/computeIlluminationProfile.m's analytic fallback so the
    % Simulink model and the main script agree on the same physics. -----
    earthRadius_m = 6371e3;
    altitude_m = 500e3;
    semiMajorAxis_m = earthRadius_m + altitude_m;
    inclination_deg = 51.6;
    raan_deg = 0;
    startTime = datetime(2026,6,27,12,0,0,'TimeZone','UTC');

    orbitPeriodMin = trueOrbitalPeriodMinutes(semiMajorAxis_m);
    [eclipseDurMin,sunlitDurMin,betaDeg] = analyticEclipseDurations( ...
        startTime, inclination_deg, raan_deg, earthRadius_m, semiMajorAxis_m, orbitPeriodMin);

    fprintf('Orbit period:   %.3f min\n',orbitPeriodMin);
    fprintf('Beta angle:     %.2f deg\n',betaDeg);
    fprintf('Eclipse/Sunlit: %.2f min / %.2f min\n',eclipseDurMin,sunlitDurMin);

    new_system(model);
    open_system(model);

    set_param(model, ...
        'StopTime', sprintf('%.1f', 2*orbitPeriodMin*60), ...   % ~2 orbits, was hardcoded 200*60
        'Solver', 'FixedStepDiscrete', ...
        'FixedStep', '1');

    % Layout constants
    x0 = 40; y0 = 60; w = 130; h = 45;

    % Blocks
    add_block('simulink/Sources/Clock', [model '/Time_s'], ...
        'Position', [x0 y0 x0+w y0+h]);

    add_block('simulink/Sources/Constant', [model '/Failure_Mode'], ...
        'Value', '0', ...
        'Position', [x0 y0+80 x0+w y0+80+h]);

    add_block('simulink/Sources/Constant', [model '/Failure_Time_min'], ...
        'Value', sprintf('%.2f',0.95*orbitPeriodMin), ...   % V12: scaled to real period, was hardcoded 95
        'Position', [x0 y0+160 x0+w y0+160+h]);

    add_block('simulink/Sources/Constant', [model '/Enable_Rail_Feedback'], ...
        'Value', '1', ...
        'Position', [x0 y0+240 x0+w y0+240+h]);

    add_block('simulink/Sources/Constant', [model '/Orbit_Period_min'], ...
        'Value', sprintf('%.4f',orbitPeriodMin), ...
        'Position', [x0 y0+320 x0+w y0+320+h]);

    add_block('simulink/Sources/Constant', [model '/Eclipse_Duration_min'], ...
        'Value', sprintf('%.4f',eclipseDurMin), ...
        'Position', [x0 y0+400 x0+w y0+400+h]);

    add_block('simulink/Sources/Constant', [model '/Sunlit_Duration_min'], ...
        'Value', sprintf('%.4f',sunlitDurMin), ...
        'Position', [x0 y0+480 x0+w y0+480+h]);

    controllerPath = [model '/Environment_Firmware_and_Switch_Plant'];
    add_block('simulink/User-Defined Functions/MATLAB Function', controllerPath, ...
        'Position', [290 95 570 295]);

    % Set MATLAB Function block code
    setMatlabFunctionScript(controllerPath, controllerScript());

    % Output scopes -- V12: added Illumination_Fraction (was 7 outputs, now 8)
    outNames = {'Mode','Commanded_Rail','Actual_Rail','Rail_Voltage','Temperature_C', ...
                'Current_mA','Solar_ADC','Illumination_Fraction'};
    for i = 1:numel(outNames)
        y = 40 + (i-1)*65;
        add_block('simulink/Sinks/Out1', [model '/' outNames{i}], ...
            'Position', [730 y 790 y+30]);
    end

    % Connect inputs
    add_line(model, 'Time_s/1', 'Environment_Firmware_and_Switch_Plant/1', 'autorouting', 'on');
    add_line(model, 'Failure_Mode/1', 'Environment_Firmware_and_Switch_Plant/2', 'autorouting', 'on');
    add_line(model, 'Failure_Time_min/1', 'Environment_Firmware_and_Switch_Plant/3', 'autorouting', 'on');
    add_line(model, 'Enable_Rail_Feedback/1', 'Environment_Firmware_and_Switch_Plant/4', 'autorouting', 'on');
    add_line(model, 'Orbit_Period_min/1', 'Environment_Firmware_and_Switch_Plant/5', 'autorouting', 'on');
    add_line(model, 'Eclipse_Duration_min/1', 'Environment_Firmware_and_Switch_Plant/6', 'autorouting', 'on');
    add_line(model, 'Sunlit_Duration_min/1', 'Environment_Firmware_and_Switch_Plant/7', 'autorouting', 'on');

    % Connect outputs
    for i = 1:numel(outNames)
        add_line(model, sprintf('Environment_Firmware_and_Switch_Plant/%d',i), ...
            sprintf('%s/1', outNames{i}), 'autorouting', 'on');
    end

    % Add dashboard scopes -- V12: added a 5th trace for illumination fraction
    add_block('simulink/Sinks/Scope', [model '/Subsystem_Scope'], ...
        'Position', [880 80 1040 260], ...
        'NumInputPorts', '5');
    add_line(model, 'Environment_Firmware_and_Switch_Plant/1', 'Subsystem_Scope/1', 'autorouting', 'on');
    add_line(model, 'Environment_Firmware_and_Switch_Plant/4', 'Subsystem_Scope/2', 'autorouting', 'on');
    add_line(model, 'Environment_Firmware_and_Switch_Plant/5', 'Subsystem_Scope/3', 'autorouting', 'on');
    add_line(model, 'Environment_Firmware_and_Switch_Plant/6', 'Subsystem_Scope/4', 'autorouting', 'on');
    add_line(model, 'Environment_Firmware_and_Switch_Plant/8', 'Subsystem_Scope/5', 'autorouting', 'on');

    annotationText = sprintf([ ...
        'CubeSat Sensor Power-Gating Subsystem (V12)\n\n' ...
        'Failure_Mode: 0 = none, 1 = stuck ON, 2 = stuck OFF\n' ...
        'This model represents the small sensor payload rail only.\n' ...
        'It does not switch the main CubeSat bus, OBC, radio, battery, or EPS.\n\n' ...
        'Orbit_Period_min / Eclipse_Duration_min / Sunlit_Duration_min are\n' ...
        'computed from the satellite''s real orbital elements + an analytic\n' ...
        'beta-angle shadow model (see build script header), NOT a hardcoded\n' ...
        '70/30 duty cycle as in V11.\n\n' ...
        'Outputs:\n' ...
        'Mode: 1 Eclipse sleep, 2 Payload ON, 3 Thermal protect, 6 Backup safe\n' ...
        'Rail voltage/current now ramp (soft-start/soft-stop) instead of\n' ...
        'stepping instantly, and carry small measurement noise.' ...
    ]);
    Simulink.Annotation(model, annotationText).Position = [40 560 520 760];

    save_system(model);
    fprintf('\nCreated and saved Simulink model: %s.slx\n', model);
    fprintf('Open it in Simulink and press Run.\n');
    fprintf('Set Failure_Mode to 0, 1, or 2 to test normal, stuck ON, or stuck OFF.\n\n');
end

function setMatlabFunctionScript(blockPath, scriptText)
    % MATLAB Function blocks are represented by Stateflow.EMChart internally.
    rt = sfroot;
    chart = rt.find('-isa','Stateflow.EMChart','Path',blockPath);

    if isempty(chart)
        error(['Could not access MATLAB Function block script. ', ...
               'Stateflow may be required for MATLAB Function block editing.']);
    end

    chart.Script = scriptText;
end

function [eclipseDurMin,sunlitDurMin,betaDeg] = analyticEclipseDurations( ...
    startTime, inclination_deg, raan_deg, Re, a, periodMin)
% Same beta-angle / cylindrical-shadow physics as the local function
% analyticIlluminationProfile() in src/computeIlluminationProfile.m,
% reduced here to just the two durations + beta angle this build script
% needs (no per-timestep profile required at build time).

    n = days(startTime - datetime(2000,1,1,12,0,0,'TimeZone','UTC'));
    L = mod(280.460 + 0.9856474*n, 360);
    g = mod(357.528 + 0.9856003*n, 360);
    lambdaSun = L + 1.915*sind(g) + 0.020*sind(2*g);
    epsObliquity = 23.439 - 0.0000004*n;

    sunVec = [cosd(lambdaSun), ...
              cosd(epsObliquity)*sind(lambdaSun), ...
              sind(epsObliquity)*sind(lambdaSun)];

    hHat = [sind(inclination_deg)*sind(raan_deg), ...
            -sind(inclination_deg)*cosd(raan_deg), ...
            cosd(inclination_deg)];

    betaDeg = asind(dot(hHat, sunVec));
    betaCritDeg = asind(Re/a);

    if abs(betaDeg) >= betaCritDeg
        eclipseDurMin = 0;
        sunlitDurMin = periodMin;
        return;
    end

    ratio = sqrt(a^2 - Re^2) / (a*cosd(betaDeg));
    ratio = max(-1, min(1, ratio));
    halfAngleDeg = acosd(ratio);
    eclipseFracOrbit = (2*halfAngleDeg) / 360;

    eclipseDurMin = eclipseFracOrbit*periodMin;
    sunlitDurMin = periodMin - eclipseDurMin;
end

function txt = controllerScript()
    txt = [
"function [mode, commandedRail, actualRail, railVoltage, temperatureC, current_mA, solarADC, illumFrac] = ..."
"    fcn(time_s, failureMode, failureTimeMin, enableRailFeedback, orbitPeriodMin, eclipseDurMin, sunlitDurMin)"
"%#codegen"
"% Mode: 1 Eclipse sleep, 2 Payload ON, 3 Thermal protect, 6 Backup safe"
"%"
"% V12: orbitPeriodMin/eclipseDurMin/sunlitDurMin are supplied as block"
"% constants (computed once at build time from real orbital elements +"
"% an analytic beta-angle shadow model -- see the build script). This"
"% chart stays codegen-safe by not calling datetime()/eclipse() itself."
"persistent lastMode nextControlTime_s eclipseLatched thermalLatched"
"persistent tempC railVPersist currentPersist cmdRail"
"if isempty(lastMode)"
"    lastMode = 1;"
"    nextControlTime_s = 0;"
"    eclipseLatched = false;"
"    thermalLatched = false;"
"    tempC = 50;"
"    railVPersist = 0;"
"    currentPersist = 0.011;"
"    cmdRail = false;"
"end"
""
"orbitPeriod_s = orbitPeriodMin*60;"
"eclipseDur_s  = eclipseDurMin*60;"
"sunlitDur_s   = sunlitDurMin*60;"
"rampTau_s = 21;   % smoothing width at the umbra edges (seconds)"
""
"% --- V12: smooth (tanh-edged) illumination fraction instead of an"
"% instantaneous 0/1 step. Same construction as the main script's"
"% analytic fallback, just evaluated in seconds instead of minutes." 
"phase_s = mod(time_s, orbitPeriod_s);"
"shifted_s = mod(phase_s - sunlitDur_s + orbitPeriod_s/2, orbitPeriod_s) - orbitPeriod_s/2;"
"afterFallingEdge = 0.5*(1 + tanh(shifted_s/rampTau_s));"
"beforeRisingEdge = 0.5*(1 - tanh((shifted_s - eclipseDur_s)/rampTau_s));"
"insideEclipse = afterFallingEdge*beforeRisingEdge;"
"illumFrac = 1 - insideEclipse;"
""
"solarADC = 120 + (900-120)*illumFrac + 8*randn;   % + small ADC measurement noise"
""
"% --- Thermal plant: continuous blend by illumination fraction (no"
"% instantaneous target-temperature jump at the eclipse edge), exact-exp"
"% lag discretization (unconditionally stable for any tau,dt > 0)."
"if cmdRail"
"    sunTargetTemp = 130;"
"else"
"    sunTargetTemp = 75;"
"end"
"targetTemp = illumFrac*sunTargetTemp + (1-illumFrac)*(-40);"
"tauThermal_s = 30*60;"
"tempC = targetTemp + (tempC - targetTemp)*exp(-1/tauThermal_s);   % dt = 1 s (FixedStep)"
"temperatureC = tempC + 0.3*randn;                                  % + small sensor noise"
""
"% Default outputs hold previous"
"mode = lastMode;"
"commandedRail = cmdRail;"
"actualRail = applyFault(cmdRail, time_s/60, failureMode, failureTimeMin);"
""
"if time_s >= nextControlTime_s"
"    if eclipseLatched"
"        eclipseDecision = solarADC < 650;"
"    else"
"        eclipseDecision = solarADC <= 500;"
"    end"
""
"    if eclipseDecision"
"        eclipseLatched = true;"
"        cmdRail = false;"
"        commandedRail = false;"
"        actualRail = applyFault(false, time_s/60, failureMode, failureTimeMin);"
"        if enableRailFeedback ~= 0 && actualRail"
"            mode = 6;"
"        else"
"            mode = 1;"
"        end"
"        nextControlTime_s = time_s + 60;"
"    else"
"        eclipseLatched = false;"
"        if thermalLatched"
"            thermalDecision = tempC > 100;"
"        else"
"            thermalDecision = tempC >= 120;"
"        end"
"        if thermalDecision"
"            thermalLatched = true;"
"            cmdRail = false;"
"            commandedRail = false;"
"            actualRail = applyFault(false, time_s/60, failureMode, failureTimeMin);"
"            if enableRailFeedback ~= 0 && actualRail"
"                mode = 6;"
"            else"
"                mode = 3;"
"            end"
"            nextControlTime_s = time_s + 60;"
"        else"
"            thermalLatched = false;"
"            cmdRail = true;"
"            commandedRail = true;"
"            actualRail = applyFault(true, time_s/60, failureMode, failureTimeMin);"
"            if enableRailFeedback ~= 0 && ~actualRail"
"                mode = 6;"
"                nextControlTime_s = time_s + 60;"
"            else"
"                mode = 2;"
"                nextControlTime_s = time_s + 1;"
"            end"
"        end"
"    end"
"    lastMode = mode;"
"end"
""
"if actualRail"
"    targetRailV = 3.3;"
"else"
"    targetRailV = 0;"
"end"
""
"if mode == 2"
"    targetCurrent = 40.1;"
"elseif mode == 6 && actualRail"
"    targetCurrent = 5.11;"
"else"
"    targetCurrent = 0.011;"
"end"
""
"% --- V12: soft-start / soft-stop instead of an instantaneous step,"
"% exact-exp lag (unconditionally stable -- see header comment)."
"tauRail_s = 6;"
"tauCurrent_s = 6;"
"railVPersist = targetRailV + (railVPersist-targetRailV)*exp(-1/tauRail_s);"
"currentPersist = targetCurrent + (currentPersist-targetCurrent)*exp(-1/tauCurrent_s);"
"railVoltage = railVPersist;"
"current_mA = currentPersist;"
""
"function y = applyFault(commanded, tMin, fMode, fTime)"
"    if tMin < fTime"
"        y = commanded;"
"    elseif fMode == 1"
"        y = true;"
"    elseif fMode == 2"
"        y = false;"
"    else"
"        y = commanded;"
"    end"
"end"
"end"
    ];
    txt = strjoin(txt, newline);
end
