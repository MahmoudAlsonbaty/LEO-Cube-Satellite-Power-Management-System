function tf = functionAvailable(name)
% functionAvailable
% -------------------------------------------------------------------------
% Tolerant helper for top-level functions/classes/built-ins. Intentionally
% includes which(name), because MATLAB class methods in @folders may not
% appear through exist(name,'file') even when method dispatch can call them.
%
% V23 (independent audit): de-duplicated from two identical local copies --
% see scenarioApiAvailable.m for why.

    tf = exist(name,'file') == 2 || exist(name,'class') == 8 || ...
         exist(name,'builtin') == 5 || ~isempty(which(name));
end
