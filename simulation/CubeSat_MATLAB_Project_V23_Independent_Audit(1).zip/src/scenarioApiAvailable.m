function tf = scenarioApiAvailable()
% scenarioApiAvailable
% -------------------------------------------------------------------------
% True when satelliteScenario can be called to create a scenario object.
% satelliteScenario is usually visible as a class/function under
% toolbox/shared/orbit.
%
% V23 (independent audit): this function used to be defined identically,
% local to TWO different files (src/ensureAerospaceEphemerisReady.m and
% START_TOOLBOX_VIEWER_WITH_METRICS.m). Local functions duplicated across
% files are a maintainability risk -- a future change to the availability
% check has to be remembered in both places, and the two copies had already
% started to drift apart in their comments. Both callers now use this
% single src/-path copy instead.

    tf = functionAvailable('satelliteScenario') || ~isempty(which('satelliteScenario'));
end
