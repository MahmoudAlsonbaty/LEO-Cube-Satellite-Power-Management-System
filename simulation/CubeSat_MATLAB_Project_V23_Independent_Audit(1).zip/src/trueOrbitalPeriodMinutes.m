function periodMin = trueOrbitalPeriodMinutes(semiMajorAxis_m)
% trueOrbitalPeriodMinutes
% -------------------------------------------------------------------------
% Returns the true two-body Keplerian orbital period (minutes) for a given
% semi-major axis, using the vis-viva / Kepler third-law relationship:
%
%   T = 2*pi*sqrt(a^3 / mu)
%
% WHY THIS FUNCTION EXISTS (V12 fix):
%   V11 hardcoded "orbitMinutes = 100" and asserted in the README that this
%   was "exactly one 100-minute orbit". For the satellite actually defined
%   in START_TOOLBOX_VIEWER_WITH_METRICS.m (500 km altitude circular orbit,
%   semiMajorAxis_m = 6371e3 + 500e3), the TRUE Keplerian period is about
%   94.47 minutes, not 100 minutes. That ~6% error meant:
%     - The scenario stop time did not correspond to exactly one orbit
%       (the satellite actually completed slightly MORE than one full
%       revolution by the time the demo ended).
%     - The eclipse/sunlight duty cycle used by the firmware model assumed
%       a 100-minute period internally, which did not match the period the
%       3D viewer was actually propagating the satellite on -- a direct
%       source of the "viewer vs dashboard" desynchronization the project
%       brief asked us to fix.
%
%   Centralizing the period calculation here means every part of the
%   project (scenario stop time, firmware duty cycle, eclipse model,
%   playback-speed calculation) uses ONE consistent, physically-derived
%   number, computed from whatever orbital elements are actually in use --
%   so this stays correct even if someone changes the altitude later.
%
% Inputs:
%   semiMajorAxis_m - semi-major axis of the orbit, meters
%
% Output:
%   periodMin       - orbital period, minutes
%
% Example:
%   T = trueOrbitalPeriodMinutes(6371e3 + 500e3);  % ~94.47 min

    muEarth_m3s2 = 3.986004418e14;   % standard gravitational parameter, Earth

    if nargin < 1 || isempty(semiMajorAxis_m) || semiMajorAxis_m <= 0
        error('trueOrbitalPeriodMinutes:badInput', ...
              'semiMajorAxis_m must be a positive scalar (meters).');
    end

    periodSec = 2*pi*sqrt(semiMajorAxis_m^3 / muEarth_m3s2);
    periodMin = periodSec / 60;
end
