function mission = simulateCubeSatMissionPower(orbitSim, cfg)
% simulateCubeSatMissionPower
% -------------------------------------------------------------------------
% V22 source-backed full-mission CubeSat EPS simulation.
%
% V20 replaces the earlier "always failing" V19 defaults with a two-step
% engineering workflow:
%   1) EPS hardware is sized from an orbit energy-budget equation in
%      estimateCubeSatEPSPowerBudget.m.
%   2) This function integrates the resulting installed hardware over the
%      requested mission duration and reports SOC, DOD, energy margin,
%      battery aging, solar-array degradation, and failure status.
%
% The function remains a configurable trade-study model. Replace the default
% coefficients with measured solar-panel, EPS, and battery-cell data before
% using it for flight design.

    cfg = applyDefaults(cfg);

    dtMin = cfg.missionStepSeconds/60;
    timeMin = 0:dtMin:(cfg.missionDurationDays*24*60);
    if timeMin(end) < cfg.missionDurationDays*24*60
        timeMin = [timeMin cfg.missionDurationDays*24*60]; %#ok<AGROW>
    end

    N = numel(timeMin);
    dtHr = [0 diff(timeMin)]/60;
    dtYears = dtHr/(24*365.25);

    orbitPeriodMin = orbitSim.timeMin(end);
    phaseMin = mod(timeMin, orbitPeriodMin);

    illumFrac = interp1(orbitSim.timeMin, orbitSim.illumFrac, phaseMin, 'linear', 'extrap');
    orbitTempC = interp1(orbitSim.timeMin, orbitSim.tempC, phaseMin, 'linear', 'extrap');
    payloadCurrentmA = interp1(orbitSim.timeMin, orbitSim.currentmA, phaseMin, 'linear', 'extrap');

    phaseIdx = interp1(orbitSim.timeMin, 1:numel(orbitSim.timeMin), phaseMin, 'nearest', 'extrap');
    phaseIdx = max(1, min(numel(orbitSim.modeName), round(phaseIdx)));
    modeName = orbitSim.modeName(phaseIdx);

    soc = zeros(1,N);
    storedWh = zeros(1,N);
    capacityHealth = zeros(1,N);
    tempCapacityFactor = zeros(1,N);
    availableCapacityWh = zeros(1,N);
    batteryTempC = zeros(1,N);
    panelTempC = zeros(1,N);
    solarHealth = zeros(1,N);
    generatedW = zeros(1,N);
    loadW = zeros(1,N);
    consumedW = zeros(1,N);
    netBatteryW = zeros(1,N);
    chargeWh = zeros(1,N);
    dischargeWh = zeros(1,N);
    unmetWh = zeros(1,N);
    excessWh = zeros(1,N);
    cumulativeGeneratedWh = zeros(1,N);
    cumulativeConsumedWh = zeros(1,N);
    cumulativeUnmetWh = zeros(1,N);
    cumulativeExcessWh = zeros(1,N);
    equivalentFullCycles = zeros(1,N);
    dischargeEquivalentCycles = zeros(1,N);
    weightedCycleDamageEFC = zeros(1,N);
    orbitDepthOfDischarge = zeros(1,N);
    instantaneousDepthOfDischarge = zeros(1,N);
    batteryCycleFade = zeros(1,N);
    batteryCalendarFade = zeros(1,N);
    batteryHighSOCStress = zeros(1,N);
    batteryC_Rate = zeros(1,N);
    solarRadiationFade = zeros(1,N);
    solarThermalCycleFade = zeros(1,N);
    solarThermalCycleCount = zeros(1,N);
    powerMarginW = zeros(1,N);

    capacityHealth(1) = 1.0;
    solarHealth(1) = 1.0;
    batteryTempC(1) = cfg.batteryInitialTempC;
    panelTempC(1) = cfg.panelInitialTempC;
    tempCapacityFactor(1) = batteryTempCapacityFactor(batteryTempC(1), cfg);
    availableCapacityWh(1) = cfg.batteryNominalCapacityWh * capacityHealth(1) * tempCapacityFactor(1);
    soc(1) = max(cfg.socMin, min(cfg.socMax, cfg.initialSOC));
    storedWh(1) = soc(1) * availableCapacityWh(1);
    instantaneousDepthOfDischarge(1) = max(0, cfg.socMax - soc(1));

    previousSunlit = illumFrac(1) >= cfg.eclipseThreshold;
    currentOrbit = floor(timeMin(1)/orbitPeriodMin) + 1;
    orbitSocMin = soc(1);
    orbitSocMax = soc(1);

    for k = 1:N
        if k > 1
            elapsedOrbit = floor(timeMin(k)/orbitPeriodMin) + 1;
            if elapsedOrbit ~= currentOrbit
                orbitDepth = max(0, orbitSocMax - orbitSocMin);
                idxPrevOrbit = floor(timeMin/orbitPeriodMin) + 1 == currentOrbit;
                orbitDepthOfDischarge(idxPrevOrbit) = orbitDepth;
                currentOrbit = elapsedOrbit;
                orbitSocMin = soc(k-1);
                orbitSocMax = soc(k-1);
            end
        end

        loadW(k) = spacecraftLoadPowerW(modeName(k), payloadCurrentmA(k), illumFrac(k), cfg);
        consumedW(k) = loadW(k) / cfg.epsDistributionEfficiency;

        if k == 1
            generatedW(k) = cfg.solarNominalPowerW * cfg.sunPointingFactor * illumFrac(k) * ...
                solarHealth(k) * cfg.mpptEfficiency;
            netBatteryW(k) = generatedW(k) - consumedW(k);
            powerMarginW(k) = netBatteryW(k);
            continue;
        end

        panelTargetC = cfg.panelEclipseTempC + ...
            (cfg.panelSunTempC - cfg.panelEclipseTempC)*illumFrac(k) + ...
            cfg.panelLoadHeatCoeffCperW*loadW(k);
        panelTempC(k) = firstOrderLag(panelTempC(k-1), panelTargetC, dtHr(k)*60, cfg.panelThermalTauMin);

        batteryTargetC = cfg.batteryBaseTempC + ...
            cfg.batterySunHeatC*illumFrac(k) + ...
            cfg.batteryLoadHeatCoeffCperW*loadW(k) + ...
            cfg.batteryOrbitTempCoupling*(orbitTempC(k) - cfg.batteryBaseTempC);
        batteryTempC(k) = firstOrderLag(batteryTempC(k-1), batteryTargetC, dtHr(k)*60, cfg.batteryThermalTauMin);

        tempCapacityFactor(k) = batteryTempCapacityFactor(batteryTempC(k), cfg);
        availableCapacityWh(k) = cfg.batteryNominalCapacityWh * capacityHealth(k-1) * tempCapacityFactor(k);

        % V23 FIX (independent audit): clamp the carried-over stored energy to
        % BOTH the floor and the ceiling of the current step's available
        % capacity, not just the ceiling. availableCapacityWh can legitimately
        % move step-to-step (tempCapacityFactor responds to battery
        % temperature every sample), so storedWh(k-1) re-expressed against
        % availableCapacityWh(k) is not guaranteed to land back inside
        % [socMin, socMax] from the ceiling clamp alone -- a transient rise in
        % availableCapacityWh while the battery was sitting at the floor can
        % otherwise compute a SOC fractionally BELOW socMin (observed: ~4.98%
        % against a configured 5.00% floor in the "Same-array no-control
        % stress test" case). Floor-clamping here keeps storedWh and soc
        % consistent at every step, not just after the discharge-limiter logic
        % below (which only protects the *delta* within a single step).
        storedWh(k) = max(cfg.socMin*availableCapacityWh(k), min(storedWh(k-1), cfg.socMax*availableCapacityWh(k)));
        soc(k) = storedWh(k)/max(availableCapacityWh(k), eps);

        panelTempDerate = 1 + cfg.panelPowerTempCoeffPerC*(panelTempC(k) - cfg.panelReferenceTempC);
        panelTempDerate = max(cfg.panelMinTempDerate, min(cfg.panelMaxTempDerate, panelTempDerate));
        generatedW(k) = cfg.solarNominalPowerW * cfg.sunPointingFactor * illumFrac(k) * ...
            solarHealth(k-1) * panelTempDerate * cfg.mpptEfficiency;

        netBatteryW(k) = generatedW(k) - consumedW(k);
        powerMarginW(k) = netBatteryW(k);

        chargeEff = batteryChargeEfficiency(batteryTempC(k), cfg);
        dischargeEff = batteryDischargeEfficiency(batteryTempC(k), cfg);

        if netBatteryW(k) >= 0
            requestedChargeWh = netBatteryW(k) * dtHr(k) * chargeEff;
            headroomWh = max(0, (cfg.socMax - soc(k))*availableCapacityWh(k));
            chargeWh(k) = min(requestedChargeWh, headroomWh);
            excessWh(k) = max(0, requestedChargeWh - chargeWh(k));
            storedWh(k) = storedWh(k) + chargeWh(k);
        else
            requestedDischargeWh = -netBatteryW(k) * dtHr(k) / dischargeEff;
            usableWh = max(0, (soc(k) - cfg.socMin) * availableCapacityWh(k));
            dischargeWh(k) = min(requestedDischargeWh, usableWh);
            unmetWh(k) = max(0, requestedDischargeWh - dischargeWh(k));
            storedWh(k) = storedWh(k) - dischargeWh(k);
        end

        % V23 FIX (independent audit): same floor+ceiling clamp as above,
        % applied after this step's charge/discharge, so storedWh and soc
        % never drift apart and soc(k) cannot land fractionally below
        % socMin due to availableCapacityWh(k) differing from the value
        % implicitly used earlier in this step's headroom/usable-Wh math.
        storedWh(k) = max(cfg.socMin*availableCapacityWh(k), min(cfg.socMax*availableCapacityWh(k), storedWh(k)));
        soc(k) = storedWh(k)/max(availableCapacityWh(k), eps);
        instantaneousDepthOfDischarge(k) = max(0, cfg.socMax - soc(k));
        orbitSocMin = min(orbitSocMin, soc(k));
        orbitSocMax = max(orbitSocMax, soc(k));

        movedWh = chargeWh(k) + dischargeWh(k);
        equivalentFullCycles(k) = equivalentFullCycles(k-1) + movedWh/(2*cfg.batteryNominalCapacityWh);
        dischargeEquivalentCycles(k) = dischargeEquivalentCycles(k-1) + dischargeWh(k)/cfg.batteryNominalCapacityWh;

        dodForStress = max(cfg.minimumDODForAging, instantaneousDepthOfDischarge(k));
        dodStress = max(cfg.minDODStressFactor, (dodForStress/cfg.referenceDOD)^cfg.dodStressExponent);

        batteryC_Rate(k) = abs(netBatteryW(k)) / max(cfg.batteryNominalCapacityWh, eps);
        cRateStress = 1 + cfg.cRateStressGain * max(0, batteryC_Rate(k) - cfg.referenceCRate);
        tempAccel = cfg.batteryQ10^((batteryTempC(k) - cfg.batteryReferenceTempC)/10);

        dWeightedEFC = dischargeWh(k)/cfg.batteryNominalCapacityWh * dodStress * cRateStress;
        weightedCycleDamageEFC(k) = weightedCycleDamageEFC(k-1) + dWeightedEFC;
        dCycleFade = cfg.batteryCycleFadeAtReference * ...
            dWeightedEFC / cfg.batteryReferenceCycleLifeEFC * tempAccel;

        highSOCStress = 1 + cfg.highSOCCalendarStressGain * max(0, soc(k) - cfg.highSOCStressThreshold);
        lowSOCStress = 1 + cfg.lowSOCCalendarStressGain * max(0, cfg.lowSOCStressThreshold - soc(k));
        batteryHighSOCStress(k) = highSOCStress;
        dCalendarFade = cfg.batteryCalendarFadePerYear * dtYears(k) * tempAccel * highSOCStress * lowSOCStress;

        batteryCycleFade(k) = min(cfg.batteryMaxPermanentFade, batteryCycleFade(k-1) + dCycleFade);
        batteryCalendarFade(k) = min(cfg.batteryMaxPermanentFade, batteryCalendarFade(k-1) + dCalendarFade);
        totalBatteryFade = min(cfg.batteryMaxPermanentFade, batteryCycleFade(k) + batteryCalendarFade(k));
        capacityHealth(k) = max(1 - totalBatteryFade, cfg.batteryMinHealthFloor);

        solarRadiationFade(k) = min(cfg.solarMaxPermanentFade, ...
            solarRadiationFade(k-1) + cfg.solarRadiationDegradationPerYear*dtYears(k));

        isSunlit = illumFrac(k) >= cfg.eclipseThreshold;
        if isSunlit ~= previousSunlit
            solarThermalCycleCount(k) = solarThermalCycleCount(k-1) + 0.5;
            dPanelCycleFade = cfg.solarThermalCycleFadePerHalfCycle * ...
                (1 + abs(panelTempC(k) - panelTempC(k-1))/cfg.panelCycleReferenceDeltaC);
            solarThermalCycleFade(k) = min(cfg.solarMaxPermanentFade, ...
                solarThermalCycleFade(k-1) + dPanelCycleFade);
            previousSunlit = isSunlit;
        else
            solarThermalCycleCount(k) = solarThermalCycleCount(k-1);
            solarThermalCycleFade(k) = solarThermalCycleFade(k-1);
        end

        totalSolarFade = min(cfg.solarMaxPermanentFade, solarRadiationFade(k) + solarThermalCycleFade(k));
        solarHealth(k) = max(1 - totalSolarFade, cfg.solarMinHealthFloor);

        cumulativeGeneratedWh(k) = cumulativeGeneratedWh(k-1) + generatedW(k)*dtHr(k);
        cumulativeConsumedWh(k) = cumulativeConsumedWh(k-1) + consumedW(k)*dtHr(k);
        cumulativeUnmetWh(k) = cumulativeUnmetWh(k-1) + unmetWh(k);
        cumulativeExcessWh(k) = cumulativeExcessWh(k-1) + excessWh(k);
    end

    orbitDepth = max(0, orbitSocMax - orbitSocMin);
    idxLastOrbit = floor(timeMin/orbitPeriodMin) + 1 == currentOrbit;
    orbitDepthOfDischarge(idxLastOrbit) = orbitDepth;

    daily = makeDailySummary(timeMin, soc, generatedW, consumedW, unmetWh, excessWh, ...
        capacityHealth, solarHealth, batteryTempC, panelTempC, orbitDepthOfDischarge, cfg);

    mission = struct();
    mission.config = cfg;
    mission.scenarioName = string(cfg.scenarioName);
    mission.timeMin = timeMin;
    mission.timeDays = timeMin/1440;
    mission.illumFrac = illumFrac;
    mission.modeName = modeName;
    mission.soc = soc;
    mission.storedWh = storedWh;
    mission.capacityHealth = capacityHealth;
    mission.tempCapacityFactor = tempCapacityFactor;
    mission.availableCapacityWh = availableCapacityWh;
    mission.batteryTempC = batteryTempC;
    mission.panelTempC = panelTempC;
    mission.solarHealth = solarHealth;
    mission.generatedW = generatedW;
    mission.loadW = loadW;
    mission.consumedW = consumedW;
    mission.netBatteryW = netBatteryW;
    mission.powerMarginW = powerMarginW;
    mission.chargeWh = chargeWh;
    mission.dischargeWh = dischargeWh;
    mission.unmetWh = unmetWh;
    mission.excessWh = excessWh;
    mission.cumulativeGeneratedWh = cumulativeGeneratedWh;
    mission.cumulativeConsumedWh = cumulativeConsumedWh;
    mission.cumulativeUnmetWh = cumulativeUnmetWh;
    mission.cumulativeExcessWh = cumulativeExcessWh;
    mission.equivalentFullCycles = equivalentFullCycles;
    mission.dischargeEquivalentCycles = dischargeEquivalentCycles;
    mission.weightedCycleDamageEFC = weightedCycleDamageEFC;
    mission.instantaneousDepthOfDischarge = instantaneousDepthOfDischarge;
    mission.orbitDepthOfDischarge = orbitDepthOfDischarge;
    mission.batteryCycleFade = batteryCycleFade;
    mission.batteryCalendarFade = batteryCalendarFade;
    mission.batteryHighSOCStress = batteryHighSOCStress;
    mission.batteryC_Rate = batteryC_Rate;
    mission.solarRadiationFade = solarRadiationFade;
    mission.solarThermalCycleFade = solarThermalCycleFade;
    mission.solarThermalCycleCount = solarThermalCycleCount;
    mission.daily = daily;
    mission.summary = makeMissionSummary(mission);
end

function cfg = applyDefaults(cfg)
    if nargin < 1 || isempty(cfg)
        cfg = struct();
    end

    cfg = setDefault(cfg,'scenarioName','Managed EPS solution');
    cfg = setDefault(cfg,'powerManagementEnabled',true);
    cfg = setDefault(cfg,'missionDurationDays',365);
    cfg = setDefault(cfg,'missionStepSeconds',300);
    cfg = setDefault(cfg,'initialSOC',0.85);
    cfg = setDefault(cfg,'socMin',0.20);
    cfg = setDefault(cfg,'socMax',0.90);

    cfg = setDefault(cfg,'batteryNominalCapacityWh',24.0);
    cfg = setDefault(cfg,'batteryInitialTempC',22.0);
    cfg = setDefault(cfg,'batteryBaseTempC',18.0);
    cfg = setDefault(cfg,'batterySunHeatC',5.0);
    cfg = setDefault(cfg,'batteryLoadHeatCoeffCperW',0.40);
    cfg = setDefault(cfg,'batteryOrbitTempCoupling',0.035);
    cfg = setDefault(cfg,'batteryThermalTauMin',55.0);
    cfg = setDefault(cfg,'batteryReferenceTempC',25.0);
    cfg = setDefault(cfg,'batteryQ10',2.0);
    cfg = setDefault(cfg,'batteryReferenceCycleLifeEFC',5500);
    cfg = setDefault(cfg,'batteryCycleFadeAtReference',0.20);
    cfg = setDefault(cfg,'batteryCalendarFadePerYear',0.010);
    cfg = setDefault(cfg,'batteryMaxPermanentFade',0.45);
    cfg = setDefault(cfg,'batteryMinHealthFloor',0.55);
    cfg = setDefault(cfg,'referenceDOD',0.30);
    cfg = setDefault(cfg,'minimumDODForAging',0.03);
    cfg = setDefault(cfg,'dodStressExponent',1.55);
    cfg = setDefault(cfg,'minDODStressFactor',0.15);
    cfg = setDefault(cfg,'referenceCRate',0.20);
    cfg = setDefault(cfg,'cRateStressGain',0.60);
    cfg = setDefault(cfg,'highSOCStressThreshold',0.85);
    cfg = setDefault(cfg,'highSOCCalendarStressGain',1.10);
    cfg = setDefault(cfg,'lowSOCStressThreshold',0.15);
    cfg = setDefault(cfg,'lowSOCCalendarStressGain',1.10);
    cfg = setDefault(cfg,'batteryColdCapacityLossPerC',0.0045);
    cfg = setDefault(cfg,'batteryHotCapacityLossPerC',0.0020);
    cfg = setDefault(cfg,'batteryMinTempCapacityFactor',0.70);
    cfg = setDefault(cfg,'batteryMaxTempCapacityFactor',1.02);
    cfg = setDefault(cfg,'batteryNominalChargeEfficiency',0.94);
    cfg = setDefault(cfg,'batteryNominalDischargeEfficiency',0.96);
    cfg = setDefault(cfg,'batteryMinEfficiency',0.82);
    cfg = setDefault(cfg,'targetOrbitDOD',0.30);

    cfg = setDefault(cfg,'solarNominalPowerW',10.5);
    cfg = setDefault(cfg,'sunPointingFactor',0.82);
    cfg = setDefault(cfg,'mpptEfficiency',0.92);
    cfg = setDefault(cfg,'solarRadiationDegradationPerYear',0.018);
    cfg = setDefault(cfg,'solarThermalCycleFadePerHalfCycle',3.5e-8);
    cfg = setDefault(cfg,'solarMaxPermanentFade',0.30);
    cfg = setDefault(cfg,'solarMinHealthFloor',0.70);
    cfg = setDefault(cfg,'panelReferenceTempC',25.0);
    cfg = setDefault(cfg,'panelSizingTempC',45.0);
    cfg = setDefault(cfg,'panelPowerTempCoeffPerC',-0.0032);
    cfg = setDefault(cfg,'panelMinTempDerate',0.70);
    cfg = setDefault(cfg,'panelMaxTempDerate',1.05);
    cfg = setDefault(cfg,'panelInitialTempC',0.0);
    cfg = setDefault(cfg,'panelEclipseTempC',-30.0);
    cfg = setDefault(cfg,'panelSunTempC',50.0);
    cfg = setDefault(cfg,'panelThermalTauMin',10.0);
    cfg = setDefault(cfg,'panelLoadHeatCoeffCperW',0.05);
    cfg = setDefault(cfg,'panelCycleReferenceDeltaC',75.0);
    cfg = setDefault(cfg,'eclipseThreshold',0.5);

    cfg = setDefault(cfg,'epsDistributionEfficiency',0.90);
    cfg = setDefault(cfg,'payloadRailScale',1.0);
    cfg = setDefault(cfg,'powerBootW',2.0);
    cfg = setDefault(cfg,'powerPayloadOnW',4.2);
    cfg = setDefault(cfg,'powerEclipseSleepW',0.75);
    cfg = setDefault(cfg,'powerThermalProtectW',1.05);
    cfg = setDefault(cfg,'powerBackupSafeW',0.60);
    cfg = setDefault(cfg,'powerNoManagementW',5.0);
    cfg = setDefault(cfg,'noManagementPayloadCurrentmA',40.1);
    cfg = setDefault(cfg,'noManagementEclipsePenaltyW',0.30);

    cfg = setDefault(cfg,'eolBatteryHealthLimit',0.80);
    cfg = setDefault(cfg,'eolSolarHealthLimit',0.80);
    cfg = setDefault(cfg,'thermalWarningC',45.0);
    cfg = setDefault(cfg,'thermalLimitC',60.0);
    cfg = setDefault(cfg,'unmetEnergyToleranceWh',1.0e-3);
    cfg = setDefault(cfg,'requiredSolarBOLW',NaN);
    cfg = setDefault(cfg,'installedSolarMarginPct',NaN);
    cfg = setDefault(cfg,'requiredBatteryWhAtTargetDOD',NaN);
    cfg = setDefault(cfg,'installedBatteryMarginPct',NaN);
end

function cfg = setDefault(cfg, fieldName, value)
    if ~isfield(cfg, fieldName) || isempty(cfg.(fieldName))
        cfg.(fieldName) = value;
    end
end

function x = firstOrderLag(xPrev, target, dtMin, tauMin)
    x = target + (xPrev - target)*exp(-dtMin/max(tauMin, eps));
end

function p = spacecraftLoadPowerW(modeName, payloadCurrentmA, illumFrac, cfg)
    payloadRailPowerW = cfg.payloadRailScale * 3.3 * payloadCurrentmA/1000;

    if ~cfg.powerManagementEnabled
        payloadRailPowerW = cfg.payloadRailScale * 3.3 * max(payloadCurrentmA, cfg.noManagementPayloadCurrentmA)/1000;
        eclipsePenaltyW = cfg.noManagementEclipsePenaltyW * double(illumFrac < cfg.eclipseThreshold);
        p = cfg.powerNoManagementW + payloadRailPowerW + eclipsePenaltyW;
        return;
    end

    switch string(modeName)
        case "BOOT"
            p = cfg.powerBootW;
        case "PAYLOAD ON"
            p = cfg.powerPayloadOnW + payloadRailPowerW;
        case "ECLIPSE SLEEP"
            p = cfg.powerEclipseSleepW;
        case "THERMAL PROTECT"
            p = cfg.powerThermalProtectW;
        case "BACKUP SAFE"
            p = cfg.powerBackupSafeW + 0.25*payloadRailPowerW;
        otherwise
            p = cfg.powerBackupSafeW;
    end
end

function f = batteryTempCapacityFactor(tempC, cfg)
    coldLoss = cfg.batteryColdCapacityLossPerC * max(0, cfg.batteryReferenceTempC - tempC);
    hotLoss = cfg.batteryHotCapacityLossPerC * max(0, tempC - cfg.batteryReferenceTempC);
    f = 1 - coldLoss - hotLoss;
    f = max(cfg.batteryMinTempCapacityFactor, min(cfg.batteryMaxTempCapacityFactor, f));
end

function eta = batteryChargeEfficiency(tempC, cfg)
    tempPenalty = 0.0025*abs(tempC - cfg.batteryReferenceTempC);
    eta = max(cfg.batteryMinEfficiency, cfg.batteryNominalChargeEfficiency - tempPenalty);
end

function eta = batteryDischargeEfficiency(tempC, cfg)
    tempPenalty = 0.0018*abs(tempC - cfg.batteryReferenceTempC);
    eta = max(cfg.batteryMinEfficiency, cfg.batteryNominalDischargeEfficiency - tempPenalty);
end

function daily = makeDailySummary(timeMin, soc, generatedW, consumedW, unmetWh, excessWh, ...
    capacityHealth, solarHealth, batteryTempC, panelTempC, orbitDepthOfDischarge, cfg)

    nDays = max(1, ceil(max(timeMin)/1440));
    dayIndex = min(floor(timeMin/1440) + 1, nDays);
    dtHr = [0 diff(timeMin)]/60;

    daily = struct();
    daily.day = 1:nDays;
    daily.socMinPct = zeros(1,nDays);
    daily.socMeanPct = zeros(1,nDays);
    daily.socMaxPct = zeros(1,nDays);
    daily.generatedWh = zeros(1,nDays);
    daily.consumedWh = zeros(1,nDays);
    daily.unmetWh = zeros(1,nDays);
    daily.excessWh = zeros(1,nDays);
    daily.capacityHealthPct = zeros(1,nDays);
    daily.solarHealthPct = zeros(1,nDays);
    daily.meanDODPct = zeros(1,nDays);
    daily.maxDODPct = zeros(1,nDays);
    daily.maxBatteryTempC = zeros(1,nDays);
    daily.maxPanelTempC = zeros(1,nDays);
    daily.lowSOCHours = zeros(1,nDays);
    daily.thermalLimitHours = zeros(1,nDays);

    for d = 1:nDays
        idx = dayIndex == d;
        idxLast = find(idx,1,'last');
        daily.socMinPct(d) = 100*min(soc(idx));
        daily.socMeanPct(d) = 100*mean(soc(idx));
        daily.socMaxPct(d) = 100*max(soc(idx));
        daily.generatedWh(d) = sum(generatedW(idx).*dtHr(idx));
        daily.consumedWh(d) = sum(consumedW(idx).*dtHr(idx));
        daily.unmetWh(d) = sum(unmetWh(idx));
        daily.excessWh(d) = sum(excessWh(idx));
        daily.capacityHealthPct(d) = 100*capacityHealth(idxLast);
        daily.solarHealthPct(d) = 100*solarHealth(idxLast);
        daily.meanDODPct(d) = 100*mean(orbitDepthOfDischarge(idx));
        daily.maxDODPct(d) = 100*max(orbitDepthOfDischarge(idx));
        daily.maxBatteryTempC(d) = max(batteryTempC(idx));
        daily.maxPanelTempC(d) = max(panelTempC(idx));
        daily.lowSOCHours(d) = sum((soc(idx) <= cfg.socMin + 0.005).*dtHr(idx));
        daily.thermalLimitHours(d) = sum((batteryTempC(idx) >= cfg.thermalLimitC).*dtHr(idx));
    end
end

function summary = makeMissionSummary(mission)
    cfg = mission.config;
    summary = struct();
    summary.scenarioName = string(mission.scenarioName);
    summary.durationDays = cfg.missionDurationDays;
    summary.finalSOCPct = 100*mission.soc(end);
    summary.minSOCPct = 100*min(mission.soc);
    summary.meanSOCPct = 100*mean(mission.soc);
    summary.finalBatteryHealthPct = 100*mission.capacityHealth(end);
    summary.finalSolarHealthPct = 100*mission.solarHealth(end);
    summary.equivalentFullCycles = mission.equivalentFullCycles(end);
    summary.dischargeEquivalentCycles = mission.dischargeEquivalentCycles(end);
    summary.weightedCycleDamageEFC = mission.weightedCycleDamageEFC(end);
    summary.meanOrbitDODPct = 100*mean(mission.orbitDepthOfDischarge);
    summary.maxOrbitDODPct = 100*max(mission.orbitDepthOfDischarge);
    summary.solarThermalHalfCycles = mission.solarThermalCycleCount(end);
    summary.generatedWh = mission.cumulativeGeneratedWh(end);
    summary.consumedWh = mission.cumulativeConsumedWh(end);
    summary.unmetWh = mission.cumulativeUnmetWh(end);
    summary.excessWh = mission.cumulativeExcessWh(end);
    summary.energyBalanceWh = summary.generatedWh - summary.consumedWh;
    summary.minPowerMarginW = min(mission.powerMarginW);
    summary.meanPowerMarginW = mean(mission.powerMarginW);
    summary.maxBatteryTempC = max(mission.batteryTempC);
    summary.minBatteryTempC = min(mission.batteryTempC);
    summary.lowSOCHours = sum(mission.soc <= cfg.socMin + 0.005) * cfg.missionStepSeconds/3600;
    summary.thermalLimitHours = sum(mission.batteryTempC >= cfg.thermalLimitC) * cfg.missionStepSeconds/3600;
    % V23 FIX (independent audit): thermalWarningC was defined as a config
    % default but never read anywhere in the simulation -- the same kind of
    % "looks like it does something but doesn't" dead-config pattern this
    % project's own V11->V12 history already caught once for actual code
    % (see docs/Firmware_Issues_and_Fixes.md item 3). Wired in below as an
    % early-warning tier, strictly below the existing hard thermalLimitC
    % trigger -- it does not change any PASS/MARGINAL/FAIL/DESIGN GAP
    % outcome above, it only adds a new informational sub-case in the PASS
    % branch when temperatures got elevated without ever reaching the
    % existing hard limit.
    summary.thermalWarningHours = sum(mission.batteryTempC >= cfg.thermalWarningC) * cfg.missionStepSeconds/3600;
    summary.requiredSolarBOLW = cfg.requiredSolarBOLW;
    summary.installedSolarBOLW = cfg.solarNominalPowerW;
    summary.installedSolarMarginPct = cfg.installedSolarMarginPct;
    summary.requiredBatteryWhAtTargetDOD = cfg.requiredBatteryWhAtTargetDOD;
    summary.installedBatteryMarginPct = cfg.installedBatteryMarginPct;

    if summary.unmetWh > cfg.unmetEnergyToleranceWh
        if isfield(cfg,'scenarioRole') && string(cfg.scenarioRole) == "stress-test"
            summary.status = "DESIGN GAP - resize EPS";
        else
            summary.status = "FAIL - energy deficit";
        end
    elseif min(mission.soc) <= cfg.socMin + 0.005
        summary.status = "MARGINAL - SOC floor";
    elseif mission.capacityHealth(end) < cfg.eolBatteryHealthLimit
        summary.status = "MARGINAL - battery EOL";
    elseif mission.solarHealth(end) < cfg.eolSolarHealthLimit
        summary.status = "MARGINAL - solar EOL";
    elseif summary.thermalLimitHours > 0
        summary.status = "MARGINAL - thermal";
    elseif summary.thermalWarningHours > 0
        summary.status = "PASS - thermal warning";
    else
        summary.status = "PASS";
    end
end
