function contactInfo = computeNextGroundContact(accessObj, startTime)
% computeNextGroundContact
% -------------------------------------------------------------------------
% WHY THIS FUNCTION EXISTS (V12 toolbox-integration feature #2):
%
%   V11 already called:
%       access(sat,gs);
%   to set up line-of-sight access analysis between the CubeSat and the
%   Cairo ground station -- but it never captured the returned Access
%   object, and nothing in the dashboard ever used it. The access analysis
%   was being computed and then thrown away.
%
%   For a power-subsystem study, ground-contact windows matter: a real
%   mission plans downlink (and any payload-on duty cycling) around when
%   the ground station can actually see the satellite. This function
%   captures that previously-discarded analysis and turns it into a
%   simple "time until next ground contact" figure for the dashboard,
%   using the standard Aerospace/Satellite Communications Toolbox
%   accessIntervals function:
%
%       ac = access(sat,gs);
%       intvls = accessIntervals(ac);
%
%   which returns a table of access windows (StartTime/EndTime/Duration).
%
% Inputs:
%   accessObj - Access object returned by access(sat,gs)
%   startTime - scenario start datetime (UTC), used to convert interval
%               start/end times into "minutes since mission start"
%
% Output: contactInfo struct array, one row per access interval, with
%   fields startMin, endMin, durationMin (all in mission-elapsed minutes).
%   Empty struct array if no access intervals are found or the toolbox
%   call is unavailable (feature degrades gracefully -- dashboard simply
%   omits the ground-contact KPI in that case).

    contactInfo = struct('startMin',{}, 'endMin',{}, 'durationMin',{});

    try
        intervalTable = accessIntervals(accessObj);
    catch
        return;   % Satellite Communications/Aerospace Toolbox access analysis unavailable
    end

    if isempty(intervalTable)
        return;
    end

    for i = 1:height(intervalTable)
        startMin = minutes(intervalTable.StartTime(i) - startTime);
        endMin   = minutes(intervalTable.EndTime(i) - startTime);
        contactInfo(end+1) = struct( ...                          %#ok<AGROW>
            'startMin', startMin, ...
            'endMin', endMin, ...
            'durationMin', endMin-startMin); %#ok<AGROW>
    end
end
