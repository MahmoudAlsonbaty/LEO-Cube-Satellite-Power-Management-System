function [illumFrac, info] = computeIlluminationProfile(sat, startTime, timeMin, orbitElements, preferToolboxEclipse)
% computeIlluminationProfile
% -------------------------------------------------------------------------
% Returns a continuous solar-illumination fraction (0 = full umbra eclipse,
% 1 = full sunlight, fractional = penumbra/antumbra) sampled at each time
% in timeMin (minutes since startTime).
%
% WHY THIS FUNCTION EXISTS (V12 fix -- replaces the old useProject7030 /
% hand-rolled "x<0" eclipse heuristics in V11):
%
%   V11 computed eclipse with one of two heuristics, selected by a flag:
%     (a) a fixed 70-min-sun / 30-min-eclipse DUTY CYCLE with no relation
%         at all to the satellite's actual inclination, RAAN, or the real
%         Sun position on the chosen date, and
%     (b) a "circular" x<0 check on a synthetic theta angle that also had
%         no link to the real Sun direction.
%   Both produced an INSTANTANEOUS step in solar input (120 ADC <-> 900 ADC
%   with nothing in between), which is exactly the kind of "too good to be
%   true / anomalously smooth, unrealistically sharp transition" behavior
%   called out in the project brief -- real terminator crossings are not
%   step functions, and the eclipse fraction of a real orbit depends on
%   the beta angle (Sun-orbit-plane geometry), which drifts day to day.
%
%   This function fixes that two ways:
%
%   PRIMARY PATH (when available): Aerospace Toolbox's real eclipse
%   analysis -- eclipse(sat) + eclipseStatus(eclObj, datetime) -- which
%   uses JPL ephemeris data (via aeroDataPackage) and a dual-cone shadow
%   model. This is the most physically accurate option and naturally
%   returns fractional values through penumbra/antumbra, so the smoothing
%   is "real" rather than synthetic. This requires:
%       - Aerospace Toolbox installed, AND
%       - ephemeris data downloaded once via the Add-On Explorer
%         (run >> aeroDataPackage in MATLAB and follow the prompts).
%
%   FALLBACK PATH (always available, no extra installs): an analytic
%   beta-angle / cylindrical-shadow-model calculation using only the
%   satellite's actual orbital elements and a low-precision (~0.01 deg)
%   solar position formula (Sun position from day count, no ephemeris
%   files needed). This gives the physically-correct ORBIT-AVERAGED
%   eclipse fraction and duration for the real inclination/RAAN/altitude
%   in use (NOT a hardcoded 30%), with a short logistic smoothing window
%   at the umbra edges so the handoff is not an instantaneous step.
%   NOTE: unlike the toolbox path, this fallback does not pin down the
%   exact orbital phase/timestamp of eclipse entry to real-world ephemeris
%   precision -- it gets the duration/fraction right and gives a smooth,
%   repeatable transition, which is what the dashboard/firmware need, but
%   for survey-grade timestamp accuracy use the toolbox path.
%
% Inputs:
%   sat           - Satellite object already added to a satelliteScenario
%                   Pass [] to force the analytic path.
%   startTime     - datetime, scenario start (UTC)
%   timeMin       - 1xN vector, minutes since startTime to evaluate
%   orbitElements - struct with fields:
%                     .inclination_deg
%                     .raan_deg
%                     .altitude_m
%   preferToolboxEclipse - optional logical. Default is false in V16 because
%                   eclipseStatus can spend a long time indexing ephemeris
%                   coefficients when sampled point-by-point during startup.
%                   Set true only for offline high-fidelity validation.
%
% Outputs:
%   illumFrac - 1xN vector in [0,1], 1 = full sunlight, 0 = full umbra
%   info      - struct with diagnostic fields:
%                 .source       'toolbox-dual-cone' or 'analytic-fallback'
%                 .betaDeg      beta angle used by the fallback (NaN if
%                               toolbox path was used)
%                 .eclipseFracOrbit  fraction of orbit period in shadow
%                                    (fallback only; NaN otherwise)

    if nargin < 5
        preferToolboxEclipse = false;
    end

    N = numel(timeMin);
    illumFrac = ones(1,N);
    info = struct('source','', 'betaDeg',NaN, 'eclipseFracOrbit',NaN, ...
                  'toolboxAttempted',false, 'toolboxError','');

    usedToolbox = false;

    % ---------------------------------------------------------------
    % OPTIONAL PATH: real Aerospace Toolbox eclipse analysis
    % ---------------------------------------------------------------
    % V16 FIX:
    % Your Ctrl+C stack showed:
    %   computeIlluminationProfile -> eclipseStatus -> Simulator/advance ->
    %   planetEphemeris -> ephSelect -> indexing
    % This means MATLAB was not missing ephemeris data; it was spending time
    % indexing/initializing the high-fidelity ephemeris-driven eclipse model.
    % For a live one-orbit dashboard, repeatedly calling eclipseStatus during
    % startup is the wrong path. The analytic model below is now the default.
    % The toolbox path remains available only when explicitly requested.
    if preferToolboxEclipse && ~isempty(sat)
        info.toolboxAttempted = true;
        try
            eclObj = eclipse(sat);

            % One vector/history query is much safer than looping over every
            % sample. MathWorks documents eclipseStatus(eclObj) as returning the
            % whole history from StartTime to StopTime when AutoSimulate is true.
            % If that history matches the dashboard grid, use it. Otherwise fall
            % back without delaying the live path.
            statusHistory = eclipseStatus(eclObj);
            statusHistory = double(statusHistory(:).');

            if numel(statusHistory) == N
                illumFrac = max(0,min(1,statusHistory));
                usedToolbox = true;
                info.source = 'toolbox-dual-cone-history';
            else
                info.toolboxError = sprintf('eclipseStatus returned %d samples; dashboard expected %d.',numel(statusHistory),N);
                usedToolbox = false;
            end
        catch ME
            % Aerospace Toolbox not installed, ephemeris data not downloaded,
            % eclipse() unsupported, or ephemeris indexing too slow/interrupted.
            % Do not propagate the error; use the analytic model below.
            usedToolbox = false;
            info.toolboxError = ME.message;
        end
    end

    % ---------------------------------------------------------------
    % DEFAULT PATH: analytic beta-angle cylindrical-shadow model
    % ---------------------------------------------------------------
    if ~usedToolbox
        [illumFrac, betaDeg, eclipseFracOrbit] = analyticIlluminationProfile( ...
            startTime, timeMin, ...
            orbitElements.inclination_deg, orbitElements.raan_deg, ...
            orbitElements.altitude_m, 0.35);
        info.source = 'analytic-fallback';
        info.betaDeg = betaDeg;
        info.eclipseFracOrbit = eclipseFracOrbit;
    end
end

% =========================================================================
% LOCAL FUNCTION: analytic fallback (no toolbox / ephemeris data required)
% =========================================================================
function [illumFrac, betaDeg, eclipseFracOrbit] = analyticIlluminationProfile( ...
    startTime, timeMin, inclination_deg, raan_deg, altitude_m, rampMin)

    Re = 6371e3;                       % Earth mean radius, m
    muEarth = 3.986004418e14;          % m^3/s^2
    a = Re + altitude_m;
    periodMin = 2*pi*sqrt(a^3/muEarth)/60;

    % --- Low-precision Sun position (good to ~0.01 deg; no ephemeris
    %     files needed). Source: standard low-precision solar coordinates
    %     formula (e.g. Astronomical Almanac low-precision formulas). ---
    n = days(startTime - datetime(2000,1,1,12,0,0,'TimeZone','UTC'));
    L = mod(280.460 + 0.9856474*n, 360);
    g = mod(357.528 + 0.9856003*n, 360);
    lambdaSun = L + 1.915*sind(g) + 0.020*sind(2*g);
    epsObliquity = 23.439 - 0.0000004*n;

    sunVec = [cosd(lambdaSun), ...
              cosd(epsObliquity)*sind(lambdaSun), ...
              sind(epsObliquity)*sind(lambdaSun)];

    % Orbit-normal (angular momentum) unit vector in ECI for the given
    % inclination & RAAN (argument of periapsis / true anomaly do not
    % affect the orbit plane orientation, only where the satellite sits
    % within it).
    hHat = [sind(inclination_deg)*sind(raan_deg), ...
            -sind(inclination_deg)*cosd(raan_deg), ...
            cosd(inclination_deg)];

    betaDeg = asind(dot(hHat, sunVec));
    betaCritDeg = asind(Re/a);

    N = numel(timeMin);
    illumFrac = ones(1,N);

    if abs(betaDeg) >= betaCritDeg
        % Beta angle too steep -- the orbit plane never dips into Earth's
        % shadow cylinder. Physically correct outcome: no eclipse at all.
        eclipseFracOrbit = 0;
        return;
    end

    ratio = sqrt(a^2 - Re^2) / (a*cosd(betaDeg));
    ratio = max(-1, min(1, ratio));
    halfAngleDeg = acosd(ratio);
    eclipseFracOrbit = (2*halfAngleDeg) / 360;

    eclipseDurMin = eclipseFracOrbit * periodMin;
    sunlitDurMin  = periodMin - eclipseDurMin;

    % Build a smooth (logistic-edged) trapezoid, periodic with the orbit:
    % illumFrac = 1 everywhere except a smoothly-bounded eclipse window of
    % duration eclipseDurMin. rampMin controls the edge sharpness; a few
    % seconds to ~tens of seconds gives a clearly non-instantaneous
    % transition without smearing the eclipse boundary into the rest of
    % the orbit.
    tau = max(rampMin, 1e-3);

    phase = mod(timeMin, periodMin);
    shiftedPhase = mod(phase - sunlitDurMin + periodMin/2, periodMin) - periodMin/2;

    afterFallingEdge  = 0.5*(1 + tanh(shiftedPhase/tau));               % ~0 in sun, ~1 once past eclipse entry
    beforeRisingEdge  = 0.5*(1 - tanh((shiftedPhase - eclipseDurMin)/tau)); % ~1 before eclipse exit, ~0 after
    insideEclipse = afterFallingEdge .* beforeRisingEdge;

    illumFrac = 1 - insideEclipse;
end
