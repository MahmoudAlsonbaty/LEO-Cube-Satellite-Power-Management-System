# CubeSat MATLAB Project - V22 Conventional Baseline Fix

V22 corrects the interpretation problem in the full-mission EPS analysis. A real CubeSat is not normally launched with an always-on payload and an undersized solar array. V22 therefore separates the comparison into three explicit engineering cases:

1. **Managed EPS solution** - the proposed power-management strategy with source-backed array sizing.
2. **Conventional CubeSat EPS** - a realistic baseline with ordinary eclipse safe mode and its own correctly sized solar array.
3. **Same-array no-control stress test** - an intentionally infeasible stress case where all control is removed but the smaller managed-case array is kept.

The stress-test case can report `DESIGN GAP - resize EPS`. That is not a claim that a normal CubeSat would fail; it means the test case is under-sized by construction.

## Run

```matlab
clear classes
clear functions
clear metricsTimer
rehash toolboxcache

addpath(pwd)
addpath(fullfile(pwd,'src'))

RUN_PROJECT
```

Choose option 4:

```text
Run conventional-baseline full-mission EPS comparison
```

## Output files

```text
outputs/mission_power_lifespan_comparison.csv
outputs/mission_power_sizing_reference.csv
outputs/mission_power_daily_managed_3yr.csv
outputs/mission_power_daily_conventional_3yr.csv
outputs/mission_power_daily_same_array_stress_3yr.csv
outputs/mission_power_v22_results.mat
```

## Why this version is more realistic

V21 used the same small solar array for the unmanaged spacecraft, so that case could fail by design. V22 adds the `Conventional CubeSat EPS` case to represent how real missions are normally handled: the baseline is still less efficient than the managed solution, but it is sized with enough solar-array power to survive. The managed solution should show smaller required array power, lower eclipse load, lower DOD, and improved battery-health behavior.

## V23 -- independent technical audit

An independent audit (static code review + numerical cross-validation)
was run against this V22 delivery. Two surgical logic/test fixes were
applied directly (see the `V23 FIX` comments at the listed locations);
the rest are documented findings with recommended fixes, left for you to
apply or decline:

- `src/simulateCubeSatMissionPower.m` (line ~128, ~156): SOC could land
  fractionally below `socMin` after a step-to-step change in available
  battery capacity. Fixed -- floor-and-ceiling clamp applied consistently.
- `validation/crosscheck_firmware.py`: the default `failure_time_min=95`
  exceeded this orbit's ~94.47 min period, so the fault-injection
  regression check silently never exercised the fault. Fixed -- now
  defaults to `0.95*orbitMinutes`, matching production code.
- `src/scenarioApiAvailable.m`, `viewerApiAvailable.m`, `functionAvailable.m`:
  de-duplicated out of `ensureAerospaceEphemerisReady.m` and
  `START_TOOLBOX_VIEWER_WITH_METRICS.m`, which previously carried two
  identical, independently-drifting copies of each.
- `START_TOOLBOX_VIEWER_WITH_METRICS.m`: the live dashboard's 5 charts now
  draw their foreground telemetry line progressively (grown frame-by-frame
  to the current sample) instead of pre-plotting the full curve and only
  moving a cursor over it; a muted full-range "preview" curve is kept
  underneath for the V18-intended look-ahead context, now visually
  distinguished from live data. Direction-of-interpretation subtitles
  ("higher is better" / "lower is better" / "context-dependent") were
  added to every chart, here and in the mission-comparison figure.
- See `docs/Power_Metrics_Model_Assumptions_V22.md` for the full
  per-scenario battery/array sizing writeup (including why the
  `Installed_Battery_Margin_pct` column in the sizing CSV looks huge --
  it's informational, the battery hardware is intentionally not resized
  per scenario the way the solar array is) and the literature
  cross-checks performed during the audit.
- `validation_extra/missionpower_crosscheck.py` is a new Python port of
  `simulateCubeSatMissionPower.m`, closing the one validation gap left
  after V12 (every other major file already had a Python cross-check;
  this was the most mathematically complex file in the project and had
  none). It is what caught the SOC floor-clamp issue above.
