# Notes

## Synchronization strategy

The dashboard is synchronized by reading `sc.SimulationTime` during official
viewer playback. This is smoother than manually advancing the scenario
because the viewer controls its own playback.

V12 adds one more piece of consistency on top of this: the scenario's
sample time and the firmware model's timestep are now derived from the
*same* variable (`sampleTimeSeconds` in `START_TOOLBOX_VIEWER_WITH_METRICS.m`),
and the displayed orbit length is the satellite's true Keplerian period
rather than a hand-picked number. Neither of those changes the sync
*mechanism* (still `sc.SimulationTime` read at a fixed dashboard refresh
rate) -- they remove two sources of mismatch between what the viewer is
actually propagating and what the dashboard assumes it is propagating.

## Limits

If the user manually pauses or drags the viewer timeline, the dashboard will
follow whatever `sc.SimulationTime` reports. For presentation, start from
the beginning and let the script run.

The analytic eclipse fallback (used automatically when the Aerospace
Toolbox eclipse path is unavailable -- see
`docs/Toolbox_Integration_Notes.md`) gets the eclipse *duration and
fraction* right for the satellite's real orbital geometry, but does not
pin the eclipse to the exact real-world orbital phase/timestamp the way
the toolbox's ephemeris-based path does. For a class demo or presentation
this is not noticeable; for anything requiring survey-grade timing
accuracy, install the ephemeris data (`aeroDataPackage`) so the toolbox
path is used instead.

## What we could not verify in this delivery

This refactor was produced and reviewed without access to a licensed
MATLAB installation (no MATLAB engine was available in the environment
this work was done in). Everything here was validated as far as possible
without one:

- The new/changed control-flow logic was cross-checked by porting it to
  Python and running it end-to-end across all three failure modes (see
  `/validation/` in this delivery) -- this is what caught the numerical
  instability bug described in `simulateCubeSatSubsystem.m`'s header.
- Every `.m` file was run through a structural linter
  (`/validation/matlab_lint.py`) that checks for balanced parentheses/
  brackets/braces, balanced string quoting (including MATLAB's transpose-
  vs-string-quote ambiguity and doubled-quote escaping), and balanced
  if/for/while/switch/function/try...end block nesting.

Neither of those is a substitute for actually running the files in
MATLAB. Please run `RUN_PROJECT` end-to-end once after pulling this update
and treat the first run as a verification pass, not just a demo -- if
anything doesn't run cleanly (missing toolbox, a typo that slipped past
the checks above, etc.), that's the most useful next bug report.

**Update from the first real run (V12.1):** exactly this happened.
`satelliteScenarioViewer(sc,'ShowDetails',true)` failed on the first
real-world run with "Ephemeris data is not available on the MATLAB
path." This was not something I could have caught with Python or a
structural linter -- it's a runtime dependency on data that has to be
downloaded separately per machine (`aeroDataPackage`), and it turned out
to affect the viewer itself, not just the `eclipse()` refinement path
(which was already designed to fall back gracefully). The fix added in
response: a fast pre-flight check that warns immediately (instead of
after the full setup sequence runs), an automatic retry of the viewer
without `ShowDetails` if the ephemeris error occurs, and a clear,
actionable final error (pointing at `aeroDataPackage`) if even that
fails. See `START_TOOLBOX_VIEWER_WITH_METRICS.m`'s `probeEphemerisAvailable`
and the `satelliteScenarioViewer` try/catch block. This is the kind of
issue that only surfaces by actually running the code -- a second reason
(beyond the validation scripts above) why a real MATLAB run is the
authoritative check, not anything in this repo's own self-checks.
