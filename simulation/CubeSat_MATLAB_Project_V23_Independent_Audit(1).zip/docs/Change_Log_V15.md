# Change Log V15 - Method-aware Satellite Scenario Viewer Detection

## Fix
- Corrected false `satelliteScenarioViewer: NO` reports when MATLAB returns a valid
  method path under `@satelliteScenario`.
- Updated `START_TOOLBOX_VIEWER_WITH_METRICS.m` so the official viewer is attempted
  when `which('satelliteScenarioViewer')` returns a valid path.
- Updated `src/ensureAerospaceEphemerisReady.m` to distinguish a missing viewer from
  a class-method viewer implementation.

## Why
In MATLAB R2025b, `satelliteScenarioViewer` may be implemented as a method of the
`satelliteScenario` class. A normal top-level `exist(name,'file')` check can return
false for class methods even though `satelliteScenarioViewer(sc,...)` is callable.
The previous V14 gate incorrectly forced dashboard-only mode in that case.

## Expected diagnostic
Your current output should change from:

```text
satelliteScenarioViewer:     NO
satelliteScenarioViewer path: ...@satelliteScenario\satelliteScenarioViewer.p
```

to:

```text
satelliteScenarioViewer:     YES
satelliteScenarioViewer path: ...@satelliteScenario\satelliteScenarioViewer.p
```

The `eclipse/eclipsestatus path` may still be `NO`; that only controls whether the
illumination model uses toolbox dual-cone eclipse analysis or the analytic beta-angle
fallback. It should not prevent the official viewer from opening.
