# Change Log V17 - Viewer Clock Synchronization Fix

## Problem observed
The official `satelliteScenarioViewer` opened and animated correctly, but the dashboard stayed static.

## Root cause
The V16 dashboard timer read `sc.SimulationTime`. In R2025b, the visible animation time is exposed on the `satelliteScenarioViewer` object as `viewer.CurrentTime`. During `play(sc,PlaybackSpeedMultiplier=...)`, `sc.SimulationTime` can remain fixed from the dashboard timer's perspective, so the dashboard always selected the first telemetry sample.

## Fix
`START_TOOLBOX_VIEWER_WITH_METRICS.m` now uses a three-stage clock selection:

1. Primary: `viewer.CurrentTime` when the official viewer is active.
2. Secondary: `sc.SimulationTime` for manual/advance workflows.
3. Final fallback: internal wall-clock mission time using the same playback speed.

This keeps the official viewer and dashboard synchronized while guaranteeing that the dashboard continues updating even if the MATLAB-side viewer clock is unavailable.
