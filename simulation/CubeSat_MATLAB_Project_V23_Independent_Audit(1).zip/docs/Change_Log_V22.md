# Change Log - V22 Conventional Baseline Fix

## Reason for change

The previous same-hardware no-management case could look like an unrealistic claim that a normal CubeSat would fail. In reality, a CubeSat would not usually be launched with an always-on load and an undersized solar array. Engineers would resize the array, increase battery capacity, reduce duty cycle, or add safe-mode behavior.

## Changes

- Added `Conventional CubeSat EPS` as a realistic comparison case.
- Kept `Same-array no-control stress test` as a diagnostic stress test only.
- Renamed stress-test energy deficits to `DESIGN GAP - resize EPS` instead of a normal mission `FAIL`.
- Updated daily CSV names to avoid implying the stress test is a regular baseline.
- Updated the plot titles and legends to separate the conventional baseline from the intentionally under-sized stress case.

## Engineering interpretation

- `Managed EPS solution`: proposed improved control strategy.
- `Conventional CubeSat EPS`: normal baseline that should be sized to pass.
- `Same-array no-control stress test`: answers the design question, “How much control benefit do we lose if we remove power management but keep the smaller hardware?”
