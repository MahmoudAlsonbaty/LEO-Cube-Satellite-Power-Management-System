# Toolbox Integration Notes

This is the requested summary of which toolbox features were integrated,
why, and how -- for future reference.

## A note on "CubeSat Toolbox" first

The brief asked to review "Aerospace Toolbox and CubeSat Toolbox" for
useful functions. We checked: **there is no MathWorks product called
"CubeSat Toolbox."** The only product with that name is a separate, paid,
third-party toolbox sold by Princeton Satellite Systems, licensed per
university CubeSat team, focused on attitude control (magnetic torquers,
magnetic hysteresis damping rods, etc.) -- it is not part of a standard
MATLAB installation and this project does not assume or require it.

Given that, the toolbox-integration work below uses **Aerospace Toolbox**
and **Satellite Communications Toolbox** functionality, both of which are
already implied by the project's existing use of `satelliteScenario`,
`satellite`, `groundStation`, and `satelliteScenarioViewer`.

## Feature 1: Real eclipse analysis (`eclipse` / `eclipseStatus`)

**What it is:** Aerospace Toolbox's eclipse-analysis object, added to a
`Satellite` via `eclipse(sat)`, queried via
`[status,datetimeOut] = eclipseStatus(eclObj, datetimeIn)`. By default it
uses a **dual-cone shadow model**: status is 1 in full sunlight, 0 in full
umbra, and a fraction in between during penumbra/antumbra -- exactly the
continuous signal needed to fix the "instantaneous eclipse step" issue
described in `docs/Firmware_Issues_and_Fixes.md`.

**Why it's high-impact:** It directly replaces a hardcoded 70/30 duty-cycle
guess with the actual physical eclipse geometry for the satellite's real
orbital elements and the scenario's real epoch, including penumbra, which
a simple binary model cannot represent at all.

**Requirements / caveat:** This function requires ephemeris data, which is
**not** bundled with a default MATLAB install. From the MATLAB Command
Window:

```matlab
aeroDataPackage
```

and follow the Add-On Explorer prompts to download the ephemeris data
package. Without this, `eclipse()`/`eclipseStatus()` will error.

**How this project handles that gracefully:**
`src/computeIlluminationProfile.m` wraps the toolbox call in `try/catch`
and falls back automatically (see Feature 1b) if it's unavailable for any
reason -- toolbox not installed, ephemeris not downloaded, or any other
runtime error. `check_CubeSat_Project_Toolboxes.m` (option 3 in
`RUN_PROJECT`) now also actively probes this path and tells you up front
which one you're going to get, rather than leaving you to discover it from
a console message after the dashboard is already open.

## Feature 1b: Analytic beta-angle fallback (no extra installs required)

**What it is:** When the toolbox path above is unavailable,
`computeIlluminationProfile.m` computes the eclipse fraction analytically
using the classic beta-angle / cylindrical-shadow-model relationship:

```
beta = angle between the orbit-normal vector and the Sun direction
beta_crit = asin(Re / a)                      (no eclipse possible if |beta| >= beta_crit)
half-angle of orbit in shadow = acos( sqrt(a^2-Re^2) / (a*cos(beta)) )
eclipse fraction = 2*half-angle / 360
```

with the Sun direction computed from a standard low-precision solar
position formula (good to about 0.01°, no ephemeris files required -- just
the date). This is real orbital mechanics tied to the satellite's actual
inclination/RAAN/altitude and the scenario's actual epoch -- not a
hardcoded percentage -- it is just less precise than the toolbox's
ephemeris-based dual-cone model about exactly *when within the orbit* the
edges fall, and doesn't model the Moon as a secondary occulting body the
way the toolbox path optionally can.

**Numerically verified result for this project's orbit/epoch**
(`/validation/crosscheck.py`): beta ≈ -28.0°, eclipse fraction ≈ 36.1% of
the orbit (≈34.1 min eclipse / ≈60.4 min sunlit) -- for comparison, V11's
hardcoded assumption was exactly 30%.

## Feature 2: Surfacing the discarded ground-station access analysis

**What it is:** V11 already called:

```matlab
access(sat,gs);
```

to compute line-of-sight access between the satellite and the Cairo
ground station -- but it never captured the returned `Access` object, and
nothing downstream ever used it. The access analysis was being computed
and then thrown away every run.

**Why it's high-impact for a power-subsystem study specifically:** ground
contact windows are directly relevant to power budgeting -- a real mission
plans downlink (and often any payload-on duty cycling) around when the
ground station can actually see the satellite. Surfacing this costs
nothing extra to compute (it was already being computed) and turns an
unused side effect into a useful KPI.

**Implementation:** `src/computeNextGroundContact.m` captures the `Access`
object, calls the standard `accessIntervals(ac)` function to get a table
of contact windows, and converts it into a simple struct array of
mission-elapsed-minute windows. The dashboard's new 5th KPI card ("Next
contact") shows either "IN VIEW (Ns left)" or "in X.X min" by checking the
current mission time against this table.

**Degrades gracefully:** if `access`/`accessIntervals` is unavailable for
any reason, `computeNextGroundContact.m` catches the error and returns an
empty list; the dashboard just shows "n/a" for that KPI instead of failing.

## Why these two and not something else

The brief asked for 1-2 high-impact features "without overcomplicating."
Both features chosen here build directly on toolbox objects the project
was **already creating** (`access(sat,gs)`) or **already structurally set
up to use** (a satellite in a `satelliteScenario`, which is exactly what
`eclipse()` needs) -- rather than bolting on an unrelated capability (e.g.
full atmospheric drag modeling, which would meaningfully change the orbit
propagation and go well beyond "fix what exists"). Both also directly
served one of the brief's other objectives (Feature 1 fixes the eclipse
physics objective; Feature 2 is genuinely useful for the stated
power-subsystem framing), rather than being added just to demonstrate
toolbox breadth.

## Other toolbox capabilities reviewed but not integrated (for the record)

- **Atmospheric drag / `atmosnrlmsise00`, magnetic field models
  (`igrfmagm`), etc.:** relevant to attitude/orbit-perturbation studies,
  not to a sensor-payload power-gating study at 500 km over a single
  ~95-minute orbit where drag's effect on the displayed trajectory is
  negligible. Flagged as a reasonable extension if the project later grows
  into a multi-orbit decay study.
- **SGP4/SDP4 propagators / TLE import:** the project already uses
  `two-body-keplerian` propagation from designed orbital elements, which is
  appropriate for a from-scratch CubeSat design exercise (no real-world TLE
  to import). Not a fit here.
- **Lunar eclipse option on the `eclipse()` call
  (`IncludeLunarEclipse=true`):** technically available, but lunar eclipses
  of a LEO CubeSat are extremely rare/brief and would add visual/logical
  complexity (a third "EclipsingBody" case) for negligible benefit at this
  altitude and timescale -- left off by default, but it's a one-argument
  change in `computeIlluminationProfile.m` if a future use case wants it.
