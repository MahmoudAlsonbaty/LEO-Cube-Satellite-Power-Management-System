# Dashboard Redesign Notes

This covers the "redesigned metrics dashboard" deliverable. The V11
dashboard was already a reasonably well-built dark-theme layout (hero
cards, KPI cards, progress bars, four time-series charts); V12 made
targeted changes rather than a ground-up redesign, per the brief's
"fix and enhance what exists rather than redesigning from scratch."

## What changed visually

1. **Environment timeline is now a real curve, not a stairstep.**
   This is the most visually important change, because it's the one that
   makes the eclipse-model fix (see `Firmware_Issues_and_Fixes.md`)
   actually *visible*: the bottom strip now plots the continuous
   illumination fraction (0=eclipse, 1=sun) as a smooth line crossing a
   dotted 0.5 reference, instead of a binary stairstep that snapped
   instantly between the two states. The chart title also names which
   eclipse model is currently active (`toolbox-dual-cone` or
   `analytic-fallback`), so a viewer of the dashboard can see at a glance
   which fidelity level is in use without checking the console output.

2. **A 5th KPI card: "Next contact."** The KPI row was widened from four
   17-22-unit cards to five 17-unit cards (with proportionally smaller
   gaps) to fit the new ground-contact KPI from
   `src/computeNextGroundContact.m` without disturbing the rest of the
   layout grid. It shows `IN VIEW (Ns left)` during a contact window, or
   `in X.X min` counting down to the next one.

3. **Hero-card subtitle text now reports live illumination percentage**
   (e.g. "solar input 82% (analytic-fallback)") instead of a flat
   "ECLIPSE"/"SUNLIGHT" label with no numeric detail -- consistent with
   making the now-continuous signal visible everywhere it appears, not
   just on the timeline chart.

## What was deliberately left alone

- Overall card-based layout, color theme (`getTheme()`), font choices, and
  the four main time-series charts (current, temperature, rail voltage,
  cumulative energy) are unchanged in structure -- they were already
  clear and presentation-appropriate. Only the data feeding them changed
  (per the firmware fixes), not their layout.
- The mode/eclipse hero cards' size and position are unchanged; only their
  subtitle text gained more detail.

## A mockup, since no MATLAB run was possible here

This delivery was produced without access to a licensed MATLAB
installation (see `Notes.md`), so no real screenshot of the running
dashboard could be captured. An inline visual mockup of the redesigned
layout (matching the actual card positions/colors/labels used in
`START_TOOLBOX_VIEWER_WITH_METRICS.m`) was provided alongside this
delivery to preview the redesign before you run it yourself -- but it is
a static mockup built to match the code, not a captured screenshot of
the real, running figure. Treat the actual `RUN_PROJECT` -> option 1
output in MATLAB as the source of truth.
