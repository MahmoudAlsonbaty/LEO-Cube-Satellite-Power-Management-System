# Power Metrics Source Background - V20

V20 corrects the V19 power-metrics workflow. V19 compared a managed EPS solution with a no-solution baseline, but the installed solar-array power was set too close to the mission load. That caused every life-span case to fail and made the graphs look physically wrong.

## What changed

1. **Source-backed orbit energy sizing first**
   - New function: `src/estimateCubeSatEPSPowerBudget.m`.
   - Uses the standard orbit power-budget relation:

     `Psa = ((Pe*Te/Xe) + (Pd*Td/Xd)) / Td`

     where:
     - `Pe` = eclipse load power,
     - `Pd` = daylight load power,
     - `Te` = eclipse duration,
     - `Td` = daylight duration,
     - `Xe` = storage path efficiency from solar array through battery to loads,
     - `Xd` = direct daylight path efficiency.

2. **Same hardware, two control policies**
   - The installed BOL solar array is sized for the managed solution with design margin.
   - The no-solution baseline uses the same installed solar array and battery.
   - This makes the comparison fair: hardware is held constant and only the EPS control policy changes.

3. **Battery sizing check**
   - The model reports required battery Wh at the selected target orbit DOD.
   - The default target orbit DOD is 30%, inside the commonly used shallow-DOD design band for LEO CubeSat Li-ion operation.

4. **Clearer graphs**
   - SOC is now plotted as daily min/mean/max envelopes instead of plotting every 5-minute point over three years.
   - A solar-array sizing bar chart compares managed required array, installed hardware, and no-solution required array.
   - Energy-margin, DOD, and battery-health plots are shown separately.

## Why the V19 output failed every case

The V19 installed array was 8 W. With pointing loss, MPPT efficiency, panel temperature derating, eclipse fraction, and solar aging, that was not enough for the assumed system-level load. The result was a continuous small daily energy deficit; once the battery reached its SOC floor, unmet energy accumulated from day 30 onward.

V20 does not hide this. It prints the required BOL solar array for both cases and the installed margin. If a case fails, the sizing table shows whether the cause is solar undersizing, battery margin, low SOC, or end-of-life health.

## Outputs

- `outputs/mission_power_lifespan_comparison.csv`
- `outputs/mission_power_sizing_reference.csv`
- `outputs/mission_power_daily_managed_3yr.csv`
- `outputs/mission_power_daily_baseline_3yr.csv`
- `outputs/mission_power_v20_results.mat`

## Important limitations

This is still a trade-study model, not a certified flight EPS model. Replace the defaults with:

- measured solar panel IV curves,
- attitude-specific sun incidence profiles,
- EPS converter efficiency maps,
- vendor battery cell aging curves,
- mission-specific payload duty cycle,
- thermal model outputs for battery and panel temperatures.
