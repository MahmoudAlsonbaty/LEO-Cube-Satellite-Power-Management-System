# Full-Mission CubeSat Power Metrics

## New entry point

Use menu option 4 from `RUN_PROJECT`, or run directly:

```matlab
RUN_FULL_MISSION_POWER_METRICS
```

The runner creates a representative one-orbit illumination/firmware profile using the existing project architecture, then calls:

```matlab
simulateCubeSatMissionPower(orbitSim, missionConfig)
```

The default mission duration is 365 days with a 60-second EPS timestep.

## Outputs

The runner writes:

```text
outputs/mission_power_daily_summary.csv
outputs/mission_power_results.mat
```

It also opens a MATLAB figure showing:

- Battery SOC over mission time.
- Battery and solar-array health degradation.
- Equivalent full cycle tracking.
- Generated power versus load power.
- Battery and solar-panel temperature profiles.
- Daily generated, consumed, and unmet energy.

## Mode-dependent load model

The model uses the same firmware mode names as the dashboard:

- `BOOT`
- `PAYLOAD ON`
- `ECLIPSE SLEEP`
- `THERMAL PROTECT`
- `BACKUP SAFE`

Each mode maps to a configurable spacecraft load power in `simulateCubeSatMissionPower.m`. The existing 3.3 V payload rail current from `simulateCubeSatSubsystem.m` is also included in the `PAYLOAD ON` load term.

## Battery model

Battery state-of-charge is propagated from generated solar energy minus spacecraft load energy, including charge/discharge efficiency and EPS distribution efficiency.

Capacity degradation has two permanent components:

1. **Calendar fade** accelerated by battery temperature with a Q10 model.
2. **Cycle fade** from cumulative equivalent-full-cycle throughput.

The model also applies instantaneous temperature derating to available capacity: cold batteries and hot batteries are less effective even before permanent aging is counted.

## Solar-array model

Solar power is computed from nominal panel power, illumination fraction, MPPT efficiency, panel temperature derating, and permanent solar-array health.

Solar health decreases from:

1. **Radiation/time aging**, represented as a configurable yearly degradation rate.
2. **Thermal-cycle fatigue**, incremented at each sunlight/eclipse transition.

## Configuration

Edit these values in `RUN_FULL_MISSION_POWER_METRICS.m` before calling the simulator:

```matlab
missionConfig.missionDurationDays = 365;
missionConfig.missionStepSeconds = 60;
missionConfig.batteryNominalCapacityWh = 20.0;
missionConfig.solarNominalPowerW = 8.0;
missionConfig.initialSOC = 0.85;
```

More detailed parameters have defaults inside `src/simulateCubeSatMissionPower.m` and can be overridden by adding fields to `missionConfig`.
