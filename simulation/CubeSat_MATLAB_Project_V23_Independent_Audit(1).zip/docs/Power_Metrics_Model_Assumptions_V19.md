# V19 CubeSat EPS Power Metrics Rework

## Purpose

V19 replaces the earlier single-scenario full-mission EPS model with a comparison-based model. The code now evaluates the managed CubeSat power solution against a no-power-management baseline over several mission life spans: 30, 90, 180, 365, 730, and 1095 days.

The live 3-D viewer remains a one-orbit presentation tool. The full mission EPS model is an offline trade-study runner launched from `RUN_PROJECT` option 4 or directly with `RUN_FULL_MISSION_POWER_METRICS`.

## Literature basis used for the model structure

The model is intentionally built around the same engineering drivers emphasized in CubeSat EPS literature:

- CubeSat EPS design must consider generation, storage, power distribution, efficiency, reliability, and battery sizing for mission duration. IEEE CubeSat EPS architecture reviews describe EPS as a key subsystem because it generates, stores, and distributes power to all other subsystems.
- Battery mission profiles in LEO are strongly driven by current rate, temperature, depth of discharge, and the number of charge/discharge cycles.
- Shallow depth of discharge is preferred in LEO CubeSat batteries. A commonly cited operating range is about 10% to 40% DOD to support sufficient cycle life.
- Small spacecraft power systems typically combine solar arrays, power management/distribution electronics, and rechargeable batteries.
- Solar array output depends on illumination, incidence/pointing, thermal behavior, conversion efficiency, and degradation over the mission lifetime.

## Scenarios

### Managed EPS solution

This scenario uses the existing firmware mode logic:

- `BOOT`
- `PAYLOAD ON`
- `ECLIPSE SLEEP`
- `THERMAL PROTECT`
- `BACKUP SAFE`

It also uses a conservative SOC operating band of 20% to 90%. This represents active power management intended to reduce eclipse load, prevent unnecessary payload operation, and avoid excessive depth of discharge.

### No power-management baseline

This scenario keeps the payload/bus load powered through eclipse and thermal periods. It uses a wider 5% to 100% SOC band to represent a less protective control policy. The same nominal battery and solar-array hardware envelope is used so the comparison highlights the effect of the management strategy, not a different spacecraft design.

## Reworked metrics

The V19 model reports the following metrics:

- Final SOC, minimum SOC, and mean SOC.
- Generated, consumed, excess, and unmet energy.
- Energy balance across the mission.
- Battery health and solar-array health at each life span.
- Equivalent full cycles.
- Weighted cycle damage EFC, which penalizes deeper DOD and higher C-rate.
- Mean and maximum orbit DOD.
- Low-SOC exposure hours.
- Thermal-limit exposure hours.
- Battery and panel temperatures.
- Mission status: PASS, marginal, or fail.

## Files changed

- `src/simulateCubeSatMissionPower.m`
  - Replaced the previous linear-ish degradation model with a scenario-based EPS model.
  - Added SOC-band effects, DOD stress, C-rate stress, high/low SOC calendar stress, temperature acceleration, and separate battery/solar degradation states.

- `RUN_FULL_MISSION_POWER_METRICS.m`
  - Now runs both managed and no-solution scenarios.
  - Sweeps 30, 90, 180, 365, 730, and 1095 days.
  - Exports comparison CSV and 3-year daily CSV files.
  - Generates a comparison figure.

- `RUN_PROJECT.m`
  - Title updated to V19.

## Outputs

Running `RUN_FULL_MISSION_POWER_METRICS` creates:

- `outputs/mission_power_lifespan_comparison.csv`
- `outputs/mission_power_daily_managed_3yr.csv`
- `outputs/mission_power_daily_baseline_3yr.csv`
- `outputs/mission_power_v19_results.mat`

## Important limitation

The default parameters are engineering assumptions for trade-study visualization. For a flight design, replace them with measured or vendor-provided values for:

- Battery cell type, capacity, internal resistance, cycle-life curve, and thermal model.
- Solar-cell beginning-of-life and end-of-life power data.
- EPS converter efficiencies.
- Payload duty cycle and measured bus load.
- Attitude profile and solar incidence profile.
- Radiation environment for the selected orbit.
