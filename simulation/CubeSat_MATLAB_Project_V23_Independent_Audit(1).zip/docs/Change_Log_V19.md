# Change Log V19 - Power Metrics Rework

## Main goal

Rework the CubeSat power metrics because the earlier long-duration EPS model was too simple and did not clearly compare the proposed power-saving solution against the no-solution baseline.

## Major changes

1. Added a managed-vs-baseline EPS comparison.
2. Added life-span sweep: 30, 90, 180, 365, 730, and 1095 days.
3. Reworked battery aging into separate terms:
   - cycle aging,
   - calendar aging,
   - temperature acceleration,
   - DOD stress,
   - C-rate stress,
   - high-SOC and low-SOC calendar stress.
4. Reworked solar-array modeling into separate terms:
   - radiation/time degradation,
   - thermal-cycle degradation,
   - panel-temperature power derating.
5. Added mission risk/status classification.
6. Added exported comparison tables and daily 3-year summaries.
7. Kept the live viewer and dashboard workflow unchanged.

## New output files

- `outputs/mission_power_lifespan_comparison.csv`
- `outputs/mission_power_daily_managed_3yr.csv`
- `outputs/mission_power_daily_baseline_3yr.csv`
- `outputs/mission_power_v19_results.mat`

## Notes

The model is a configurable engineering trade study. It should be calibrated with real battery, solar-array, and payload measurements before any flight-level conclusion is made.
