# V22/V23 Independent Technical Audit -- CubeSat Power Management Project

Scope: static code review + numerical cross-validation (no licensed MATLAB
engine was available in this environment, same constraint the project's own
`docs/Notes.md` already documents -- the same workaround was used: Python
ports of the key algorithms, run and checked numerically). All findings
below reference exact files/functions/lines as of the V22 delivery
reviewed. Two categories of finding: **(Fixed)** -- a surgical patch was
applied directly to the delivered files, with before/after numerical
confirmation; **(Recommended)** -- a documented finding with a concrete
suggested fix, left for you to apply.

---

## 1. Logic & Battery Verification

### 1.1 SOC floor-clamp edge case -- **Fixed**, MINOR severity
`src/simulateCubeSatMissionPower.m`, ~line 128 and ~line 156.

`storedWh(k)` was carried over from the previous step and clamped only at
the *ceiling* (`socMax*availableCapacityWh(k)`), not the floor. Because
`availableCapacityWh(k)` legitimately moves step-to-step (temperature-driven
`tempCapacityFactor` is recomputed every sample), a transient *increase* in
available capacity while the battery was sitting at the SOC floor could
compute a SOC fractionally *below* the configured floor. Measured before
the fix: 4.98% against a configured 5.00% floor, in the "Same-array
no-control stress test" scenario (which spends long stretches floor-clamped
by design). Fixed by floor-and-ceiling clamping `storedWh(k)` at both
points in the function, confirmed via `validation_extra/missionpower
_crosscheck.py`: minSOC is now exactly 5.00% with no out-of-band excursions
across all 3 scenarios x 6 life spans.

### 1.2 Validated: no NaNs, no runaway values, no out-of-band health
Ran all 3 scenarios (`Managed EPS solution`, `Conventional CubeSat EPS`,
`Same-array no-control stress test`) across all 6 life spans (30/90/180/
365/730/1095 days) via the new Python port. Zero NaNs, zero negative
healths, battery temperature stayed in a physically sane 22-27.4 deg C
range throughout, capacity/solar health never dropped below their
configured floors. This is the most mathematically complex file in the
project (DOD stress, C-rate stress, calendar stress, temperature
acceleration, EFC weighting, all compounding over a 3-year integration)
and it had no prior Python cross-check, unlike the firmware/orbit files --
see `validation_extra/README.md`.

### 1.3 Achieved DOD is far shallower than the model's own sizing target -- **Recommended**, worth a design decision
Measured orbit DOD over a 3-year run: Managed ~1.5% mean / 5% max,
Conventional ~6% mean / 10% max, stress test ~3.4% mean / 16% max -- all
well below both the literature-cited 10-40% LEO guidance (cited in the
project's own `docs/Power_Metrics_Model_Assumptions_V19.md`) and the
model's own `targetOrbitDOD = 0.30` sizing parameter. Root cause: the 24 Wh
battery is a fixed hardware constant shared across all three scenarios
(`RUN_FULL_MISSION_POWER_METRICS.m`, `scenarioConfig()`, line ~190) and is
never resized by `estimateCubeSatEPSPowerBudget.m`'s sizing equation the
way the solar array is. Consequence: cycle-fade aging runs near its floor
(`minDODStressFactor=0.15`) in all three scenarios, so battery aging in
this configuration is calendar-fade-dominated, and the managed-vs-
conventional battery-health gap at 3 years is real but small in absolute
terms (96.8% vs. 95.4%). Not a bug -- a parameterization choice worth a
second look if the goal is to visibly demonstrate the cycle-life benefit of
the managed strategy. See `docs/Power_Metrics_Model_Assumptions_V22.md` for
the full writeup and options.

### 1.4 No other logic/edge-case defects found in the battery/thermal/SOC model
Specifically checked and found correct: SOC is always clamped to [0,
socMax] before this fix and [socMin, socMax] after it; `dodForStress` and
`dodStress` are floored (`minimumDODForAging=0.03`, `minDODStressFactor=
0.15`) to avoid a zero-DOD edge case feeding a fractional power exponent;
battery/solar health floors (`batteryMinHealthFloor=0.55`,
`solarMinHealthFloor=0.70`) are enforced on every assignment; charge/
discharge efficiency temperature penalties are floored at
`batteryMinEfficiency=0.82`; the `headroomWh`/`usableWh` discharge-limiter
logic correctly prevents over-charge/over-discharge within a single step.

### 1.5 Firmware-layer logic (per-orbit model) -- no new defects found
`src/simulateCubeSatSubsystem.m` matches its own documented V12 fixes
exactly (continuous illumination -> ADC -> hysteresis band now genuinely
exercised; exact-exponential lag for thermal/rail/current; reachable BOOT
state). Re-ran the existing `validation/crosscheck_firmware.py` after
fixing the bug described in 5.1 below; firmware mode logic, current/temp/
rail bounds all check out (no NaNs, current in [0.011, 40.1] mA, rail in
[0, 3.3] V, across all three failure modes).

---

## 2. Graph & Visualization Audit

### 2.1 No graph in the project had "higher is better / lower is better / context-dependent" labeling -- **Fixed**
Verified by grep across every `.m` file: zero matches for any such
labeling before this audit, despite it being explicitly requested. Added
direction-of-interpretation subtitles to:
- All 5 live-dashboard charts in `START_TOOLBOX_VIEWER_WITH_METRICS.m`
  (current draw and rail voltage and temperature: context-dependent;
  cumulative energy: lower is better; illumination timeline: informational,
  not a performance metric).
- All 9 panels of the mission-comparison figure in
  `RUN_FULL_MISSION_POWER_METRICS.m` (solar sizing bars: lower required for
  same installed is better; daily margin: higher is better; unmet energy:
  lower is better; the 3 SOC envelope panels: context-dependent, staying
  clear of the floor is the goal; max DOD: lower is better; battery health:
  higher is better; health loss: lower is better).

### 2.2 Axis scale / clipping -- already good, no changes needed
`RUN_FULL_MISSION_POWER_METRICS.m`'s `zoomYAxis()` helper dynamically pads
and floors/ceils every comparison-figure axis so multi-percent changes
(battery health, DOD, SOC) stay visible instead of looking like flat lines
on a 0-100% axis -- this was the explicit fix in V21 (see
`docs/Change_Log_V21.md`) and it works correctly across the ranges actually
produced by the model. The live dashboard's 5 charts use fixed but
data-driven ranges (`max(sim.baselineCurrentmA)*1.15`, etc.) which are
appropriate for a single-orbit live view. No clipping or excessive
whitespace found in either figure.

### 2.3 Titles, units, legends -- complete and consistent
Every chart in both figures has a title, axis labels with units, and (where
more than one series is plotted) a legend; checked for omissions and found
none. Font sizes (7-15pt depending on UI element) and card layout in the
dashboard were checked for off-axes overlap (KPI card x-positions, chart
axes positions, UI-strip y-position) -- no overlaps found; the V12 5-card
KPI resize (`Dashboard_Redesign_Notes.md`) fits cleanly within its allotted
width.

---

## 3. Technical Feasibility Report (with sources)

All cross-checked against literature during this audit (web search,
results below paraphrased and cited by source name -- see chat response for
clickable links):

- **Solar-array sizing equation.** `estimateCubeSatEPSPowerBudget.m`'s
  `Psa = ((Pe*Te/Xe)+(Pd*Td/Xd))/Td` is the standard SMAD-derived CubeSat
  EPS sizing approach (daylight/eclipse load and duration as inputs,
  separate direct-path vs. storage-path efficiency) used throughout
  CubeSat EPS literature and coursework (SJSU CubeSat power-subsystem
  theses, IEEE/ResearchGate CubeSat EPS validation papers).
- **18% BOL array design margin** falls inside the commonly-cited 5-25%
  ECSS/SMAD margin range for this design-maturity level (Tandfonline
  CubeSat EPS design-methodology article).
- **30% target/reference DOD and 5500 EFC/year reference cycle life**
  match commonly-cited LEO CubeSat Li-ion guidance almost exactly (DOD
  "generally restricted to less than 30%", "5500 cycles/year" cited as the
  typical LEO requirement in multiple sources, including a 2024
  ScienceDirect CubeSat battery-life paper and a LEO Li-ion retained-
  capacity study).
- **Beta angle / eclipse fraction** (-28.0 deg, 36.1% of orbit, for 51.6 deg
  inclination / 500 km altitude) is consistent with publicly documented
  ISS-class LEO eclipse behavior (similar inclination/altitude class,
  commonly cited eclipse durations in the 30-38% range depending on
  season).
- **Battery operating temperature** (~18-27 deg C across all 3 scenarios in
  the 3-year run) matches real-mission LEO Li-ion practice -- e.g. the
  REIMEI satellite (96-min LEO orbit, very close to this project's 94.47
  min) thermally managed its batteries to 19-22 deg C and ran ~20% DOD.
- **`batteryQ10=2.0`** (aging roughly doubles per 10 deg C) is a commonly
  used Arrhenius-style heuristic for Li-ion aging acceleration -- a
  reasonable trade-study default, not a substitute for vendor cell data
  (which the project's own docs already correctly caveat).
- **24 Wh battery capacity** is plausible hardware (commercial small-sat
  battery modules in the 30-275 Wh range exist), but see 1.3 above: it is
  oversized relative to what this project's own sizing equation computes
  it needs to be at the stated 30% target DOD.
- **No results found implausible.** Bus voltage (3.3 V), payload current
  (40.1 mA nominal), and mode-power figures (0.6-5 W range) are all
  ordinary for a small CubeSat sensor-payload module; nothing in the
  model produces a voltage, current, or temperature outside real CubeSat
  EPS norms.

---

## 4. Dashboard Real-Time Capability Assessment

### 4.1 Charts were not actually drawn in real time -- **Fixed**, MAJOR finding
`START_TOOLBOX_VIEWER_WITH_METRICS.m`, `createModernDashboard()` /
`updateDashboard()`. All 5 time-series charts (current, temperature, rail
voltage, cumulative energy, illumination timeline) plotted their FULL data
array once, at dashboard creation; during "live" playback, only an `xline`
cursor moved across the already-complete curve -- the brief's own
description of the failure mode ("merely highlighted or pointed to after
the fact") was exactly what was happening. No `animatedline`/`addpoints`
call existed anywhere in the project.

Compounding this: the chart data spans 1.75 orbits (`plotOrbitCycles=1.75`,
a deliberate V18 design choice to preview the next eclipse/load transition)
but the timer that drives playback explicitly clamps and stops at 1.0 orbit
(`missionMinute = min(missionMinute,viewerOrbitMinutes)`, then
`stop(timerObj)` once reached). So roughly 43% of each chart's horizontal
span was always showing data the cursor could never reach during a live
run -- "future" data rendered identically to "past" data from frame one.

**Fix applied:** each chart now has a faint, full-range "preview" line
(muted color, blended 32% toward the chart background, drawn once) sitting
under a bold "live" line that `updateDashboard()` grows every frame via
`set(h,'XData',sim.timeMin(1:k),'YData',...)`. This satisfies both
constraints at once: the V18-intended look-ahead context is preserved
(you can still see the upcoming transition shape), but it's now visually
distinguishable from genuine "received" telemetry, and the live line
itself is drawn progressively as the simulation advances rather than
pre-rendered. `dash.liveLines` holds the 5 handles; `updateDashboard`
re-slices the full prefix each call rather than incrementally appending
points, which stays correct even under the (already-guarded) possibility
of a non-monotonic `missionMinute` and costs nothing measurable at this
sample count (a few hundred points) next to `drawnow limitrate`'s own
budget.

### 4.2 Refresh-rate / buffer-management practices -- already good
`dashboardHz=8` with `refreshPeriod=max(0.05,1/dashboardHz)`,
`'BusyMode','drop'` on the timer, and `drawnow limitrate` (not a bare
`drawnow`) at the end of every update were all already correct,
standard-practice choices for smooth MATLAB animation and did not need
changing.

---

## 5. Documentation & Code Updates

### 5.1 Validation-script regression bug: fault injection silently never fired -- **Fixed**
`validation/crosscheck_firmware.py`. Default `failure_time_min=95` exceeds
this orbit's actual period (~94.469 min, last sample ~94.33 min), so
`apply_switch_fault`'s `t_min < failure_time_min` guard was true for every
sample -- the fault never triggered, and `none`/`stuck_on`/`stuck_off`
produced byte-identical output. This silently defeated the exact
regression check `docs/Firmware_Issues_and_Fixes.md` item 7 claims this
script performs. Fixed: default is now `0.95*orbitMinutes`, matching the
production `.m` code's own computation. Re-ran: `stuck_on` now correctly
diverges (ends in `BACKUP SAFE`, railV=3.3) from `none`/`stuck_off` (end in
`ECLIPSE SLEEP`, railV=0), as the changelog originally claimed.

### 5.2 Stale stability-check reference value in the same script -- **Fixed**
The same file's trailing "Reference: dt/tau ratios" print hardcoded
`tau=0.05 min`, which no longer matches the production
`tauRailMin`/`tauCurrentMin=0.10 min` in `src/simulateCubeSatSubsystem.m`.
At the tau value actually shipped, `dt/tau ~= 1.67` for the 10 s scenario
sample period, which is within explicit Euler's `|1-dt/tau|<1` stability
bound (oscillatory but not literally divergent) -- the original "Euler is
unstable here" claim is only true at the smaller, no-longer-shipped
tau=0.05 value. The exact-exponential discretization is still strictly
better regardless (unconditionally stable AND more accurate), so no
implementation changed -- only the documentation/validation reference value
was corrected, and both ratios are now printed so the discrepancy is
auditable instead of silently wrong.

### 5.3 Duplicated helper functions across two files -- **Fixed**
`scenarioApiAvailable`, `viewerApiAvailable`, and `functionAvailable` were
defined as local functions, identically, in both
`src/ensureAerospaceEphemerisReady.m` and
`START_TOOLBOX_VIEWER_WITH_METRICS.m` -- and the two copies had already
started to drift in their comments. Extracted into their own files
(`src/scenarioApiAvailable.m`, `src/viewerApiAvailable.m`,
`src/functionAvailable.m`); both callers now share one implementation.

### 5.4 Battery model assumptions doc was stale (V19, predates the 3-scenario design) -- **Fixed**
The only existing battery-model-assumptions doc
(`docs/Power_Metrics_Model_Assumptions_V19.md`) describes a 2-scenario
(managed vs. no-management) model from before the `Conventional CubeSat
EPS` baseline existed, and never documented the per-scenario SOC bands,
load deltas, or the "battery hardware is shared/fixed, NOT resized like
the solar array" behavior. Added
`docs/Power_Metrics_Model_Assumptions_V22.md` with a full per-scenario
table, the battery-margin-looks-huge explanation, the achieved-DOD finding
from 1.3, and the literature cross-checks from Section 3.

### 5.5 README -- accurate, only a changelog-style addition made
`README.md`'s run instructions, menu option, and output filenames were all
checked against the actual code (`RUN_PROJECT.m`'s menu, `RUN_FULL_MISSION
_POWER_METRICS.m`'s `writetable` calls) and are accurate for V22 -- no
correction needed. Added a "V23 -- independent technical audit" section
summarizing the fixes above.

### 5.6 Function headers / comments -- generally excellent, two stale-reference issues found and fixed (5.1/5.2), nothing else
Code comments throughout are unusually thorough and mostly self-correcting
(each file's header documents exactly what changed and why, version over
version). The two stale-reference issues above (5.1/5.2) are the only
places where a comment's claim no longer matched the code/script it
described; everything else checked (firmware header, Simulink-builder
header, illumination-profile header, mission-power header) matched its
implementation.

---

## 6. Overall Summary & Prioritized Recommendations

**Already fixed in this delivery (no action needed from you):**
1. SOC floor-clamp edge case (`simulateCubeSatMissionPower.m`) -- minor numerical, real edge case.
2. Validation-script fault-injection regression bug (`crosscheck_firmware.py`) -- the test was not testing what it claimed.
3. Stale stability-check reference value in the same script.
4. Duplicated toolbox-availability helper functions, across 2 files.
5. Real-time progressive line drawing in the dashboard (5 charts).
6. "Higher/lower is better/context-dependent" labels on every chart, both figures.
7. New battery-model-assumptions doc reflecting the current 3-scenario design.
8. New Python cross-check closing the validation gap on the most complex file in the project.

**Worth a deliberate decision (not fixed, since it's a parameterization choice, not a bug):**
1. Battery capacity (24 Wh) is far oversized relative to the model's own 30%-DOD sizing target, producing very shallow achieved DOD (1.5-16%) and a calendar-fade-dominated result. See Section 1.3 / `docs/Power_Metrics_Model_Assumptions_V22.md` for options if you want the cycle-life modeling to visibly matter.

**No critical defects found.** Across a full 3-scenario x 6-life-span
numerical sweep of the battery/aging model and a full run of the firmware
state machine across all 3 failure modes: no NaNs, no runaway values, no
physically impossible states (after the one floor-clamp fix above), and no
results inconsistent with CubeSat EPS literature.

---

## 7. Follow-up pass: graph-rendering bug + 2 deferred items resolved

A real bug in the comparison figure, plus the 2 items deliberately left
open in Section 6, were addressed in a follow-up pass:

### 7.1 Bar-chart value labels were attached to the wrong bars -- **Fixed**, root cause confirmed against MathWorks docs and reproduced in matplotlib before fixing
`RUN_FULL_MISSION_POWER_METRICS.m`, panel 1 ("Solar-array sizing logic").
`cats = categorical({...5 strings...})` with no explicit valueset sorts its
categories **alphabetically** in MATLAB (confirmed via MathWorks
documentation), not in the order the strings were listed. `bar(ax,cats,
vals)` then draws the bars in that alphabetical order ("Conv. installed",
"Conv. req.", "Managed installed", "Managed req.", "Stress req."), while
the old `labelBars(ax,vals,fmt)` placed `text(ax,k,values(k),...)` assuming
the k-th bar sat at x=k in the *original* (un-sorted) order. Net effect: 4
of the 5 numeric labels sat over the wrong bar (visually confirmed with a
matplotlib reproduction using the project's real numbers before touching
the fix, and again after). Fixed two ways: (1) `categorical(catNames,
catNames)` now passes an explicit valueset so the intended order is kept,
and (2) `labelBars` now takes the actual `Bar` object and reads
`XEndPoints`/`YEndPoints` directly off it instead of assuming `x=1:N` --
correct by construction regardless of category order, now or in any
future edit.

### 7.2 Text-collision regression -- self-inflicted in the Section 2 fix, now corrected
The dashboard's chart axes are genuinely tiny: 395x127 px for `axCurrent`
(figure is 1000x940 px, axes `Position=[0.075 0.315 0.395 0.135]`), with
only ~19 px of clearance between the top of each chart and the UI element
sitting above it. The `subtitle()` calls added in Section 2.1 added a
second text line that didn't fit in that 19 px -- mocked up at the real
pixel dimensions, the subtitle text sits past where the next UI element
starts. Fixed by removing the dashboard's 4 `subtitle()` calls and folding
a short tag into each existing single-line title instead (e.g. `'Current
draw (context-dependent)'`), which adds zero extra vertical space. Also
shortened the 5th chart's title (`axEnv`), which combined a dynamic
`eclipseInfo.source` string with a long clause and could run to ~120
characters across an 850 px-wide, 52 px-tall axes -- now ~65 characters.
In the mission-comparison figure (553x326 px tiles, more headroom than the
dashboard but still finite), the longest 3 of the 9 new subtitles
(70-85 characters) were shortened to 50-60 characters to stay clear of
wrapping/overflow into neighboring tiles.

### 7.3 `thermalWarningC` dead config -- **Fixed**: wired into the status logic
Was defined as a config default in two places but never read anywhere in
the simulation (only `thermalLimitC=60`, the hard limit, was actually
used). Added `summary.thermalWarningHours` in `makeMissionSummary()`,
following the exact same pattern as the existing `thermalLimitHours`, and
a new `"PASS - thermal warning"` status tier strictly between normal PASS
and the existing `"MARGINAL - thermal"` trigger -- no existing
PASS/MARGINAL/FAIL/DESIGN GAP outcome changes. Also added to the exported
CSV (`Thermal_Warning_Hours` column, next to `Thermal_Limit_Hours`). With
the current load/thermal parameters this tier won't fire in practice
(battery temp tops out around 27 deg C across every scenario and life
span, well under the 45 deg C warning threshold) -- it's now correctly
wired for if/when load or thermal assumptions change.

### 7.4 Brownout/undervoltage protection -- documented as an explicit scope boundary
No code change (there is nothing to fix: the project tracks battery energy
as a Wh "bucket", not cell terminal voltage vs. SOC, so there is no
electrical quantity for a brownout detector to act on). Added a comment
block at the rail-voltage target assignment in
`simulateCubeSatSubsystem.m` stating this explicitly, plus the algebraic
proof that the soft-start/soft-stop lag is a convex combination of the
previous value and its target (`w=exp(-dt/tau) in (0,1)`) and therefore
cannot produce a value outside [0, 3.3] V even transiently.

