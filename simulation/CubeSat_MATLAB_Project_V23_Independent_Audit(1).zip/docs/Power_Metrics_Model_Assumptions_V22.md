# V22/V23 CubeSat EPS Power Metrics -- Model Assumptions (Battery Focus)

This supersedes `docs/Power_Metrics_Model_Assumptions_V19.md` for everything
that changed once the `Conventional CubeSat EPS` baseline was introduced
(V21-V22) and after the independent audit fixes below (tagged V23). The
V19 doc's literature basis and general modeling approach are still
accurate and are not repeated in full here -- this file's job is to say,
precisely, **what hardware and SOC assumptions are used in each of the
three scenarios**, since that is exactly the thing that changed and the
thing most likely to be mis-read from the CSV outputs.

## The three scenarios, side by side

| | Managed EPS solution | Conventional CubeSat EPS | Same-array no-control stress test |
|---|---|---|---|
| Purpose | Proposed control strategy | Realistic baseline, sized to pass | Diagnostic-only: "what if control is removed but hardware isn't upsized" |
| `powerManagementEnabled` | true | true | **false** |
| SOC band (`socMin`-`socMax`) | 20% - 90% | 15% - 95% | 5% - 100% |
| `epsDistributionEfficiency` | 0.90 | 0.88 | 0.88 |
| Eclipse-mode load | `ECLIPSE SLEEP` = 0.75 W | `ECLIPSE SLEEP` = 2.15 W | no sleep mode; constant ~4.9-5.0 W + payload rail, always on |
| Payload-on load | 4.2 W + payload rail | 4.85 W + payload rail | n/a (always-on load model) |
| Battery calendar-fade rate / yr | 1.0% | 1.2% | 1.3% |
| Installed solar array (BOL) | sized to its own budget, **+18% margin** | sized to its own (larger) budget, **+18% margin** | **same array as Managed** -- intentionally not resized |
| Installed battery capacity | **24 Wh (fixed, see below)** | **24 Wh (fixed, see below)** | **24 Wh (fixed, see below)** |

Source: `RUN_FULL_MISSION_POWER_METRICS.m`, function `scenarioConfig()`.

## The one thing the CSVs can make look like a bug, but isn't

**The solar array is resized per scenario from the orbit energy-budget
equation in `estimateCubeSatEPSPowerBudget.m`. The battery is not.**
`cfg.batteryNominalCapacityWh = 24.0` is set once, in the shared block of
`scenarioConfig()`, before the per-scenario `switch` statement, and is
never overwritten for any of the three scenarios. Contrast this with
`cfg.solarNominalPowerW`, which the caller explicitly overwrites per
scenario (`RUN_FULL_MISSION_POWER_METRICS.m`, around the
`installedSolarByScenario` assignment) after running the sizing budget.

This is a legitimate engineering choice (you would not necessarily
redesign the battery cell stack between a "managed" and "conventional"
control strategy on the same bus), but it has a visible side effect in
`outputs/mission_power_sizing_reference.csv`: the **`Installed_Battery
_Margin_pct`** column reads roughly **+1408%** for Managed, **+452%** for
Conventional, and **+118%** for the stress test, at the 3-year design
point. Those numbers are *informational only* -- they describe how much
headroom the fixed 24 Wh hardware has relative to `requiredBatteryWhAt
TargetDOD` (itself computed from `targetOrbitDOD = 0.30`), they are **not**
used to size anything, and a 1408% margin sitting next to an ~18% solar
margin in the same table is not a sizing-logic bug, just an asymmetry
that is easy to misread without this note.

One consequence worth knowing about: because the battery is this
oversized relative to the eclipse energy it actually has to supply, the
*achieved* per-orbit depth of discharge is far shallower than either the
literature-cited 10-40% LEO guidance or the model's own 30% sizing
target:

| Scenario | Mean orbit DOD | Max orbit DOD |
|---|---|---|
| Managed EPS solution | ~1.5% | ~5% |
| Conventional CubeSat EPS | ~6% | ~10% |
| Same-array no-control stress test | ~3.4% | ~16% |

(measured via the independent Python cross-check in
`validation_extra/missionpower_crosscheck.py`, 3-year run). Practically,
this means cycle-fade is operating near its floor (`minDODStressFactor =
0.15`) for all three scenarios, and battery aging in this configuration is
**calendar-fade-dominated**, not cycle-fade-dominated -- the
`weightedCycleDamageEFC` machinery is implemented correctly but is not the
thing driving the result with the current hardware/load combination. If a
future revision wants the cycle-life modeling to visibly matter (and to
better demonstrate the managed solution's DOD/cycle-life benefit, which is
real but currently small in absolute terms -- battery health at 3 years is
96.8% managed vs. 95.4% conventional, a ~1.4 percentage-point gap), either
shrink `batteryNominalCapacityWh` toward what `requiredBatteryWhAtTarget
DOD` actually computes, or revisit whether the `ECLIPSE SLEEP`/`THERMAL
PROTECT`/`BACKUP SAFE` system-level load numbers (0.75-2.15 W) are
representative of a real bus's total housekeeping draw during eclipse, not
just the sensor-payload module this firmware model originated from.

## Per-scenario design intent (for anyone reading the CSVs cold)

- **Managed EPS solution.** The SOC band (20-90%) and the lower calendar-fade
  rate reflect deliberately protective charge-controller behavior: avoid
  full charge (high-SOC calendar stress) and avoid deep discharge (low-SOC
  calendar stress and cycle stress). This is the only scenario whose
  hardware (`solarNominalPowerW`) is sized down to take advantage of the
  lower eclipse load `ECLIPSE SLEEP` provides.

- **Conventional CubeSat EPS.** Represents "a real CubeSat that still has
  basic eclipse safe-mode behavior, sized to its own (larger) budget" --
  not a do-nothing baseline. SOC band is wider (15-95%) and eclipse-mode
  load is higher (2.15 W vs. 0.75 W) because the safe mode is less
  aggressive about shedding load, and the higher `highSOCCalendarStress
  Gain`/`lowSOCCalendarStressGain` values reflect a less protective charge
  controller. This scenario is expected to PASS on its own correctly-sized
  array; a `FAIL`/`MARGINAL` result here would indicate a real design
  problem, unlike the stress test below.

- **Same-array no-control stress test.** `powerManagementEnabled = false`
  removes all mode-based load shedding (always draws the "no management"
  load defined in `spacecraftLoadPowerW`'s early-return branch), and the
  installed array is deliberately left at the *Managed* scenario's smaller
  size rather than its own (larger) required size. A reported energy
  deficit here is intentionally labeled `DESIGN GAP - resize EPS` rather
  than `FAIL`, specifically so it cannot be misread as "a normal CubeSat
  would fail" -- see `summary.status` logic in `makeMissionSummary()` and
  `docs/Change_Log_V22.md`.

## Literature cross-checks performed during the V22/V23 independent audit

- Orbit energy-budget sizing equation (`Psa = ((Pe*Te/Xe)+(Pd*Td/Xd))/Td`
  in `estimateCubeSatEPSPowerBudget.m`) matches the standard SMAD-derived
  CubeSat solar-array sizing approach used throughout the CubeSat EPS
  literature (daylight/eclipse load and duration inputs, separate
  direct-path vs. storage-path efficiencies).
- `designMargin = 0.18` (18% BOL array margin) falls inside the
  commonly-cited 5-25% SMAD/ECSS margin range for this level of design
  maturity.
- `referenceDOD`/`targetOrbitDOD = 0.30` and `batteryReferenceCycleLifeEFC
  = 5500` match commonly-cited LEO CubeSat Li-ion guidance (DOD generally
  restricted to 10-40%, with ~5500 cycles/year cited as the typical LEO
  cycling rate at that DOD range).
- The analytic eclipse fallback's beta angle (-28.0 deg) and eclipse
  fraction (36.1%) for this orbit (51.6 deg inclination, 500 km altitude)
  are consistent with publicly documented ISS-class LEO eclipse behavior
  (similar inclination/altitude class, commonly cited eclipse durations in
  the 30-38% range depending on season).
- Battery operating temperature range produced by the model (~18-27 deg C
  across all three scenarios) is consistent with real LEO Li-ion mission
  practice (e.g. the REIMEI satellite's batteries were thermally managed to
  19-22 deg C).
- `batteryQ10 = 2.0` (aging rate roughly doubles per 10 deg C) is a
  commonly used approximate Arrhenius-style heuristic for Li-ion aging
  acceleration; treat it as a trade-study default, not a cell-specific
  measured value -- replace with vendor Arrhenius/cycle-life data for a
  flight design, as the V19 doc already recommends for all battery/solar
  coefficients in this model.

## V23 audit fix applied to the battery model itself

`simulateCubeSatMissionPower.m`'s SOC update used to clamp the
carried-over stored energy only at the *ceiling* (`socMax`) when moving
into a new step, not at the floor (`socMin`). Because `availableCapacityWh`
can legitimately shift step-to-step (temperature-driven
`tempCapacityFactor` changes every sample), a transient *rise* in available
capacity while the battery was already sitting at the floor could compute
a SOC fractionally below the configured floor (observed: 4.98% against a
5.00% floor, in the stress-test scenario, before the fix). Both clamp
points in the function now floor-and-ceiling clamp consistently. See the
`V23 FIX` comments in `src/simulateCubeSatMissionPower.m` for the exact
diff, and `validation_extra/missionpower_crosscheck.py` for the before/after
numerical confirmation.
