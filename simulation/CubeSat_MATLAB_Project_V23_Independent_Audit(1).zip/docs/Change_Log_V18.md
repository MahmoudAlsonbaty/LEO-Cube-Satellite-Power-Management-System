# Change Log V18 - Dashboard clock sync and extended metric cycle view

## Problem addressed

After the V17 viewer-clock fix, the official `satelliteScenarioViewer` opened and the dashboard updated, but the cursor could remain slightly out of phase with the 3-D animation. The metric plots also ended visually at the first-orbit boundary, which made the power/eclipsing cycle feel cut off.

## Fixes made

### 1. Smooth wall-clock mission timeline with viewer drift correction

`START_TOOLBOX_VIEWER_WITH_METRICS.m` now uses one presentation wall clock as the primary dashboard time source. This clock is driven by the same `PlaybackSpeedMultiplier` used by `play(sc,...)`.

`viewer.CurrentTime` is still read when the official viewer is available, but only to correct small timing drift in the internal clock offset. This avoids the small visible lag/jitter caused by using `viewer.CurrentTime` directly as the only timer source.

### 2. Extended graph horizon

The 3-D viewer still shows one true orbit in the target time, but the dashboard plots now cover `plotOrbitCycles = 1.75` orbit cycles. A dotted vertical marker labelled `1 orbit` shows where the viewer completes its first orbit.

This lets the dashboard show the next part of the repeated illumination/load/thermal cycle instead of having every trace end exactly at the presentation finish point.

### 3. Exact final plot sample

The metrics time vector now appends the exact final plot time when the sample interval does not divide the plotting horizon exactly. This prevents MATLAB colon-vector rounding from stopping the plotted traces one sample early.

### 4. Validation utility path fix

`validation/crosscheck_firmware.py` now loads `crosscheck.py` relative to its own folder rather than from an absolute development-machine path.

## Main file changed

- `START_TOOLBOX_VIEWER_WITH_METRICS.m`
- `validation/crosscheck_firmware.py`
