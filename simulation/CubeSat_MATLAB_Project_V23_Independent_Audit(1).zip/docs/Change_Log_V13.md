# Change Log - V13 Ephemeris + Full Mission EPS

## Runtime error fix

- Added `src/ensureAerospaceEphemerisReady.m`.
- Replaced the previous narrow ephemeris probe with a direct `planetEphemeris` data-path validation.
- Added automatic `rehash toolboxcache` before the second ephemeris validation attempt.
- Added add-on registration diagnostics through `matlab.addons.installedAddons` when available.
- Updated `START_TOOLBOX_VIEWER_WITH_METRICS.m` so ephemeris-related viewer failure no longer terminates the project.
- Added dashboard-only playback fallback using wall-clock mission time and the same playback speed as the official viewer.
- Updated `check_CubeSat_Project_Toolboxes.m` to reuse the same ephemeris diagnostic helper as the main runner.

## Full-mission CubeSat power model

- Added `RUN_FULL_MISSION_POWER_METRICS.m` menu runner.
- Added `src/simulateCubeSatMissionPower.m`.
- Added battery SOC propagation over a configurable mission duration.
- Added battery capacity health degradation from calendar aging and equivalent-full-cycle fatigue.
- Added temperature-dependent capacity and charge/discharge efficiency derating.
- Added solar-array health degradation from radiation/time aging and repeated sunlight/eclipse thermal cycling.
- Added mode-dependent power consumption tied to the existing firmware mode names.
- Added daily CSV and MAT output products in `outputs/`.

## Menu and documentation

- Added RUN_PROJECT option 4 for full-mission power metrics.
- Added `docs/Ephemeris_Setup_and_Debugging.md`.
- Added `docs/Full_Mission_Power_Metrics.md`.
- Updated README with the new option and documentation links.
