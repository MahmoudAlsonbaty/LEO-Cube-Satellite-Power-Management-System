# Change Log - V21 Graph Scale and Reasoning Fix

## Problem addressed

V20 produced physically meaningful pass/fail results, but the graphs were not visually diagnostic enough. Battery health changes of only a few percent were shown on a full 0-100% axis, making useful differences appear as straight lines.

## Fixes

- Added a third scenario: `No PM resized array`.
- Preserved the same-hardware comparison: `No PM same hardware`.
- Dynamically zoomed SOC, DOD, energy-margin, and health axes.
- Added a battery health-loss plot so 2-3% changes are visible.
- Added an unmet-energy diagnostic plot to show why the same-hardware unmanaged case fails.
- Updated output file names and MAT result file to V21.

## Engineering reasoning

The same-hardware no-management baseline fails because it requires a larger BOL solar array than the managed solution. V21 does not hide this by resizing every case automatically. Instead, it shows both comparisons:

1. Same hardware: demonstrates the hardware saved by the power-management solution.
2. Resized no-management hardware: compares battery aging when the uncontrolled case is given enough solar power to survive.
