# Change Log V16 - Fast Eclipse Startup and Viewer Method Fix

## Why V16 was needed

The latest Ctrl+C trace showed that MATLAB was no longer failing because ephemeris data was missing. The stack was:

```text
computeIlluminationProfile -> eclipseStatus -> Simulator/advance -> planetEphemeris -> ephSelect -> indexing
```

This means `planetEphemeris` was available, but the high-fidelity `eclipseStatus` call was spending too long indexing/initializing ephemeris-backed data while the project sampled the eclipse state for every dashboard point during startup. For a live one-orbit dashboard that must finish in about one minute of viewer time, this is the wrong startup path.

## Fixes

### START_TOOLBOX_VIEWER_WITH_METRICS.m

- Changed `useToolboxEclipse` default from `true` to `false`.
- The official `satelliteScenario` / `satelliteScenarioViewer` path remains enabled.
- The live power dashboard now uses the fast analytic beta-angle eclipse model by default.
- Added comments explaining that the Ctrl+C stack is a performance/indexing problem, not a missing ephemeris-data problem.

### src/computeIlluminationProfile.m

- Added optional input `preferToolboxEclipse`.
- Default is now `false`, so existing calls do not enter `eclipseStatus` unless explicitly requested.
- The toolbox eclipse path remains available for offline validation.
- Removed the old per-sample `for` loop around `eclipseStatus(eclObj,tQuery)`.
- If toolbox eclipse is explicitly enabled, it now attempts one history query using `eclipseStatus(eclObj)` instead of repeated scalar queries.
- Any toolbox eclipse problem falls back to the analytic model without stopping the project.

## Expected behavior

Running `RUN_PROJECT` option 1 should now:

1. Create the satellite scenario if `satelliteScenario` is available.
2. Open the official viewer if `satelliteScenarioViewer(sc,...)` succeeds.
3. Skip slow `eclipseStatus` startup calls.
4. Start the dashboard quickly using analytic illumination.
5. Complete one full orbit in the configured target presentation duration.

## How to enable high-fidelity toolbox eclipse manually

In `START_TOOLBOX_VIEWER_WITH_METRICS.m`, change:

```matlab
useToolboxEclipse = false;
```

to:

```matlab
useToolboxEclipse = true;
```

Use this only for slower offline validation runs, not for the live presentation dashboard.
