# Ephemeris Setup and Viewer Debugging

## What failed

The runtime failure came from the `START_TOOLBOX_VIEWER_WITH_METRICS()` call in `RUN_PROJECT` option 1. The scenario and satellite objects can be created, but `satelliteScenarioViewer(sc,'ShowDetails',true)` can call ephemeris-dependent rendering/analysis paths. If MATLAB cannot see the Aerospace Toolbox ephemeris database, the viewer fails with:

```text
Ephemeris data is not available on the MATLAB path.
```

The important detail is that `aerospaceephemerisdata.mlpkginstall` is not the database. It is only an installer descriptor. Adding that file or this project folder to the MATLAB path does not install the JPL coefficient files used by `planetEphemeris`, `eclipse`, or detailed viewer rendering.

## Code-level fix

The project now uses `src/ensureAerospaceEphemerisReady.m` before the viewer is opened. It:

1. Checks whether the relevant functions exist: `satelliteScenario`, `satelliteScenarioViewer`, `planetEphemeris`, `aeroDataPackage`, `eclipse`, and `eclipseStatus`.
2. Checks MATLAB's registered add-ons when `matlab.addons.installedAddons` is available.
3. Calls `rehash toolboxcache` once, because a correctly installed data package can remain invisible after startup until the toolbox cache is refreshed.
4. Validates the actual data path with:

```matlab
planetEphemeris(2451545.0,'Earth','Moon')
```

5. Separately validates the scenario eclipse path with a small throwaway `satelliteScenario` and `eclipseStatus` call.

If the viewer still cannot open because ephemeris data is missing, `START_TOOLBOX_VIEWER_WITH_METRICS.m` no longer crashes the project. It switches to dashboard-only playback driven by the same computed playback speed. This preserves the one-orbit-in-under-one-minute metrics demo while making the root cause explicit.

## Manual validation in MATLAB

Run the following from the project root:

```matlab
restoredefaultpath
rehash toolboxcache
savepath
addpath(pwd)
addpath(fullfile(pwd,'src'))
check_CubeSat_Project_Toolboxes
```

Then run this direct ephemeris test:

```matlab
planetEphemeris(2451545.0,'Earth','Moon')
```

A 1x3 numeric vector means the ephemeris data is visible. The same error about ephemeris data not being on the MATLAB path means the Add-On is still not installed or not registered correctly.

## Installing from the uploaded .mlpkginstall file

In MATLAB, either drag `aerospaceephemerisdata.mlpkginstall` into the Command Window or right-click it from the Current Folder browser and choose **Install**. After installation finishes, run:

```matlab
rehash toolboxcache
planetEphemeris(2451545.0,'Earth','Moon')
```

If the test works only immediately after installation but fails after restarting MATLAB, rerun:

```matlab
rehash toolboxcache
savepath
```

If `savepath` reports a permissions error, start MATLAB as a user with write permission to the path definition file, or install/register the Add-On under a writable MATLAB user folder.
