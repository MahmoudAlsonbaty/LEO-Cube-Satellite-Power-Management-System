# CubeSat MATLAB Project V14 - Scenario/Viewer Fallback Fix

## Trigger

A user diagnostic from MATLAB R2025b reported:

- `planetEphemeris: YES`
- `Ephemeris Add-On registered: YES`
- `Ephemeris data path: YES`
- `satelliteScenario: NO`
- `satelliteScenarioViewer: NO`
- `eclipse/eclipsestatus path: NO`

This means the original ephemeris-data problem is resolved. The remaining runtime failure is caused by the scenario/viewer API being unavailable to the active MATLAB session.

## Root-cause distinction

V13 still attempted to call `satelliteScenario(...)` unconditionally after the ephemeris pre-flight check. That was correct when the only failure was the missing ephemeris add-on, but it was not robust when the scenario API itself was missing or hidden by path/license state.

## Files changed

### `START_TOOLBOX_VIEWER_WITH_METRICS.m`

- Added `functionAvailable(...)` guard for `satelliteScenario` and `satelliteScenarioViewer`.
- Avoids calling `satelliteScenario(...)` when the API is not visible.
- Runs analytic orbit/illumination playback and the live dashboard without the 3-D viewer.
- Keeps `sc`, `sat`, `gs`, and `viewer` assigned in the base workspace as empty arrays in fallback mode so existing debugging workflows do not error on missing variables.
- Opens `satelliteScenarioViewer` only when both scenario and viewer APIs are visible.

### `src/ensureAerospaceEphemerisReady.m`

- Separates ephemeris readiness from scenario/viewer availability.
- Adds tolerant API availability checks.
- Adds license probes for Aerospace Toolbox and Satellite Communications Toolbox.
- Replaces misleading `[EPHEMERIS PARTIAL]` message with `[SCENARIO VIEWER NOT AVAILABLE]` when ephemeris data is ready but scenario/viewer functions are not visible.

### `check_CubeSat_Project_Toolboxes.m`

- Updates console wording so the user sees that ephemeris, scenario API, and viewer API are separate checks.

## Expected behavior now

If `planetEphemeris` is YES but `satelliteScenario`/`satelliteScenarioViewer` are NO, option 1 in `RUN_PROJECT` should still open the live power dashboard and finish one orbit in the configured presentation duration using internal wall-clock mission time.

The 3-D official viewer will automatically return when MATLAB can see `satelliteScenario` and `satelliteScenarioViewer` again.
