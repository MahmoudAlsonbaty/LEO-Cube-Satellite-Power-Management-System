# Firmware Issues Found and Corrected (V11 -> V12)

This document is one of the requested deliverables: a summary of firmware
issues found in the existing project, with specific explanations of the
unrealistic behavior observed and how each was resolved. Each item below
names the file(s) changed.

---

## 1. Orbital period was hardcoded and physically wrong

**Where:** `START_TOOLBOX_VIEWER_WITH_METRICS.m` (V11), throughout.

**What was wrong:** V11 set `orbitMinutes = 100` and the README asserted
this was "exactly one 100-minute orbit." The satellite actually defined in
the scenario (`semiMajorAxis_m = 6371e3 + 500e3`, i.e. a 500 km circular
orbit) has a true two-body Keplerian period of:

```
T = 2*pi*sqrt(a^3/mu) = 2*pi*sqrt((6.871e6)^3 / 3.986004418e14) ≈ 5668.1 s ≈ 94.47 min
```

That is a ~6% error. Concretely, by the time the V11 scenario's stop time
(100 min) arrived, the satellite had completed slightly *more* than one
full revolution -- so "one orbit" was not what was actually shown, and any
duty-cycle logic keyed to "100 minutes per orbit" was keyed to the wrong
number for the orbit actually being propagated by `satelliteScenario`.

**Fix:** `src/trueOrbitalPeriodMinutes.m` computes the real period from the
semi-major axis via vis-viva, and that single value now drives the
scenario stop time, the firmware model's mission duration, and the
playback-speed calculation. Verified numerically (see
`/validation/crosscheck.py`): for this orbit, the corrected period is
94.469 minutes.

---

## 2. Eclipse/sunlight was a fixed 70/30 duty cycle (or an equally made-up alternative), with no link to the satellite's actual orbit

**Where:** `simulateCubeSatSubsystem` (was inline in
`START_TOOLBOX_VIEWER_WITH_METRICS.m`, now `src/simulateCubeSatSubsystem.m`
+ `src/computeIlluminationProfile.m`).

**What was wrong:** V11 offered two eclipse models behind a flag
(`useProject7030`):
- a flat 70-minutes-sun / 30-minutes-eclipse duty cycle, with no
  dependence on inclination, RAAN, altitude, or the actual Sun position on
  the chosen date, and
- an alternative "circular" check (`x = cos(theta); ... isEclipse = x<0 &&
  abs(y)<0.93`) that was equally disconnected from the real Sun direction.

Both produced `solarADC` as a literal 0/1 step between exactly 120 and
exactly 900 -- i.e. an **instantaneous** transition with nothing in
between. This is exactly the kind of "too good to be true / anomalously
smooth, unrealistically sharp transition" the project review was looking
for: real terminator crossings are not step functions, and a real LEO
orbit's eclipse fraction depends on the beta angle (the angle between the
orbit plane and the Sun direction), which is a real, calculable quantity
for any given epoch and orbit -- not a number you pick because it sounds
plausible.

**Fix:** `src/computeIlluminationProfile.m` returns a continuous
illumination fraction (0 = full umbra, 1 = full sunlight, fractional in
penumbra/antumbra) computed two ways:
- **Primary:** the real Aerospace Toolbox dual-cone eclipse analysis
  (`eclipse(sat)` + `eclipseStatus(eclObj, datetime)`), when the toolbox
  and its ephemeris data are available.
- **Fallback:** an analytic beta-angle / cylindrical-shadow-model
  calculation, using the satellite's actual inclination/RAAN/altitude and
  a low-precision (but real, ~0.01° accurate) Sun-position formula -- not
  a fixed duty cycle. For the orbit and 27-Jun-2026 epoch used in this
  project, this works out to a beta angle of about -28.0° and an eclipse
  fraction of about 36.1% of the orbit (≈34.1 min eclipse / ≈60.4 min
  sunlit) -- the *correct* number for this geometry, not 30%.

Both paths feed a continuous value into the firmware model, with a short
smoothing window at the umbra edges in the fallback path so the
transition is visibly gradual rather than a step (see item 4 in
`docs/Toolbox_Integration_Notes.md` for why the smoothing width was chosen
the way it was).

---

## 3. The eclipse hysteresis band was dead code

**Where:** `src/simulateCubeSatSubsystem.m`.

**What was wrong:** The firmware already contained hysteresis logic for
eclipse detection:

```matlab
if eclipseLatched
    eclipseDecision = solarADC(k) < 650;
else
    eclipseDecision = solarADC(k) <= 500;
end
```

This is a reasonable design (different thresholds for entering vs. leaving
eclipse mode, to avoid relay-style chatter near the boundary) -- but
because V11's `solarADC` only ever took the values 120 or 900 (see item 2),
the band strictly between 500 and 650 could **never actually be
exercised**. The hysteresis code looked correct but was functionally
inert.

**Fix:** Once `solarADC` is continuous (item 2) and carries small
measurement noise (item 5), the signal genuinely passes through the 500-650
band during every transition, so the hysteresis now does real work --
exactly like a real eclipse-detector comparator with hysteresis. No logic
change was needed here; fixing item 2 made this existing code meaningful.

---

## 4. Rail voltage and current stepped instantly, with no transient

**Where:** `src/simulateCubeSatSubsystem.m`.

**What was wrong:** The instant `actualRail`/`mode` changed, `railV` and
`currentmA` were set directly to their new value with no transition at
all -- a real load switch / FET plus downstream capacitance does not
behave this way; there is always some soft-start/soft-stop transient.

**Fix:** Both now approach a commanded target via a first-order lag with a
short time constant (`tauRailMin`/`tauCurrentMin`, ~6 seconds), so the
dashboard shows a brief ramp instead of an instant jump every time the
firmware changes mode.

---

## 5. Telemetry was perfectly noise-free ("too good to be true")

**Where:** `src/simulateCubeSatSubsystem.m`.

**What was wrong:** `solarADC`, `currentmA`, and `tempC` were all
perfectly smooth/deterministic, with zero measurement noise anywhere --
unrealistically clean for anything described as sensor telemetry.

**Fix:** Small, fixed-seed (reproducible) Gaussian noise was added to the
telemetry channels the firmware actually reads (`solarADC`: ±~8 ADC
counts; `tempC`: ±~0.3 °C). The noise amplitude was deliberately chosen to
be well inside the existing hysteresis bands (500-650 for eclipse, 100-120
°C for thermal) so it adds visual realism without introducing spurious
mode-chatter. The noise seed is fixed (passed explicitly into
`simulateCubeSatSubsystem`, and the caller's global RNG state is saved and
restored around the call) so results stay reproducible run-to-run for
grading/demo purposes, while still looking like real telemetry rather than
a perfect analytic curve.

---

## 6. A numerically unstable discretization was caught before shipping

**Where:** `src/simulateCubeSatSubsystem.m` and
`src/build_CubeSat_PowerGating_Simulink_Model.m`.

**What happened:** The most natural way to add the soft-start/soft-stop
ramps in item 4 is to reuse the same explicit first-difference update the
original thermal model used:

```matlab
x(k) = x(k-1) + (target - x(k-1)) * dt/tau;
```

This update is only numerically stable while `dt/tau < 2`. It was fine for
the original thermal loop (`dt/tau ≈ 0.006` with `dtMin=0.25`, `tau=30`),
but a realistic few-second soft-start time constant against a 10-second
sample period gives `dt/tau ≈ 3.3` -- **unstable**. This was caught during
pre-delivery validation (`/validation/crosscheck_firmware.py`, run before
any MATLAB file was finalized): the first version of the ramp produced
unbounded, sign-flipping, exponentially growing "current" and "voltage"
values (literally reaching values like 10^20 within the simulated window)
almost immediately.

**Fix:** Every first-order lag in the project -- thermal, rail-voltage
ramp, and current ramp, in both the main script's model and the mirrored
Stateflow/MATLAB Function block logic in the Simulink build -- now uses
the *exact* discretization of `dx/dt = (target-x)/tau`:

```matlab
x(k) = target + (x(k-1) - target) * exp(-dt/tau);
```

This form is unconditionally stable for any `tau > 0`, `dt > 0`, and is
also a more accurate discretization of the underlying physical ODE than
the explicit-difference form it replaces (not just "safe," strictly
better). Re-validated after the fix: rail voltage stays in [0, 3.3] V,
current stays in [0.011, 40.1] mA, temperature stays bounded, across all
three failure modes, with no NaNs.

---

## 7. The fault-injection time silently stopped doing anything

**Where:** `START_TOOLBOX_VIEWER_WITH_METRICS.m` /
`src/build_CubeSat_PowerGating_Simulink_Model.m`.

**What was wrong:** `failureTimeMin = 95` was tuned for the V11 assumption
of a 100-minute orbit (i.e. "trigger near the end, at 95% through"). Once
the orbital period is corrected to ~94.47 minutes (item 1), a fault time
of 95 minutes falls *after* the displayed orbit ends -- so selecting
`failureMode = "stuck_on"` or `"stuck_off"` would silently produce no
visible difference at all, which would have been a confusing regression
to discover live during a demo.

**Fix:** `failureTimeMin` is now computed as `0.95*orbitMinutes`, scaling
with whatever the real orbital period turns out to be, so the fault demo
keeps landing near the end of the displayed window. (Verified in
`/validation/crosscheck_firmware.py`: `stuck_on` now visibly forces
`BACKUP SAFE` mode and a held-on rail near the end of the run, where
before the fix it was indistinguishable from `failureMode="none"`.)

---

## 8. "BOOT" mode was unreachable dead code

**Where:** `src/simulateCubeSatSubsystem.m`.

**What was wrong:** `nextControlMin` was initialized to `0`, and the first
sample's mission time was also `0`, so the control-decision branch
(`if timeMin(k) >= nextControlMin`) was already true at the very first
sample. The `else` branch that would have assigned `modeName(1) = "BOOT"`
could never execute -- dead code that implied a power-on/boot state the
simulation never actually showed.

**Fix:** `nextControlMin` is now initialized to `dtMin` and sample 1 is
explicitly assigned `"BOOT"` before the control loop runs, so the first
real eclipse/thermal/payload decision happens at sample 2 -- matching a
real firmware power-on sequence where the rail is held off during
initialization, however briefly.

---

## What was deliberately left unchanged

- The control thresholds themselves (500/650 ADC for eclipse hysteresis,
  100/120 °C for thermal hysteresis, the 1-minute minimum dwell time
  between non-payload-on mode re-evaluations) were not changed. They were
  already a reasonable two-layer debounce design (value hysteresis + time
  hysteresis); the problem was that the *signal* feeding them was
  unrealistically clean (items 2, 3, 5), not the thresholds.
- The overall mode set (`BOOT`, `ECLIPSE SLEEP`, `PAYLOAD ON`,
  `THERMAL PROTECT`, `BACKUP SAFE`) and the fault model
  (`none`/`stuck_on`/`stuck_off`) are unchanged.
