function RUN_PROJECT()
% RUN_PROJECT
% Launcher for CubeSat MATLAB project V22 (Conventional Baseline EPS Metrics).

    clc;
    close all;

    root = fileparts(mfilename('fullpath'));
    addpath(root);
    addpath(fullfile(root,'src'));

    keepRunning = true;

    while keepRunning
        fprintf('\n');
        fprintf('============================================================\n');
        fprintf(' CubeSat MATLAB Project - V22 Conventional Baseline EPS Metrics\n');
        fprintf('============================================================\n');
        fprintf('1) Smooth official viewer + synced dashboard, one TRUE orbit in < 1 min\n');
        fprintf('2) Build Simulink subsystem model\n');
        fprintf('3) Check MATLAB toolboxes / Java UI status\n');
        fprintf('4) Run zoomed/source-backed full-mission EPS comparison\n');
        fprintf('0) Exit\n');
        fprintf('============================================================\n');

        choice = input('Select option: ');

        switch choice
            case 1
                START_TOOLBOX_VIEWER_WITH_METRICS();

            case 2
                if exist('build_CubeSat_PowerGating_Simulink_Model','file') == 2
                    build_CubeSat_PowerGating_Simulink_Model();
                else
                    fprintf('Simulink builder not found.\n');
                end

            case 3
                check_CubeSat_Project_Toolboxes();

            case 4
                if exist('RUN_FULL_MISSION_POWER_METRICS','file') == 2
                    RUN_FULL_MISSION_POWER_METRICS();
                else
                    fprintf('Full-mission power metrics runner not found.\n');
                end

            case 0
                keepRunning = false;

            otherwise
                fprintf('Invalid option.\n');
        end

        if keepRunning
            reply = input('Return to menu? Y/N: ','s');
            if strcmpi(strtrim(reply),'n') || strcmpi(strtrim(reply),'no')
                keepRunning = false;
            end
        end
    end
end
