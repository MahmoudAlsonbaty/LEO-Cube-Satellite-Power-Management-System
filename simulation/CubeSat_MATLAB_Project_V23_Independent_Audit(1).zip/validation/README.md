# validation/

These Python scripts are NOT part of the MATLAB project's runtime. They
were used to validate the V12 physics and firmware-logic changes before
they were written into the `.m` files, because no licensed MATLAB
installation was available in the environment this work was done in. They
are included so the reasoning is auditable/reproducible rather than just
asserted. See `docs/Notes.md` -> "What we could not verify in this
delivery" for the full context.

- `crosscheck.py` -- validates the orbital-period (vis-viva) and
  beta-angle eclipse-fraction math used in `src/trueOrbitalPeriodMinutes.m`
  and `src/computeIlluminationProfile.m`, and checks the smoothed
  illumination profile has no instantaneous jumps.

- `crosscheck_firmware.py` -- a Python port of the full firmware state
  machine in `src/simulateCubeSatSubsystem.m` (eclipse/thermal/payload
  mode logic, soft-start ramps, noise), run across all three failure
  modes to check for NaNs, runaway values, and sane mode distributions.
  This is the script that caught the numerical-instability bug described
  in `simulateCubeSatSubsystem.m`'s header (explicit-Euler ramp update
  diverging) before it ever reached a `.m` file.

- `matlab_lint.py` -- a lightweight structural linter (not a real MATLAB
  parser) used to sanity-check every `.m` file in this delivery for
  balanced parentheses/brackets/braces, balanced string quoting, and
  balanced if/for/while/switch/function/try...end block nesting. Run as:

  ```bash
  python3 validation/matlab_lint.py RUN_PROJECT.m START_TOOLBOX_VIEWER_WITH_METRICS.m \
      check_CubeSat_Project_Toolboxes.m src/*.m
  ```

None of these scripts need to be run by you -- they're a record of how
this delivery was checked, not a required build step. The real
verification step is running `RUN_PROJECT` in MATLAB.
