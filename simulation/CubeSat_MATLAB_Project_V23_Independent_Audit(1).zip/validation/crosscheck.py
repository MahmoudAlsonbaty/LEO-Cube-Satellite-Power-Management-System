import numpy as np
import math
from datetime import datetime, timezone

# ---------------------------------------------------------------------------
# Python cross-check of the NEW firmware/illumination logic before porting
# to MATLAB (no MATLAB engine available in this sandbox -> validate algorithm
# behavior numerically here first).
# ---------------------------------------------------------------------------

Re = 6371e3
mu = 3.986004418e14
alt = 500e3
a = Re + alt
T_min = 2*math.pi*math.sqrt(a**3/mu)/60
inc_deg, raan_deg = 51.6, 0.0

def days_since_J2000(dt_utc):
    return (dt_utc - datetime(2000,1,1,12,0,0,tzinfo=timezone.utc)).total_seconds()/86400.0

def analytic_illum_profile(startTime, timeMin, inc_deg, raan_deg, altitude_m, ramp_min):
    n = days_since_J2000(startTime)
    L = math.radians((280.460 + 0.9856474*n) % 360)
    g = math.radians((357.528 + 0.9856003*n) % 360)
    lam = L + math.radians(1.915)*math.sin(g) + math.radians(0.020)*math.sin(2*g)
    eps = math.radians(23.439 - 0.0000004*n)
    sun = np.array([math.cos(lam), math.cos(eps)*math.sin(lam), math.sin(eps)*math.sin(lam)])

    inc = math.radians(inc_deg); raan = math.radians(raan_deg)
    h = np.array([math.sin(inc)*math.sin(raan), -math.sin(inc)*math.cos(raan), math.cos(inc)])
    beta = math.degrees(math.asin(np.dot(h, sun)))
    a_ = Re + altitude_m
    beta_crit = math.degrees(math.asin(Re/a_))

    N = len(timeMin)
    illum = np.ones(N)
    if abs(beta) >= beta_crit:
        return illum, beta, 0.0, T_min

    ratio = math.sqrt(a_**2-Re**2)/(a_*math.cos(math.radians(beta)))
    ratio = max(-1.0,min(1.0,ratio))
    half_deg = math.degrees(math.acos(ratio))
    eclipse_frac = (2*half_deg)/360.0
    eclipse_dur_min = eclipse_frac*T_min
    sunlit_dur_min = T_min - eclipse_dur_min

    tau = ramp_min
    for k in range(N):
        phase = timeMin[k] % T_min
        shifted = ((phase - sunlit_dur_min + T_min/2) % T_min) - T_min/2
        afterEdge0 = 0.5*(1+math.tanh(shifted/tau))
        beforeEdge1 = 0.5*(1-math.tanh((shifted-eclipse_dur_min)/tau))
        inside = afterEdge0*beforeEdge1
        illum[k] = 1 - inside
    return illum, beta, eclipse_frac, T_min

startTime = datetime(2026,6,27,12,0,0,tzinfo=timezone.utc)
dtMin = 10/60.0  # aligned with scenario sampleTimeSeconds = 10 s
timeMin = np.arange(0, T_min+1e-9, dtMin)
illum, beta, eclipse_frac, T_min_check = analytic_illum_profile(startTime, timeMin, inc_deg, raan_deg, alt, ramp_min=0.35)

print(f"Orbital period: {T_min:.3f} min")
print(f"Beta angle: {beta:.2f} deg, eclipse fraction: {eclipse_frac*100:.2f}%")
print(f"N samples: {len(timeMin)}")
print(f"illum min={illum.min():.4f} max={illum.max():.4f}")
print(f"Fraction of samples in eclipse (illum<0.5): {np.mean(illum<0.5)*100:.2f}% (expect close to {eclipse_frac*100:.2f}%)")

# check smoothness: max |delta illum| per step should be small (no instantaneous jump)
dillum = np.diff(illum)
print(f"max |step-to-step change| in illum = {np.max(np.abs(dillum)):.4f}  (old model had a jump of 1.0 i.e. instantaneous)")

