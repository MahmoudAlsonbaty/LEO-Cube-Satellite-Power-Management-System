#!/usr/bin/env python3
"""
Lightweight structural sanity-checker for MATLAB .m files.

This is NOT a real MATLAB parser. It cannot catch every possible bug.
It is a best-effort net for the most common mechanical mistakes that are
easy to introduce while hand-writing/templating .m files outside MATLAB
itself (which is the situation here -- no licensed MATLAB engine is
available in this environment, so this script exists to catch what it can
before the files are handed to the user to run for real):

  - unbalanced ( ) [ ] { }
  - unbalanced string quotes (single AND double, with MATLAB's doubled-quote
    escaping convention, and a heuristic for the transpose-vs-string-start
    single-quote ambiguity)
  - unbalanced block constructs: every if/for/while/switch/function/
    try/parfor must have a matching end (elseif/else/case/otherwise/catch
    do not open their own block)

Usage: python3 matlab_lint.py file1.m file2.m ...
Exits non-zero if any file fails a check.
"""
import sys
import re

BLOCK_OPENERS = {'if','for','while','switch','function','try','parfor'}
BLOCK_MIDDLES = {'elseif','else','case','otherwise','catch'}
BLOCK_CLOSER = 'end'
KEYWORD_RE = re.compile(r'\b(' + '|'.join(
    sorted(BLOCK_OPENERS | BLOCK_MIDDLES | {BLOCK_CLOSER}, key=len, reverse=True)
) + r')\b')


def strip_to_code_tokens(text):
    """Return (code_only_text_with_strings_blanked, errors) -- removes
    comments, and replaces string contents with spaces (so keyword/paren
    scanning ignores anything inside strings/comments), while still
    validating that strings/parens are themselves balanced."""
    errors = []
    out = []
    i = 0
    n = len(text)
    in_single = False
    in_double = False
    paren_stack = []
    PAIR = {'(': ')', '[': ']', '{': '}'}
    CLOSE = {')': '(', ']': '[', '}': '{'}
    line = 1

    while i < n:
        ch = text[i]
        if ch == '\n':
            line += 1
            if in_single or in_double:
                errors.append(f"line {line-1}: string not terminated before end of line")
                in_single = False
                in_double = False
            out.append('\n')
            i += 1
            continue

        if in_single:
            if ch == "'":
                if i+1 < n and text[i+1] == "'":
                    i += 2
                    out.append(' ')
                    continue
                else:
                    in_single = False
                    out.append(' ')
                    i += 1
                    continue
            else:
                out.append(' ')
                i += 1
                continue

        if in_double:
            if ch == '"':
                if i+1 < n and text[i+1] == '"':
                    i += 2
                    out.append(' ')
                    continue
                else:
                    in_double = False
                    out.append(' ')
                    i += 1
                    continue
            else:
                out.append(' ')
                i += 1
                continue

        if ch == '%':
            # line comment -- skip to end of line (do NOT count parens/quotes inside)
            while i < n and text[i] != '\n':
                i += 1
            continue

        if ch == "'":
            # MATLAB's real rule: transpose only when the quote IMMEDIATELY
            # follows (no whitespace) an identifier/number/closing-bracket/
            # dot; any whitespace (or start of line/expression) before the
            # quote means it starts a new string literal. Do NOT skip
            # whitespace when looking at the previous character.
            prev_char = out[-1] if out else ''
            if prev_char.isalnum() or prev_char in ')]}._':
                # transpose operator, not a string start
                out.append(ch)
                i += 1
                continue
            else:
                in_single = True
                out.append(' ')
                i += 1
                continue

        if ch == '"':
            in_double = True
            out.append(' ')
            i += 1
            continue

        if ch in PAIR:
            paren_stack.append((ch, line))
            out.append(ch)
            i += 1
            continue

        if ch in CLOSE:
            if not paren_stack or paren_stack[-1][0] != CLOSE[ch]:
                errors.append(f"line {line}: unmatched '{ch}'")
            else:
                paren_stack.pop()
            out.append(ch)
            i += 1
            continue

        # 'end' used as the array-indexing keyword (e.g. A(end+1), A(2:end))
        # is NOT a block-closing statement -- only treat bare 'end' as a
        # block closer when it appears outside any open ( [ { (depth 0).
        if paren_stack and text[i:i+3] == 'end' and \
           (i == 0 or not (text[i-1].isalnum() or text[i-1] == '_')) and \
           (i+3 >= n or not (text[i+3].isalnum() or text[i+3] == '_')):
            out.append('   ')
            i += 3
            continue

        out.append(ch)
        i += 1

    if in_single or in_double:
        errors.append("file ended with an unterminated string")
    for (c, ln) in paren_stack:
        errors.append(f"line {ln}: unmatched '{c}' (never closed)")

    return ''.join(out), errors


def check_blocks(code_only):
    errors = []
    stack = []
    for lineno, line in enumerate(code_only.split('\n'), start=1):
        for m in KEYWORD_RE.finditer(line):
            kw = m.group(1)
            if kw in BLOCK_OPENERS:
                stack.append((kw, lineno))
            elif kw in BLOCK_MIDDLES:
                if not stack:
                    errors.append(f"line {lineno}: '{kw}' with no enclosing block")
            elif kw == BLOCK_CLOSER:
                if not stack:
                    errors.append(f"line {lineno}: 'end' with empty block stack (extra end?)")
                else:
                    stack.pop()
    if stack:
        for (kw, lineno) in stack:
            errors.append(f"line {lineno}: '{kw}' never closed with matching 'end'")
    return errors


def lint_file(path):
    with open(path, encoding='utf-8') as f:
        text = f.read()
    code_only, str_errors = strip_to_code_tokens(text)
    block_errors = check_blocks(code_only)
    return str_errors + block_errors


if __name__ == '__main__':
    overall_ok = True
    for path in sys.argv[1:]:
        errs = lint_file(path)
        if errs:
            overall_ok = False
            print(f"\n=== {path}: {len(errs)} issue(s) ===")
            for e in errs:
                print("  -", e)
        else:
            print(f"{path}: OK")
    sys.exit(0 if overall_ok else 1)
