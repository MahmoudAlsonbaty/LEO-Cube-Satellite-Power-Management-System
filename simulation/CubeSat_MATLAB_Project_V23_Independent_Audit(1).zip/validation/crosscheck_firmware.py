import numpy as np
import math
from datetime import datetime, timezone
import importlib.util

Re = 6371e3
mu = 3.986004418e14
alt = 500e3
a = Re + alt
T_min = 2*math.pi*math.sqrt(a**3/mu)/60
dtMin = 10/60.0
timeMin = np.arange(0, T_min+1e-9, dtMin)
N = len(timeMin)

from pathlib import Path
spec = importlib.util.spec_from_file_location("xc", str(Path(__file__).resolve().parent / "crosscheck.py"))
xc = importlib.util.module_from_spec(spec)
spec.loader.exec_module(xc)
illum, beta, eclipse_frac, _ = xc.analytic_illum_profile(datetime(2026,6,27,12,0,0,tzinfo=timezone.utc), timeMin, 51.6, 0.0, alt, ramp_min=0.35)

def apply_switch_fault(commanded, t_min, failure_mode, failure_time_min):
    if t_min < failure_time_min:
        return commanded
    if failure_mode == "stuck_on":
        return True
    if failure_mode == "stuck_off":
        return False
    return commanded

def lag_step(prev, target, dt, tau):
    # EXACT discretization of dx/dt = (target-x)/tau over a step dt.
    # Unconditionally stable for any tau>0, dt>0 (unlike explicit Euler).
    return target + (prev - target)*math.exp(-dt/tau)

def simulate(failure_mode="none", failure_time_min=None, seed=42,
             tauThermalMin=30.0, tauRailMin=0.10, tauCurrentMin=0.10):
    # V23 FIX (independent audit): the previous default failure_time_min=95
    # exceeded this orbit's actual period (T_min ~= 94.469, with the last
    # sample at ~94.33), so apply_switch_fault's "if t_min < failure_time_min"
    # guard was true for every sample regardless of failure_mode -- the fault
    # never fired, and all three modes ("none"/"stuck_on"/"stuck_off") below
    # produced byte-identical output. That silently defeated the very
    # regression check this script's header and docs/Firmware_Issues_and_Fixes.md
    # item 7 claim it performs. Also corrected tauRailMin/tauCurrentMin
    # defaults from 0.05 to 0.10 min to match the actual production constants
    # in src/simulateCubeSatSubsystem.m (see docs note below).
    if failure_time_min is None:
        failure_time_min = 0.95 * T_min
    rng = np.random.default_rng(seed)
    solarADC_true = 120 + (900-120)*illum
    solarADC_meas = solarADC_true + 8*rng.standard_normal(N)

    railV = np.zeros(N); currentmA = np.zeros(N)
    tempC_true = np.zeros(N); tempC_meas = np.zeros(N)
    modeName = [""]*N

    tempC_true[0] = 50.0
    tempC_meas[0] = 50.0 + 0.3*rng.standard_normal()
    commandedRail = False
    actualRail = False
    eclipseLatched = False
    thermalLatched = False

    modeName[0] = "BOOT"
    nextControlMin = dtMin

    n_mode_changes = 0
    prev_mode = "BOOT"

    for k in range(N):
        if k > 0:
            sunTargetTemp = 130.0 if actualRail else 75.0
            targetTemp = illum[k-1]*sunTargetTemp + (1-illum[k-1])*(-40.0)
            tempC_true[k] = lag_step(tempC_true[k-1], targetTemp, dtMin, tauThermalMin)
            tempC_meas[k] = tempC_true[k] + 0.3*rng.standard_normal()

        actualRail = apply_switch_fault(commandedRail, timeMin[k], failure_mode, failure_time_min)

        if k == 0:
            modeName[0] = "BOOT"
        elif timeMin[k] >= nextControlMin:
            if eclipseLatched:
                eclipseDecision = solarADC_meas[k] < 650
            else:
                eclipseDecision = solarADC_meas[k] <= 500

            if eclipseDecision:
                eclipseLatched = True
                commandedRail = False
                actualRail = apply_switch_fault(False, timeMin[k], failure_mode, failure_time_min)
                modeName[k] = "BACKUP SAFE" if actualRail else "ECLIPSE SLEEP"
                nextControlMin = timeMin[k] + 1
            else:
                eclipseLatched = False
                if thermalLatched:
                    thermalDecision = tempC_meas[k] > 100
                else:
                    thermalDecision = tempC_meas[k] >= 120
                if thermalDecision:
                    thermalLatched = True
                    commandedRail = False
                    actualRail = apply_switch_fault(False, timeMin[k], failure_mode, failure_time_min)
                    modeName[k] = "BACKUP SAFE" if actualRail else "THERMAL PROTECT"
                    nextControlMin = timeMin[k] + 1
                else:
                    thermalLatched = False
                    commandedRail = True
                    actualRail = apply_switch_fault(True, timeMin[k], failure_mode, failure_time_min)
                    if not actualRail:
                        modeName[k] = "BACKUP SAFE"
                        nextControlMin = timeMin[k] + 1
                    else:
                        modeName[k] = "PAYLOAD ON"
                        nextControlMin = timeMin[k] + dtMin
        else:
            modeName[k] = modeName[k-1]

        if modeName[k] != prev_mode:
            n_mode_changes += 1
            prev_mode = modeName[k]

        targetRailV = 3.3 if actualRail else 0.0
        if modeName[k] == "PAYLOAD ON":
            targetCurrent = 40.1
        elif modeName[k] == "BACKUP SAFE" and actualRail:
            targetCurrent = 5.11
        else:
            targetCurrent = 0.011

        if k == 0:
            railV[k] = targetRailV
            currentmA[k] = targetCurrent
        else:
            railV[k] = lag_step(railV[k-1], targetRailV, dtMin, tauRailMin)
            currentmA[k] = lag_step(currentmA[k-1], targetCurrent, dtMin, tauCurrentMin)

    return dict(timeMin=timeMin, illum=illum, solarADC=solarADC_meas, railV=railV,
                currentmA=currentmA, tempC=tempC_meas, modeName=np.array(modeName),
                n_mode_changes=n_mode_changes)

for fm in ["none","stuck_on","stuck_off"]:
    r = simulate(failure_mode=fm)
    modes, counts = np.unique(r["modeName"], return_counts=True)
    print(f"\n--- failureMode={fm} (fault time={0.95*T_min:.2f} min) ---")
    print("mode distribution:", dict(zip(modes, counts)))
    print(f"mode changes over run: {r['n_mode_changes']}")
    print(f"last mode: {r['modeName'][-1]}  last railV: {r['railV'][-1]:.3f}")
    print(f"max tempC={r['tempC'].max():.2f}  min tempC={r['tempC'].min():.2f}")
    print(f"currentmA range=[{r['currentmA'].min():.4f},{r['currentmA'].max():.4f}]  any NaN? {np.any(np.isnan(r['currentmA']))}")
    print(f"railV range=[{r['railV'].min():.4f},{r['railV'].max():.4f}]")

# V23 FIX (independent audit): this used to hardcode tau=0.05 min, which no
# longer matches tauRailMin/tauCurrentMin=0.10 min in the production
# src/simulateCubeSatSubsystem.m (and this script's own simulate() defaults,
# fixed above). At the ACTUAL production tau (0.10 min), dt/tau ~= 1.67 for
# the 10 s scenario sample period used in the live dashboard, which is just
# inside explicit Euler's |1-dt/tau|<1 stability bound -- i.e. Euler would
# not literally diverge at the tau value actually shipped, only oscillate
# with reduced accuracy. The exact-exponential form is still strictly better
# regardless (it is both unconditionally stable AND a more accurate
# discretization of the underlying ODE -- see simulateCubeSatSubsystem.m
# header item 3), so the implementation choice does not change. But the
# original "Euler would be unstable here" claim only holds at a smaller tau
# (e.g. ~0.05 min / 3 s), which was probably an earlier parameterization that
# the documentation's example was never updated to match. Both ratios are
# printed below so the discrepancy is auditable instead of silently wrong.
print("\n[Reference] Stability check: dt/tau ratios")
print(f"  thermal:  dt/tau = {dtMin/30.0:.4f}  (fine even with Euler)")
print(f"  rail/current at ACTUAL production tau=0.10 min: dt/tau = {dtMin/0.10:.4f}  "
      f"(within Euler's |1-dt/tau|<1 bound -- oscillatory but technically stable; exact-exp form used anyway, and is still strictly preferable)")
print(f"  rail/current at tau=0.05 min (older/smaller value, NOT what ships today): dt/tau = {dtMin/0.05:.4f}  "
      f"(this is the value at which Euler genuinely diverges -- see docs/Firmware_Issues_and_Fixes.md item 6)")
