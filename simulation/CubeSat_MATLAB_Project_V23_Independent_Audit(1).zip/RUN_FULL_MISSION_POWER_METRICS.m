function RUN_FULL_MISSION_POWER_METRICS()
% RUN_FULL_MISSION_POWER_METRICS
% -------------------------------------------------------------------------
% V22 source-backed CubeSat EPS mission review with conventional baseline.
%
% V21 keeps the source-backed EPS sizing workflow and adds two fixes:
%   1) dynamically zoomed axes so small SOC/health changes are visible.
%   2) a third no-management case with a larger resized solar array so battery
%      aging can be compared without immediate SOC-floor clipping.
%
% Workflow:
%   1) Build one representative orbit from the same firmware/illumination
%      profile used by the viewer.
%   2) Size the installed solar array from an orbit energy-balance equation.
%   3) Use the same installed hardware for the managed and no-solution cases.
%   4) Integrate SOC, DOD, thermal stress, battery aging, and solar degradation
%      across several mission lifetimes.
%   5) Export tables and figures that show why the managed case passes or
%      fails and how much extra array/battery margin the baseline would need.

    clc;
    root = fileparts(mfilename('fullpath'));
    addpath(root);
    addpath(fullfile(root,'src'));

    fprintf('\nCubeSat full-mission EPS power metrics review - V22\n');
    fprintf('==================================================\n\n');

    eph = ensureAerospaceEphemerisReady(true); %#ok<NASGU>

    startTime = datetime(2026,6,1,10,0,0,'TimeZone','UTC');
    altitude_m = 500e3;
    inclination_deg = 51.6;
    raan_deg = 31;
    eccentricity = 0;
    argPeriapsis_deg = 0;
    trueAnomaly_deg = 15;
    earthRadius_m = 6371e3;
    semiMajorAxis_m = earthRadius_m + altitude_m;
    sampleTimeSeconds = 60;
    dtMin = sampleTimeSeconds/60;
    orbitMinutes = trueOrbitalPeriodMinutes(semiMajorAxis_m);
    timeMin = 0:dtMin:orbitMinutes;

    orbitElements = struct('inclination_deg',inclination_deg, ...
                           'raan_deg',raan_deg, ...
                           'altitude_m',altitude_m);

    % Use the fast analytic eclipse path for repeated long-duration sweeps.
    % The toolbox eclipseStatus path remains too slow/unavailable in the
    % user's current installation and is not required for the EPS trade study.
    [illumFrac,eclipseInfo] = computeIlluminationProfile([],startTime,timeMin,orbitElements,false);
    orbitSim = simulateCubeSatSubsystem("none",0.95*orbitMinutes,illumFrac,timeMin,dtMin,42);

    outputDir = fullfile(root,'outputs');
    if ~exist(outputDir,'dir')
        mkdir(outputDir);
    end

    designLifeDays = 1095;   % three-year design point for the installed hardware
    designMargin = 0.18;     % extra BOL array margin above the managed-case sizing result

    managedDesignCfg = scenarioConfig("Managed EPS solution", designLifeDays);
    conventionalDesignCfg = scenarioConfig("Conventional CubeSat EPS", designLifeDays);
    stressDesignCfg = scenarioConfig("Same-array no-control stress test", designLifeDays);

    managedBudgetForSizing = estimateCubeSatEPSPowerBudget(orbitSim, managedDesignCfg, designLifeDays);
    conventionalBudgetForSizing = estimateCubeSatEPSPowerBudget(orbitSim, conventionalDesignCfg, designLifeDays);
    stressBudgetForSizing = estimateCubeSatEPSPowerBudget(orbitSim, stressDesignCfg, designLifeDays); %#ok<NASGU>

    % V22 separates three cases so the wording matches real CubeSat practice:
    %   1) Managed EPS solution: the proposed control strategy, sized normally.
    %   2) Conventional CubeSat EPS: a realistic baseline with basic eclipse
    %      safe mode and its own correctly sized array. This should normally pass.
    %   3) Same-array no-control stress test: an intentionally infeasible test
    %      where all power management is removed but the smaller managed array
    %      is kept. A deficit here is reported as a design gap, not as a normal
    %      CubeSat failure.
    installedManagedSolarNominalPowerW = managedBudgetForSizing.requiredSolarBOLW * (1 + designMargin);
    installedConventionalSolarNominalPowerW = conventionalBudgetForSizing.requiredSolarBOLW * (1 + designMargin);

    managedDesignCfg.solarNominalPowerW = installedManagedSolarNominalPowerW;
    conventionalDesignCfg.solarNominalPowerW = installedConventionalSolarNominalPowerW;
    stressDesignCfg.solarNominalPowerW = installedManagedSolarNominalPowerW;

    managedBudgetInstalled = estimateCubeSatEPSPowerBudget(orbitSim, managedDesignCfg, designLifeDays);
    conventionalBudgetInstalled = estimateCubeSatEPSPowerBudget(orbitSim, conventionalDesignCfg, designLifeDays);
    stressBudgetInstalled = estimateCubeSatEPSPowerBudget(orbitSim, stressDesignCfg, designLifeDays);

    fprintf('Reference orbit energy-budget sizing\n');
    fprintf('------------------------------------\n');
    fprintf('Orbit period:             %.3f min\n', orbitMinutes);
    fprintf('Sunlight / eclipse:       %.1f / %.1f min per orbit\n', ...
        60*managedBudgetInstalled.daylightHours, 60*managedBudgetInstalled.eclipseHours);
    fprintf('Managed day/eclipse load: %.2f / %.2f W\n', ...
        managedBudgetInstalled.dayLoadW, managedBudgetInstalled.eclipseLoadW);
    fprintf('Conventional day/eclipse load %.2f / %.2f W\n', ...
        conventionalBudgetInstalled.dayLoadW, conventionalBudgetInstalled.eclipseLoadW);
    fprintf('No-control stress day/eclipse load %.2f / %.2f W\n', ...
        stressBudgetInstalled.dayLoadW, stressBudgetInstalled.eclipseLoadW);
    fprintf('Managed required BOL array %.2f W; installed %.2f W; margin %.1f%%\n', ...
        managedBudgetInstalled.requiredSolarBOLW, installedManagedSolarNominalPowerW, managedBudgetInstalled.installedSolarMarginPct);
    fprintf('Conventional required BOL array %.2f W; installed %.2f W; margin %.1f%%\n', ...
        conventionalBudgetInstalled.requiredSolarBOLW, installedConventionalSolarNominalPowerW, conventionalBudgetInstalled.installedSolarMarginPct);
    fprintf('Same-array no-control required %.2f W; same installed %.2f W; design gap %.1f%%\n', ...
        stressBudgetInstalled.requiredSolarBOLW, installedManagedSolarNominalPowerW, stressBudgetInstalled.installedSolarMarginPct);
    fprintf('Array avoided versus conventional baseline: %.2f W (%.1f%% less BOL array)\n\n', ...
        installedConventionalSolarNominalPowerW - installedManagedSolarNominalPowerW, ...
        100*(1 - installedManagedSolarNominalPowerW/installedConventionalSolarNominalPowerW));

    lifeSpansDays = [30 90 180 365 730 1095];
    scenarioNames = ["Managed EPS solution", "Conventional CubeSat EPS", "Same-array no-control stress test"];
    installedSolarByScenario = [installedManagedSolarNominalPowerW, ...
                                installedConventionalSolarNominalPowerW, ...
                                installedManagedSolarNominalPowerW];

    comparisonRows = table();
    budgetRows = table();
    missionStore = cell(numel(scenarioNames), numel(lifeSpansDays));

    for sIdx = 1:numel(scenarioNames)
        for lIdx = 1:numel(lifeSpansDays)
            cfg = scenarioConfig(scenarioNames(sIdx), lifeSpansDays(lIdx));
            cfg.solarNominalPowerW = installedSolarByScenario(sIdx);
            cfg.designLifeDays = designLifeDays;
            cfg.designMarginPct = 100*designMargin;

            budget = estimateCubeSatEPSPowerBudget(orbitSim, cfg, lifeSpansDays(lIdx));
            cfg.requiredSolarBOLW = budget.requiredSolarBOLW;
            cfg.installedSolarMarginPct = budget.installedSolarMarginPct;
            cfg.requiredBatteryWhAtTargetDOD = budget.requiredBatteryWhAtTargetDOD;
            cfg.installedBatteryMarginPct = budget.installedBatteryMarginPct;
            cfg.dayLoadW = budget.dayLoadW;
            cfg.eclipseLoadW = budget.eclipseLoadW;
            cfg.daylightHours = budget.daylightHours;
            cfg.eclipseHours = budget.eclipseHours;

            mission = simulateCubeSatMissionPower(orbitSim, cfg);
            comparisonRows = [comparisonRows; summaryToTableRow(mission.summary)]; %#ok<AGROW>
            budgetRows = [budgetRows; budgetToTableRow(string(cfg.scenarioName), lifeSpansDays(lIdx), budget)]; %#ok<AGROW>
            missionStore{sIdx,lIdx} = mission;

            fprintf('%-32s | %4d d | %-22s | min SOC %5.1f%% | batt %5.1f%% | solar margin %+6.1f%% | unmet %8.2f Wh\n', ...
                scenarioNames(sIdx), lifeSpansDays(lIdx), mission.summary.status, ...
                mission.summary.minSOCPct, mission.summary.finalBatteryHealthPct, ...
                mission.summary.installedSolarMarginPct, mission.summary.unmetWh);
        end
    end

    writetable(comparisonRows, fullfile(outputDir,'mission_power_lifespan_comparison.csv'));
    writetable(budgetRows, fullfile(outputDir,'mission_power_sizing_reference.csv'));
    save(fullfile(outputDir,'mission_power_v22_results.mat'), 'missionStore', 'comparisonRows', ...
        'budgetRows', 'orbitSim', 'eclipseInfo', 'lifeSpansDays', 'scenarioNames', ...
        'installedSolarByScenario', 'installedManagedSolarNominalPowerW', ...
        'installedConventionalSolarNominalPowerW', 'managedBudgetInstalled', ...
        'conventionalBudgetInstalled', 'stressBudgetInstalled');

    managed3yr = missionStore{1,end};
    conventional3yr = missionStore{2,end};
    stress3yr = missionStore{3,end};
    writetable(dailyToTable(managed3yr), fullfile(outputDir,'mission_power_daily_managed_3yr.csv'));
    writetable(dailyToTable(conventional3yr), fullfile(outputDir,'mission_power_daily_conventional_3yr.csv'));
    writetable(dailyToTable(stress3yr), fullfile(outputDir,'mission_power_daily_same_array_stress_3yr.csv'));

    createMissionPowerComparisonFigure(managed3yr, conventional3yr, stress3yr, comparisonRows, budgetRows, eclipseInfo);

    fprintf('--------------------------------------------------\n');
    fprintf('Eclipse model source:       %s\n', eclipseInfo.source);
    fprintf('True orbital period:        %.3f min\n', orbitMinutes);
    fprintf('Managed BOL solar array:    %.2f W\n', installedManagedSolarNominalPowerW);
    fprintf('Conventional BOL array:     %.2f W\n', installedConventionalSolarNominalPowerW);
    fprintf('Life spans evaluated:       %s days\n', strjoin(string(lifeSpansDays), ', '));
    fprintf('Comparison CSV:             outputs/mission_power_lifespan_comparison.csv\n');
    fprintf('Sizing reference CSV:       outputs/mission_power_sizing_reference.csv\n');
    fprintf('Managed daily CSV:          outputs/mission_power_daily_managed_3yr.csv\n');
    fprintf('Conventional daily CSV:     outputs/mission_power_daily_conventional_3yr.csv\n');
    fprintf('Same-array stress CSV:      outputs/mission_power_daily_same_array_stress_3yr.csv\n');
    fprintf('MAT results:                outputs/mission_power_v22_results.mat\n');
    fprintf('==================================================\n');
end

function cfg = scenarioConfig(name, durationDays)
    cfg = struct();
    cfg.scenarioName = char(name);
    cfg.missionDurationDays = durationDays;
    cfg.missionStepSeconds = 300;
    cfg.initialSOC = 0.85;

    % Shared hardware: small deployable/body-mounted CubeSat EPS envelope.
    cfg.batteryNominalCapacityWh = 24.0;
    cfg.solarNominalPowerW = 10.5;  % overwritten by source-backed sizing above
    cfg.payloadRailScale = 1.0;
    cfg.sunPointingFactor = 0.82;
    cfg.mpptEfficiency = 0.92;
    cfg.epsDistributionEfficiency = 0.90;
    cfg.batteryNominalChargeEfficiency = 0.94;
    cfg.batteryNominalDischargeEfficiency = 0.96;
    cfg.targetOrbitDOD = 0.30;

    % Battery thermal/aging assumptions. These are deliberately moderate and
    % should be replaced by vendor cell data for a flight design.
    cfg.batteryInitialTempC = 22.0;
    cfg.batteryBaseTempC = 18.0;
    cfg.batterySunHeatC = 5.0;
    cfg.batteryLoadHeatCoeffCperW = 0.40;
    cfg.batteryOrbitTempCoupling = 0.035;
    cfg.batteryThermalTauMin = 55.0;
    cfg.batteryReferenceTempC = 25.0;
    cfg.batteryQ10 = 2.0;
    cfg.batteryReferenceCycleLifeEFC = 5500;
    cfg.batteryCycleFadeAtReference = 0.20;
    cfg.batteryCalendarFadePerYear = 0.010;
    cfg.batteryMaxPermanentFade = 0.45;
    cfg.batteryMinHealthFloor = 0.55;
    cfg.referenceDOD = 0.30;
    cfg.minimumDODForAging = 0.03;
    cfg.dodStressExponent = 1.55;
    cfg.minDODStressFactor = 0.15;
    cfg.referenceCRate = 0.20;
    cfg.cRateStressGain = 0.60;
    cfg.highSOCStressThreshold = 0.85;
    cfg.highSOCCalendarStressGain = 1.10;
    cfg.lowSOCStressThreshold = 0.15;
    cfg.lowSOCCalendarStressGain = 1.10;
    cfg.batteryColdCapacityLossPerC = 0.0045;
    cfg.batteryHotCapacityLossPerC = 0.0020;
    cfg.batteryMinTempCapacityFactor = 0.70;
    cfg.batteryMaxTempCapacityFactor = 1.02;
    cfg.batteryMinEfficiency = 0.82;

    % Solar assumptions. V20 uses a sizing temperature instead of the much
    % hotter electronics telemetry temperature so array output is not derated
    % by a payload-board temperature that the panels would not physically see.
    cfg.solarRadiationDegradationPerYear = 0.018;
    cfg.solarThermalCycleFadePerHalfCycle = 3.5e-8;
    cfg.solarMaxPermanentFade = 0.30;
    cfg.solarMinHealthFloor = 0.70;
    cfg.panelReferenceTempC = 25.0;
    cfg.panelSizingTempC = 45.0;
    cfg.panelPowerTempCoeffPerC = -0.0032;
    cfg.panelMinTempDerate = 0.70;
    cfg.panelMaxTempDerate = 1.05;
    cfg.panelInitialTempC = 0.0;
    cfg.panelEclipseTempC = -30.0;
    cfg.panelSunTempC = 50.0;
    cfg.panelThermalTauMin = 10.0;
    cfg.panelLoadHeatCoeffCperW = 0.05;
    cfg.panelCycleReferenceDeltaC = 75.0;
    cfg.eclipseThreshold = 0.5;

    % Mode loads.
    cfg.powerBootW = 2.0;
    cfg.powerPayloadOnW = 4.2;
    cfg.powerEclipseSleepW = 0.75;
    cfg.powerThermalProtectW = 1.05;
    cfg.powerBackupSafeW = 0.60;
    cfg.powerNoManagementW = 5.0;
    cfg.noManagementPayloadCurrentmA = 40.1;
    cfg.noManagementEclipsePenaltyW = 0.30;

    % Reporting thresholds.
    cfg.eolBatteryHealthLimit = 0.80;
    cfg.eolSolarHealthLimit = 0.80;
    cfg.thermalWarningC = 45.0;
    cfg.thermalLimitC = 60.0;
    cfg.unmetEnergyToleranceWh = 1.0e-3;

    switch string(name)
        case "Managed EPS solution"
            cfg.powerManagementEnabled = true;
            cfg.scenarioRole = "managed";
            cfg.socMin = 0.20;
            cfg.socMax = 0.90;

        case "Conventional CubeSat EPS"
            % Real CubeSats are not operated as always-on no-control systems.
            % This baseline keeps ordinary eclipse safe mode and is given its
            % own correctly sized solar array, but it is less efficient than
            % the proposed managed solution.
            cfg.powerManagementEnabled = true;
            cfg.scenarioRole = "conventional";
            cfg.socMin = 0.15;
            cfg.socMax = 0.95;
            cfg.epsDistributionEfficiency = 0.88;
            cfg.powerPayloadOnW = 4.85;
            cfg.powerEclipseSleepW = 2.15;
            cfg.powerThermalProtectW = 1.55;
            cfg.powerBackupSafeW = 1.20;
            cfg.batteryLoadHeatCoeffCperW = 0.50;
            cfg.batteryCalendarFadePerYear = 0.012;
            cfg.highSOCCalendarStressGain = 1.35;
            cfg.lowSOCCalendarStressGain = 1.30;

        otherwise
            % Stress test only: no active power management, but the solar array
            % is intentionally kept at the smaller managed-case size. A deficit
            % in this case is a hardware/control design gap, not a statement
            % that a normal CubeSat would be launched this way.
            cfg.powerManagementEnabled = false;
            cfg.scenarioRole = "stress-test";
            cfg.socMin = 0.05;
            cfg.socMax = 1.00;
            cfg.epsDistributionEfficiency = 0.88;
            cfg.batteryLoadHeatCoeffCperW = 0.55;
            cfg.batteryCalendarFadePerYear = 0.013;
            cfg.highSOCCalendarStressGain = 1.60;
            cfg.lowSOCCalendarStressGain = 1.50;
    end
end

function row = summaryToTableRow(s)
    row = table(string(s.scenarioName), s.durationDays, s.finalSOCPct, ...
        s.minSOCPct, s.meanSOCPct, s.finalBatteryHealthPct, ...
        s.finalSolarHealthPct, s.equivalentFullCycles, ...
        s.weightedCycleDamageEFC, s.meanOrbitDODPct, s.maxOrbitDODPct, ...
        s.generatedWh, s.consumedWh, s.energyBalanceWh, s.unmetWh, ...
        s.excessWh, s.lowSOCHours, s.thermalWarningHours, s.thermalLimitHours, s.maxBatteryTempC, ...
        s.meanPowerMarginW, s.requiredSolarBOLW, s.installedSolarBOLW, ...
        s.installedSolarMarginPct, s.requiredBatteryWhAtTargetDOD, ...
        s.installedBatteryMarginPct, string(s.status), ...
        'VariableNames', {'Scenario','Duration_Days','Final_SOC_pct', ...
        'Min_SOC_pct','Mean_SOC_pct','Battery_Health_pct', ...
        'Solar_Health_pct','Equivalent_Full_Cycles','Weighted_Cycle_Damage_EFC', ...
        'Mean_Orbit_DOD_pct','Max_Orbit_DOD_pct','Generated_Wh','Consumed_Wh', ...
        'Energy_Balance_Wh','Unmet_Wh','Excess_Wh','Low_SOC_Hours', ...
        'Thermal_Warning_Hours','Thermal_Limit_Hours','Max_Battery_Temp_C','Mean_Power_Margin_W', ...
        'Required_Solar_BOL_W','Installed_Solar_BOL_W','Installed_Solar_Margin_pct', ...
        'Required_Battery_Wh_at_Target_DOD','Installed_Battery_Margin_pct','Status'});
end

function row = budgetToTableRow(scenarioName, durationDays, b)
    row = table(scenarioName, durationDays, b.daylightHours, b.eclipseHours, ...
        b.dayLoadW, b.eclipseLoadW, b.orbitAverageLoadW, b.requiredEOLSunPowerW, ...
        b.requiredSolarBOLW, b.installedSolarBOLW, b.installedSolarMarginPct, ...
        b.solarHealthEOL, b.panelTempDerate, b.requiredBatteryWhAtTargetDOD, ...
        b.installedBatteryMarginPct, b.targetOrbitDODPct, ...
        'VariableNames', {'Scenario','Duration_Days','Daylight_Hours','Eclipse_Hours', ...
        'Day_Load_W','Eclipse_Load_W','Orbit_Average_Load_W','Required_EOL_Sun_Power_W', ...
        'Required_Solar_BOL_W','Installed_Solar_BOL_W','Installed_Solar_Margin_pct', ...
        'Solar_Health_EOL','Panel_Temp_Derate','Required_Battery_Wh_at_Target_DOD', ...
        'Installed_Battery_Margin_pct','Target_Orbit_DOD_pct'});
end

function t = dailyToTable(mission)
    d = mission.daily;
    t = table(d.day(:), d.socMinPct(:), d.socMeanPct(:), d.socMaxPct(:), ...
        d.generatedWh(:), d.consumedWh(:), d.unmetWh(:), d.excessWh(:), ...
        d.capacityHealthPct(:), d.solarHealthPct(:), d.meanDODPct(:), ...
        d.maxDODPct(:), d.maxBatteryTempC(:), d.maxPanelTempC(:), ...
        d.lowSOCHours(:), d.thermalLimitHours(:), ...
        'VariableNames', {'Day','SOC_Min_pct','SOC_Mean_pct','SOC_Max_pct', ...
        'Generated_Wh','Consumed_Wh','Unmet_Wh','Excess_Wh', ...
        'Battery_Health_pct','Solar_Health_pct','Mean_DOD_pct','Max_DOD_pct', ...
        'Max_Battery_Temp_C','Max_Panel_Temp_C','Low_SOC_Hours','Thermal_Limit_Hours'});
end

function createMissionPowerComparisonFigure(managedMission, conventionalMission, stressMission, comparisonRows, budgetRows, eclipseInfo)
    th = getMissionTheme();

    fig = figure('Name','CubeSat EPS Source-Backed Comparison - V22', ...
        'NumberTitle','off', ...
        'Color',th.bg, ...
        'Position',[35 25 1660 980]);

    tl = tiledlayout(fig,3,3,'TileSpacing','compact','Padding','compact');
    title(tl,sprintf('CubeSat EPS Source-Backed Power Metrics - Conventional Baseline View (%s)',eclipseInfo.source), ...
        'Color',th.fg,'FontWeight','bold','Interpreter','none');

    designDays = max(budgetRows.Duration_Days);
    managedBudget = budgetRows(budgetRows.Scenario == "Managed EPS solution" & budgetRows.Duration_Days == designDays,:);
    conventionalBudget = budgetRows(budgetRows.Scenario == "Conventional CubeSat EPS" & budgetRows.Duration_Days == designDays,:);
    stressBudget = budgetRows(budgetRows.Scenario == "Same-array no-control stress test" & budgetRows.Duration_Days == designDays,:);

    ax = nexttile(tl);
    catNames = {'Managed req.','Managed installed','Conv. req.','Conv. installed','Stress req.'};
    % V23 FIX (independent audit): categorical({...}) with no explicit
    % valueset sorts its categories ALPHABETICALLY in MATLAB (confirmed in
    % MathWorks docs), not in the order the strings are listed here. bar()
    % then draws the bars in that alphabetical order ("Conv. installed",
    % "Conv. req.", "Managed installed", "Managed req.", "Stress req."),
    % while labelBars() below was assuming vals(k) sits at x=k in the
    % ORIGINAL, un-sorted order -- so 4 of the 5 value labels were sitting
    % over the wrong bar. Fixed two ways: (1) pass catNames as an explicit
    % valueset so the categories keep their intended order, and (2) have
    % labelBars read each bar's actual plotted position from its Bar
    % object (XEndPoints/YEndPoints) instead of assuming x=1:N, so it stays
    % correct even if the category order ever changes again.
    cats = categorical(catNames, catNames);
    vals = [managedBudget.Required_Solar_BOL_W, managedBudget.Installed_Solar_BOL_W, ...
            conventionalBudget.Required_Solar_BOL_W, conventionalBudget.Installed_Solar_BOL_W, ...
            stressBudget.Required_Solar_BOL_W];
    b = bar(ax,cats,vals);
    ylim(ax,[0, max(vals)*1.18]);
    labelBars(ax,b,'%.1f W');
    formatMissionAxis(ax,th,'Solar-array sizing logic','','BOL array power (W)');
    subtitle(ax,'Lower is better. Stress test is intentionally undersized.','Color',th.muted);

    ax = nexttile(tl);
    managedMargin = managedMission.daily.generatedWh - managedMission.daily.consumedWh;
    sameMargin = stressMission.daily.generatedWh - stressMission.daily.consumedWh;
    resizedMargin = conventionalMission.daily.generatedWh - conventionalMission.daily.consumedWh;
    plot(ax,managedMission.daily.day,managedMargin,'LineWidth',1.25);
    hold(ax,'on');
    plot(ax,stressMission.daily.day,sameMargin,'LineWidth',1.25);
    plot(ax,conventionalMission.daily.day,resizedMargin,'LineWidth',1.25);
    yline(ax,0,'--','Zero margin');
    legend(ax,{'Managed','Same-array stress','Conventional'},'TextColor',th.fg,'Location','best');
    zoomYAxis(ax,[managedMargin(:); sameMargin(:); resizedMargin(:)],[],[],8);
    formatMissionAxis(ax,th,'Daily energy margin, zoomed','Mission day','Wh/day');
    subtitle(ax,'Higher is better (more headroom above zero margin)','Color',th.muted);

    ax = nexttile(tl);
    plot(ax,stressMission.daily.day,cumsum(stressMission.daily.unmetWh),'LineWidth',1.25);
    hold(ax,'on');
    plot(ax,conventionalMission.daily.day,cumsum(conventionalMission.daily.unmetWh),'LineWidth',1.25);
    legend(ax,{'Same-array stress','Conventional'},'TextColor',th.fg,'Location','northwest');
    formatMissionAxis(ax,th,'Unmet energy diagnosis','Mission day','Cumulative unmet Wh');
    subtitle(ax,'Lower is better. Separates EPS deficit from battery aging','Color',th.muted);

    ax = nexttile(tl);
    plotSOCEnvelope(ax,managedMission,th,'Managed SOC envelope, zoomed',true);

    ax = nexttile(tl);
    plotSOCEnvelope(ax,stressMission,th,'Same-array stress-test SOC collapse',false);
    zoomWindow = stressMission.daily.day >= min(7,max(stressMission.daily.day));
    if any(zoomWindow)
        values = [stressMission.daily.socMinPct(zoomWindow); ...
                  stressMission.daily.socMeanPct(zoomWindow); ...
                  stressMission.daily.socMaxPct(zoomWindow)];
        zoomYAxis(ax,values,0,30,5);
    end

    ax = nexttile(tl);
    plotSOCEnvelope(ax,conventionalMission,th,'Conventional CubeSat SOC envelope, zoomed',true);

    ax = nexttile(tl);
    plot(ax,managedMission.daily.day,managedMission.daily.maxDODPct,'LineWidth',1.25);
    hold(ax,'on');
    plot(ax,stressMission.daily.day,stressMission.daily.maxDODPct,'LineWidth',1.25);
    plot(ax,conventionalMission.daily.day,conventionalMission.daily.maxDODPct,'LineWidth',1.25);
    legend(ax,{'Managed','Same-array stress','Conventional'},'TextColor',th.fg,'Location','best');
    dodVals = [managedMission.daily.maxDODPct(:); stressMission.daily.maxDODPct(:); conventionalMission.daily.maxDODPct(:)];
    zoomYAxis(ax,dodVals,0,[],4);
    formatMissionAxis(ax,th,'Maximum orbit DOD, zoomed','Mission day','DOD (%)');
    subtitle(ax,'Lower is better (shallower DOD = less battery stress)','Color',th.muted);

    ax = nexttile(tl);
    durations = unique(comparisonRows.Duration_Days);
    managedRows = comparisonRows(comparisonRows.Scenario == "Managed EPS solution",:);
    stressRows = comparisonRows(comparisonRows.Scenario == "Same-array no-control stress test",:);
    conventionalRows = comparisonRows(comparisonRows.Scenario == "Conventional CubeSat EPS",:);
    plot(ax,durations,managedRows.Battery_Health_pct,'-o','LineWidth',1.25);
    hold(ax,'on');
    plot(ax,durations,stressRows.Battery_Health_pct,'-o','LineWidth',1.25);
    plot(ax,durations,conventionalRows.Battery_Health_pct,'-o','LineWidth',1.25);
    yline(ax,80,'--','EOL reference');
    legend(ax,{'Managed','Same-array stress','Conventional'},'TextColor',th.fg,'Location','best');
    healthVals = [managedRows.Battery_Health_pct; stressRows.Battery_Health_pct; conventionalRows.Battery_Health_pct];
    zoomYAxis(ax,healthVals,78,100.5,4);
    formatMissionAxis(ax,th,'Battery health by life span, zoomed','Mission duration (days)','Health (%)');
    subtitle(ax,'Higher is better','Color',th.muted);

    ax = nexttile(tl);
    plot(ax,durations,100-managedRows.Battery_Health_pct,'-o','LineWidth',1.25);
    hold(ax,'on');
    plot(ax,durations,100-stressRows.Battery_Health_pct,'-o','LineWidth',1.25);
    plot(ax,durations,100-conventionalRows.Battery_Health_pct,'-o','LineWidth',1.25);
    legend(ax,{'Managed loss','Same-array stress loss','Conventional loss'},'TextColor',th.fg,'Location','northwest');
    lossVals = [100-managedRows.Battery_Health_pct; 100-stressRows.Battery_Health_pct; 100-conventionalRows.Battery_Health_pct];
    zoomYAxis(ax,lossVals,0,[],2);
    formatMissionAxis(ax,th,'Battery health loss, expanded scale','Mission duration (days)','Capacity fade (%)');
    subtitle(ax,'Lower is better','Color',th.muted);
end

function plotSOCEnvelope(ax,mission,th,ttl,zoomNormal)
    plot(ax,mission.daily.day,mission.daily.socMinPct,'LineWidth',1.0);
    hold(ax,'on');
    plot(ax,mission.daily.day,mission.daily.socMeanPct,'LineWidth',1.25);
    plot(ax,mission.daily.day,mission.daily.socMaxPct,'LineWidth',1.0);
    yline(ax,100*mission.config.socMin,'--','SOC floor');
    legend(ax,{'Daily min','Daily mean','Daily max'},'TextColor',th.fg,'Location','best');
    vals = [mission.daily.socMinPct(:); mission.daily.socMeanPct(:); mission.daily.socMaxPct(:)];
    if zoomNormal
        zoomYAxis(ax,vals,max(0,100*mission.config.socMin - 2),100.5,4);
    end
    formatMissionAxis(ax,th,ttl,'Mission day','SOC (%)');
    subtitle(ax,'Context-dependent: stay clear of the SOC floor','Color',th.muted);
end

function zoomYAxis(ax,values,hardMin,hardMax,minSpan)
    values = values(isfinite(values));
    if isempty(values)
        return;
    end
    if nargin < 3 || isempty(hardMin)
        hardMin = -inf;
    end
    if nargin < 4 || isempty(hardMax)
        hardMax = inf;
    end
    if nargin < 5 || isempty(minSpan)
        minSpan = 1;
    end

    vMin = min(values);
    vMax = max(values);
    span = max(vMax - vMin, minSpan);
    pad = max(0.08*span, 0.15);
    yLo = vMin - pad;
    yHi = vMax + pad;

    if (yHi - yLo) < minSpan
        mid = 0.5*(yHi + yLo);
        yLo = mid - 0.5*minSpan;
        yHi = mid + 0.5*minSpan;
    end

    yLo = max(yLo, hardMin);
    yHi = min(yHi, hardMax);
    if yHi <= yLo
        yHi = yLo + minSpan;
    end
    ylim(ax,[yLo yHi]);
end

function labelBars(ax,barObj,fmt)
% labelBars
% -------------------------------------------------------------------------
% V23 FIX (independent audit): used to take the raw values vector and place
% text(ax,k,values(k),...) assuming the k-th bar is at x=k. That assumption
% breaks the moment the bars are not drawn in the same order the values
% were listed in (e.g. MATLAB's default alphabetical categorical sort --
% see the V23 FIX note at the call site). Reading XEndPoints/YEndPoints
% directly off the actual Bar object is correct by construction: it is
% wherever MATLAB itself decided to draw each bar, full stop.
    xs = barObj.XEndPoints;
    ys = barObj.YEndPoints;
    for k = 1:numel(xs)
        text(ax,xs(k),ys(k),sprintf(fmt,ys(k)), ...
            'HorizontalAlignment','center', ...
            'VerticalAlignment','bottom', ...
            'Color',ax.YColor, ...
            'FontSize',8, ...
            'FontWeight','bold');
    end
end

function formatMissionAxis(ax,th,ttl,xlab,ylab)
    set(ax,'Color',th.chartBg,'XColor',th.fg,'YColor',th.fg, ...
        'GridColor',th.grid,'FontName','Consolas','FontSize',9,'Box','on');
    grid(ax,'on');
    title(ax,ttl,'Color',th.fg,'FontWeight','bold');
    if ~isempty(xlab)
        xlabel(ax,xlab,'Color',th.fg);
    end
    ylabel(ax,ylab,'Color',th.fg);
end

function th = getMissionTheme()
    th.bg = [0.010 0.014 0.026];
    th.chartBg = [0.018 0.026 0.045];
    th.fg = [0.92 0.95 1.00];
    th.muted = [0.62 0.70 0.82];
    th.grid = [0.20 0.26 0.38];
end
